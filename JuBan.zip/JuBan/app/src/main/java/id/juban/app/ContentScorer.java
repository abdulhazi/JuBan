package id.juban.app;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Reads a web page's HTML and decides whether it is a Ju site.
 *
 * Real Ju pages announce themselves loudly: titles such as "Daftar Agen Situs Toto Togel
 * Online" or "Bandar Judi Resmi Live Casino Online" carry several strong phrases at once,
 * and the page lists game providers (Pragmatic Play, PG Soft, ...). So the rule needs
 * several strong phrases together, which keeps ordinary pages that merely mention one
 * such word safe. Pages that talk ABOUT Ju sites (news, police, government) are
 * recognised by their own vocabulary and let through.
 *
 * Pure Java (no Android imports) so it can be unit-tested on a desktop JVM.
 */
public final class ContentScorer {

    private ContentScorer() {}

    /** Phrases that practically only appear on Ju sites. Matched as whole words. */
    static final String[] STRONG = {
            "slot gacor", "slot online", "situs slot", "agen slot", "judi online", "judi slot",
            "situs judi", "agen judi", "bandar judi", "judi bola", "judi resmi",
            "togel online", "situs togel", "bandar togel", "agen togel", "toto togel", "situs toto",
            "casino online", "live casino", "kasino online", "bonus new member", "new member 100",
            "link alternatif", "rtp live", "rtp slot", "bocoran rtp", "pola gacor", "scatter hitam",
            "maxwin", "anti rungkad", "gampang menang", "gampang maxwin", "depo 10k", "depo 5k",
            "deposit pulsa", "deposit dana", "tanpa potongan", "free chip", "freechip",
            "pragmatic play", "pg soft", "pgsoft", "habanero", "spadegaming", "microgaming",
            "joker123", "joker gaming", "nolimit city", "hacksaw gaming", "jili", "pay4d",
            "idn poker", "idn casino", "idnplay", "sbobet", "mahjong ways", "gates of olympus",
            "sweet bonanza", "starlight princess", "dragon tiger", "mix parlay", "sabung ayam",
            "toto macau", "togel hongkong", "togel singapore", "togel sgp", "togel hk",
            "keluaran hk", "keluaran sgp", "paito", "slot88", "slot777", "situs gacor",
            "akun gacor", "akun pro", "server thailand", "slot thailand", "slot demo",
            "togel resmi", "situs toto togel", "bandar slot", "daftar slot", "login slot",
            // game makers
            "evolution gaming", "playtech", "ezugi", "sexy baccarat", "sa gaming", "spribe", "cq9",
            "jdb", "nextspin", "advantplay", "fachai", "live22", "mega888", "918kiss", "wm casino",
            "yggdrasil", "netent", "play n go", "red tiger", "relax gaming", "booongo", "bgaming",
            "skywind", "dream gaming",
    };

    /** Common words on Ju sites, but also elsewhere; they only add weight. */
    static final Set<String> MEDIUM = new HashSet<>(java.util.Arrays.asList(
            "slot", "slots", "casino", "kasino", "togel", "judi", "gacor", "deposit", "withdraw",
            "depo", "wd", "daftar", "login", "masuk", "bonus", "jackpot", "rtp", "poker", "parlay",
            "spin", "toto", "bandar", "agen", "resmi", "terpercaya", "scatter", "member", "hadiah",
            "prediksi", "sabung", "baccarat", "roulette", "blackjack", "sportsbook", "taruhan",
            "betting", "bet", "4d", "promosi", "livechat"));

    /** In a title, these words on their own already point strongly at a Ju site. */
    static final Set<String> TITLE_WORDS = new HashSet<>(java.util.Arrays.asList(
            "slot", "togel", "judi", "casino", "kasino", "gacor", "toto", "maxwin", "sbobet"));

    /** Vocabulary of pages that report on or fight Ju sites. */
    static final Set<String> COUNTER = new HashSet<>(java.util.Arrays.asList(
            "satgas", "berantas", "pemberantasan", "memberantas", "komdigi", "kominfo", "polisi",
            "polri", "polda", "polres", "ditangkap", "tersangka", "bahaya", "dampak", "kecanduan",
            "rehabilitasi", "redaksi", "wartawan", "menteri", "kementerian"));

    public static final class Result {
        public boolean ju;
        public int strong;      // distinct strong phrases in the whole page
        public int medium;      // distinct medium words
        public int titleHits;   // strong phrases + title words in the title
        public int counter;     // distinct counter words
        public int words;       // how many words of readable text the page has
        public String title = "";

        @Override public String toString() {
            return "ju=" + ju + " strong=" + strong + " medium=" + medium + " title=" + titleHits
                    + " counter=" + counter + " \"" + title + "\"";
        }
    }

    private static final Pattern TITLE = Pattern.compile("<title[^>]*>(.*?)</title>",
            Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern SCRIPT_STYLE = Pattern.compile(
            "<(script|style|noscript|svg)[^>]*>.*?</\\1>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern META_CONTENT = Pattern.compile(
            "<meta[^>]+content\\s*=\\s*[\"']([^\"']*)[\"']", Pattern.CASE_INSENSITIVE);
    private static final Pattern ALT = Pattern.compile("\\salt\\s*=\\s*[\"']([^\"']*)[\"']",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern TAG = Pattern.compile("<[^>]*>");
    private static final Pattern NON_WORD = Pattern.compile("[^a-z0-9]+");

    /** Lower-case words separated by single spaces, with a space at each end. */
    static String words(String s) {
        String t = s.toLowerCase(Locale.ROOT)
                .replace("&amp;", "&").replace("&nbsp;", " ").replace("&#39;", "'").replace("&quot;", "\"");
        return " " + NON_WORD.matcher(t).replaceAll(" ").trim() + " ";
    }

    public static Result score(String html) {
        Result r = new Result();
        if (html == null) return r;
        if (html.length() > 400_000) html = html.substring(0, 400_000);

        Matcher tm = TITLE.matcher(html);
        String title = tm.find() ? tm.group(1) : "";
        r.title = title.trim().replaceAll("\\s+", " ");
        if (r.title.length() > 160) r.title = r.title.substring(0, 160);

        StringBuilder text = new StringBuilder(title).append(' ');
        Matcher mm = META_CONTENT.matcher(html);
        while (mm.find()) text.append(mm.group(1)).append(' ');
        Matcher am = ALT.matcher(html);
        while (am.find()) text.append(am.group(1)).append(' ');
        String body = SCRIPT_STYLE.matcher(html).replaceAll(" ");
        text.append(TAG.matcher(body).replaceAll(" "));

        String all = words(text.toString());
        r.words = all.trim().isEmpty() ? 0 : all.trim().split(" ").length;
        String t = words(title);

        Set<String> titleSeen = new HashSet<>();
        for (String p : STRONG) {
            String needle = " " + p + " ";
            if (all.contains(needle)) r.strong++;
            if (t.contains(needle)) titleSeen.add(p);
        }
        for (String w : t.trim().split(" ")) if (TITLE_WORDS.contains(w)) titleSeen.add(w);
        r.titleHits = titleSeen.size();

        Set<String> med = new HashSet<>(), counter = new HashSet<>();
        for (String w : all.trim().split(" ")) {
            if (MEDIUM.contains(w)) med.add(w);
            if (COUNTER.contains(w)) counter.add(w);
        }
        r.medium = med.size();
        r.counter = counter.size();

        boolean ju = r.titleHits >= 2
                || (r.titleHits >= 1 && r.strong >= 2)
                || r.strong >= 3
                || (r.strong >= 2 && r.medium >= 4);
        // A news or government page about Ju sites: only block if it is overwhelming.
        if (r.counter >= 2 && r.strong < 6) ju = false;
        r.ju = ju;
        return r;
    }

    /** Titles of "checking your browser" screens, which hide the real page from JuBan. */
    private static final String[] CHALLENGE_TITLES = {
            "just a moment", "attention required", "checking your browser", "verify you are human",
            "please wait", "bot verification", "403 forbidden", "access denied", "ddos-guard",
            "security check", "one more step"};

    /** Technical traces those screens leave in their code. */
    private static final String[] CHALLENGE_MARKS = {
            "cf-challenge", "challenge-platform", "cf_chl_", "ddos-guard", "sgcaptcha", "imunify360",
            "error 1020", "your access to this site has been limited",
            "enable javascript and cookies to continue"};

    /**
     * True when the page tells us nothing: a protection screen, or (almost) no text at all
     * (a page drawn entirely by scripts). Such a page must never be remembered as clean.
     */
    public static boolean unreadable(String html, Result r) {
        if (html == null) return true;
        if (r.ju) return false;
        if (r.words < 25) return true;
        if (r.words >= 300) return false;          // protection screens are short
        String title = r.title.toLowerCase(Locale.ROOT);
        for (String t : CHALLENGE_TITLES) if (title.contains(t)) return true;
        String h = (html.length() > 60_000 ? html.substring(0, 60_000) : html).toLowerCase(Locale.ROOT);
        for (String m : CHALLENGE_MARKS) if (h.contains(m)) return true;
        return false;
    }

    private static final Pattern META_REFRESH = Pattern.compile(
            "<meta[^>]+http-equiv\\s*=\\s*[\"']?refresh[^>]*url\\s*=\\s*['\"]?([^'\"\\s>]+)",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern JS_LOCATION = Pattern.compile(
            "location(?:\\.href)?\\s*(?:=|\\.replace\\(|\\.assign\\()\\s*['\"](https?://[^'\"]+)['\"]",
            Pattern.CASE_INSENSITIVE);

    /** A page that just forwards the visitor elsewhere (meta refresh or script): where to. */
    public static String findRedirect(String html) {
        if (html == null) return null;
        Matcher m = META_REFRESH.matcher(html);
        if (m.find()) return m.group(1);
        m = JS_LOCATION.matcher(html);
        if (m.find()) return m.group(1);
        return null;
    }
}
