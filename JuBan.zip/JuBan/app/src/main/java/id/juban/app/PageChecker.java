package id.juban.app;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * The page check: opens a site's front page the way a phone browser would, scores the text
 * with {@link ContentScorer}, and remembers the verdict.
 *
 * Verdicts are kept in a small file: Ju sites forever, clean sites for 7 days, sites that
 * could not be read for 6 hours (and those are never blocked). "Could not be read" includes
 * error pages, "checking your browser" screens and pages with almost no text: those are
 * never remembered as clean.
 *
 * Many Ju pages live on hacked websites that show the Ju page only to people arriving from
 * a Google search, and the old site to everyone else. So the check visits like someone who
 * clicked a Google result.
 *
 * Pure Java (no Android imports) so it can be unit-tested on a desktop JVM.
 */
public final class PageChecker {

    public static final int UNKNOWN = 0, JU = 1, CLEAN = 2, FAILED = 3;

    static final long CLEAN_FOR_MS = 7L * 24 * 60 * 60 * 1000;
    static final long FAILED_FOR_MS = 6L * 60 * 60 * 1000;
    static final int MAX_BYTES = 300_000;
    static final int TIMEOUT_MS = 2500;

    /** Visit like someone who clicked a Google search result. */
    static final String REFERER = "https://www.google.com/";

    static final String USER_AGENT = "Mozilla/5.0 (Linux; Android 14; K) AppleWebKit/537.36 "
            + "(KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36";

    /** Fetches a page. Replaceable in tests. */
    public interface Fetcher {
        /** @return the HTML and the address it finally came from, or null on failure. */
        Page fetch(String url);
    }

    public static final class Page {
        public final String html, finalUrl;
        public final int status;
        public Page(String html, String finalUrl) { this(html, finalUrl, 200); }
        public Page(String html, String finalUrl, int status) {
            this.html = html;
            this.finalUrl = finalUrl;
            this.status = status;
        }
    }

    /** Told about every site found to be a Ju site. */
    public interface Listener { void onJu(String host, ContentScorer.Result why); }

    private final File file;
    private final Fetcher fetcher;
    private final Map<String, long[]> verdicts = new ConcurrentHashMap<>();   // host -> {verdict, until}
    private final Map<String, Future<Integer>> inflight = new ConcurrentHashMap<>();
    private final ExecutorService exec;
    private final AtomicInteger juCount = new AtomicInteger();
    private volatile Listener listener;
    private long clock = -1;   // tests only

    public PageChecker(File file, Fetcher fetcher) {
        this.file = file;
        this.fetcher = fetcher != null ? fetcher : new HttpFetcher();
        this.exec = Executors.newFixedThreadPool(6, new ThreadFactory() {
            private final AtomicInteger n = new AtomicInteger();
            @Override public Thread newThread(Runnable r) {
                Thread t = new Thread(r, "juban-check-" + n.incrementAndGet());
                t.setDaemon(true);
                return t;
            }
        });
        load();
    }

    public void setListener(Listener l) { listener = l; }
    public void shutdown() { exec.shutdownNow(); }
    public void setClockForTest(long now) { clock = now; }
    private long now() { return clock >= 0 ? clock : System.currentTimeMillis(); }

    /** How many different sites the page check has found so far. */
    public int juCount() { return juCount.get(); }

    /** The remembered verdict, or UNKNOWN if there is none (or it has expired). */
    public int cached(String host) {
        long[] v = verdicts.get(host);
        if (v == null) return UNKNOWN;
        if (v[0] != JU && v[1] < now()) {
            verdicts.remove(host);
            return UNKNOWN;
        }
        return (int) v[0];
    }

    /** Starts a check (or joins one already running for this host). */
    public Future<Integer> check(final String host) {
        Future<Integer> f = inflight.get(host);
        if (f != null) return f;
        synchronized (inflight) {
            f = inflight.get(host);
            if (f != null) return f;
            f = exec.submit(new Callable<Integer>() {
                @Override public Integer call() {
                    try {
                        return run(host);
                    } finally {
                        inflight.remove(host);
                    }
                }
            });
            inflight.put(host, f);
            return f;
        }
    }

    int run(String host) {
        int c = cached(host);
        if (c != UNKNOWN) return c;

        Page page = fetcher.fetch("https://" + host + "/");
        if (page == null) page = fetcher.fetch("http://" + host + "/");
        if (page == null) {
            remember(host, FAILED, null);
            return FAILED;
        }
        ContentScorer.Result r = ContentScorer.score(page.html);
        boolean readable = page.status < 400 && !ContentScorer.unreadable(page.html, r);
        if (!r.ju) {
            // A page that only forwards the visitor somewhere else: check where it goes.
            String next = ContentScorer.findRedirect(page.html);
            if (next != null) {
                try {
                    URL u = new URL(new URL(page.finalUrl), next);
                    Page p2 = fetcher.fetch(u.toString());
                    if (p2 != null) {
                        r = ContentScorer.score(p2.html);
                        readable = p2.status < 400 && !ContentScorer.unreadable(p2.html, r);
                    }
                } catch (IOException ignored) { }
            }
        }
        if (!r.ju && !readable) {
            remember(host, FAILED, r);                 // try again later; never "clean"
            return FAILED;
        }
        int verdict = r.ju ? JU : CLEAN;
        remember(host, verdict, r);
        // If the address forwarded to another site, that site gets the same verdict.
        try {
            String finalHost = new URL(page.finalUrl).getHost().toLowerCase(Locale.ROOT);
            // (Not for big known sites such as Telegram, which a Ju page may link to.)
            if (!finalHost.equals(host) && PageCheckPolicy.eligible(finalHost, 1)
                    && cached(finalHost) == UNKNOWN) {
                remember(finalHost, verdict, r);
            }
        } catch (IOException ignored) { }
        return verdict;
    }

    private void remember(String host, int verdict, ContentScorer.Result why) {
        long until = verdict == JU ? Long.MAX_VALUE
                : now() + (verdict == CLEAN ? CLEAN_FOR_MS : FAILED_FOR_MS);
        long[] old = verdicts.put(host, new long[]{verdict, until});
        if (verdict == JU && (old == null || old[0] != JU)) {
            juCount.incrementAndGet();
            Listener l = listener;
            if (l != null) l.onJu(host, why);
        }
        append(host, verdict, until);
    }

    // ---- the verdict file: one line per verdict, the last line for a host wins ----

    private synchronized void append(String host, int verdict, long until) {
        if (file == null) return;
        try {
            if (file.length() > 512 * 1024) compact();
            try (Writer w = new FileWriter(file, true)) {
                w.write(host + " " + verdict + " " + until + "\n");
            }
        } catch (IOException ignored) { }
    }

    private synchronized void compact() throws IOException {
        File tmp = new File(file.getPath() + ".tmp");
        long t = now();
        try (Writer w = new FileWriter(tmp, false)) {
            for (Map.Entry<String, long[]> e : verdicts.entrySet()) {
                long[] v = e.getValue();
                if (v[0] == JU || v[1] > t) w.write(e.getKey() + " " + v[0] + " " + v[1] + "\n");
            }
        }
        if (!tmp.renameTo(file)) {
            file.delete();
            tmp.renameTo(file);
        }
    }

    private void load() {
        if (file == null || !file.exists()) return;
        try (BufferedReader r = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = r.readLine()) != null) {
                String[] p = line.trim().split(" ");
                if (p.length != 3) continue;
                try {
                    verdicts.put(p[0], new long[]{Long.parseLong(p[1]), Long.parseLong(p[2])});
                } catch (NumberFormatException ignored) { }
            }
        } catch (IOException ignored) { }
        int n = 0;
        for (long[] v : verdicts.values()) if (v[0] == JU) n++;
        juCount.set(n);
    }

    /**
     * Moves verdicts to a new file, keeping only the Ju ones. Used once when upgrading from
     * 1.3, whose "clean" verdicts may have come from protection screens or from hacked sites
     * that hid their Ju page; those sites get checked again.
     */
    public static void keepOnlyJu(File from, File to) {
        if (from == null || !from.exists() || to == null) return;
        StringBuilder keep = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new FileReader(from))) {
            String line;
            while ((line = r.readLine()) != null) {
                String[] p = line.trim().split(" ");
                if (p.length == 3 && p[1].equals(String.valueOf(JU))) keep.append(line.trim()).append('\n');
            }
        } catch (IOException e) {
            return;
        }
        try (Writer w = new FileWriter(to, true)) {
            w.write(keep.toString());
        } catch (IOException e) {
            return;
        }
        from.delete();
    }

    /** Remembers a site as Ju (found by the screen check). */
    public void markJu(String host) {
        if (host == null || cached(host) == JU) return;
        remember(host, JU, null);
    }

    /** Forgets a site (used when the user marks it "Always allow"). */
    public void forget(String host) {
        long[] old = verdicts.remove(host);
        if (old != null && old[0] == JU) juCount.decrementAndGet();
        append(host, CLEAN, now() + CLEAN_FOR_MS);
        verdicts.put(host, new long[]{CLEAN, now() + CLEAN_FOR_MS});
    }

    // ---- the real fetcher ----

    /** Opens a page like a phone browser in Indonesia would, following redirects. */
    public static final class HttpFetcher implements Fetcher {
        @Override public Page fetch(String url) {
            try {
                String current = url;
                for (int hop = 0; hop < 5; hop++) {
                    HttpURLConnection c = (HttpURLConnection) new URL(current).openConnection();
                    c.setInstanceFollowRedirects(false);
                    c.setConnectTimeout(TIMEOUT_MS);
                    c.setReadTimeout(TIMEOUT_MS);
                    c.setRequestProperty("User-Agent", USER_AGENT);
                    c.setRequestProperty("Accept", "text/html,application/xhtml+xml;q=0.9,*/*;q=0.8");
                    c.setRequestProperty("Accept-Language", "id-ID,id;q=0.9,en;q=0.8");
                    c.setRequestProperty("Referer", REFERER);
                    try {
                        int code = c.getResponseCode();
                        if (code >= 300 && code < 400) {
                            String loc = c.getHeaderField("Location");
                            if (loc == null) return null;
                            current = new URL(new URL(current), loc).toString();
                            continue;
                        }
                        InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
                        if (in == null) return null;
                        String type = c.getContentType();
                        if (type != null && !type.toLowerCase(Locale.ROOT).contains("html")) return null;
                        return new Page(read(in, charset(type)), current, code);
                    } finally {
                        c.disconnect();
                    }
                }
            } catch (IOException | RuntimeException e) {
                // unreachable, bad certificate, not a website...
            }
            return null;
        }

        private static Charset charset(String type) {
            if (type != null) {
                int i = type.toLowerCase(Locale.ROOT).indexOf("charset=");
                if (i >= 0) {
                    try {
                        return Charset.forName(type.substring(i + 8).replace("\"", "").trim());
                    } catch (RuntimeException ignored) { }
                }
            }
            return StandardCharsets.UTF_8;
        }

        private static String read(InputStream in, Charset cs) throws IOException {
            try (InputStream s = in) {
                byte[] buf = new byte[MAX_BYTES];
                int n = 0, r;
                while (n < buf.length && (r = s.read(buf, n, buf.length - n)) > 0) n += r;
                return new String(buf, 0, n, cs);
            }
        }
    }
}
