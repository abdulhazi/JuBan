package id.juban.app;

/**
 * The turn-off delay. Protection cannot be switched off on the spot: the person asks,
 * waits DELAY_MS, and then has WINDOW_MS to actually switch it off. If they do nothing
 * in that window the request expires and they have to ask again.
 *
 * Pure Java (no Android imports) so it can be unit-tested on a desktop JVM.
 */
public final class LockTimer {

    /** How long protection stays on after turn-off is requested. Change this to taste. */
    public static final long DELAY_MS = 24L * 60 * 60 * 1000;
    /** How long the "you may turn it off now" window stays open afterwards. */
    public static final long WINDOW_MS = 60L * 60 * 1000;

    public static final int NONE = 0;      // no request (or it expired)
    public static final int WAITING = 1;   // counting down
    public static final int OPEN = 2;      // may be turned off now

    public final int state;
    /** Time left in the current state (0 for NONE). */
    public final long remainingMs;

    private LockTimer(int state, long remainingMs) {
        this.state = state;
        this.remainingMs = remainingMs;
    }

    /**
     * @param requestWall    clock time when turn-off was requested, or 0 if there is no request
     * @param requestElapsed time-since-boot when it was requested
     * @param sameBoot       true if the phone has not been restarted since the request
     *
     * While the phone has not restarted we measure with time-since-boot, which is not
     * affected by someone moving the clock forward in Settings.
     */
    public static LockTimer compute(long requestWall, long requestElapsed, boolean sameBoot,
                                    long nowWall, long nowElapsed) {
        if (requestWall <= 0) return new LockTimer(NONE, 0);
        long passed = sameBoot ? nowElapsed - requestElapsed : nowWall - requestWall;
        if (passed < 0) passed = 0;
        if (passed < DELAY_MS) return new LockTimer(WAITING, DELAY_MS - passed);
        if (passed < DELAY_MS + WINDOW_MS) return new LockTimer(OPEN, DELAY_MS + WINDOW_MS - passed);
        return new LockTimer(NONE, 0);
    }
}
