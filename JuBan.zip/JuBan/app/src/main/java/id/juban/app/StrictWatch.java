package id.juban.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.provider.Settings;

/**
 * Notices when strict mode (the accessibility service) has been switched off by Android or the
 * phone maker's cleaner, not by the person, and does something about it:
 *  - if JuBan was given the "write secure settings" permission once from a computer, it switches
 *    strict mode back on by itself;
 *  - otherwise it shows an alert that opens JuBan.
 * Called about once a minute while protection is on, and at start-up.
 */
final class StrictWatch {
    private StrictWatch() { }

    private static final String CHANNEL = "strict_alert";
    private static final int ALERT_ID = 4242;
    static final String PERMISSION = "android.permission.WRITE_SECURE_SETTINGS";

    static void check(Context c) {
        try {
            if (!Prefs.enabled(c)) { clear(c); return; }
            if (GuardService.isOn(c)) {
                Prefs.setStrictWanted(c, true);       // remember it was on, so a later "off" is a surprise
                clear(c);
                return;
            }
            if (!Prefs.strictWanted(c)) return;       // never turned on: nothing was lost
            if (canSwitchOn(c) && switchOn(c) && GuardService.isOn(c)) { clear(c); return; }
            alert(c);
        } catch (RuntimeException ignored) { }
    }

    static boolean canSwitchOn(Context c) {
        return c.checkSelfPermission(PERMISSION) == PackageManager.PERMISSION_GRANTED;
    }

    /** Adds JuBan's accessibility service to the enabled list. Needs the permission above. */
    static boolean switchOn(Context c) {
        try {
            String me = new ComponentName(c, GuardService.class).flattenToString();
            String list = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            String next = (list == null || list.isEmpty()) ? me : list + ":" + me;
            boolean a = Settings.Secure.putString(c.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, next);
            boolean b = Settings.Secure.putInt(c.getContentResolver(), Settings.Secure.ACCESSIBILITY_ENABLED, 1);
            return a && b;
        } catch (RuntimeException e) {
            return false;
        }
    }

    private static void alert(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(
                CHANNEL, c.getString(R.string.channel_alert), NotificationManager.IMPORTANCE_DEFAULT));
        PendingIntent pi = PendingIntent.getActivity(c, 1, new Intent(c, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        nm.notify(ALERT_ID, new Notification.Builder(c, CHANNEL)
                .setSmallIcon(R.drawable.ic_shield)
                .setContentTitle(c.getString(R.string.strict_alert_title))
                .setContentText(c.getString(R.string.strict_alert_text))
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build());
    }

    private static void clear(Context c) {
        ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(ALERT_ID);
    }
}
