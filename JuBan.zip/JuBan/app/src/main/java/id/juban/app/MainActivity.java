package id.juban.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class MainActivity extends Activity {

    private static final int REQUEST_VPN = 1;
    private static final int REQUEST_NOTIFICATIONS = 2;

    private TextView status, lockInfo, count, recent, rules, adminStatus, strictStatus;
    private Button toggle, adminButton;
    private Switch smart, page;
    private TextView pageHelp;
    private EditText input;
    private DevicePolicyManager dpm;
    private ComponentName admin;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            refresh();
            handler.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
        admin = new ComponentName(this, AdminReceiver.class);

        status = findViewById(R.id.status);
        lockInfo = findViewById(R.id.lock_info);
        count = findViewById(R.id.count);
        recent = findViewById(R.id.recent);
        rules = findViewById(R.id.rules);
        adminStatus = findViewById(R.id.admin_status);
        strictStatus = findViewById(R.id.strict_status);
        findViewById(R.id.btn_strict).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                try {
                    startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                } catch (RuntimeException e) {
                    Toast.makeText(MainActivity.this, R.string.open_settings_failed, Toast.LENGTH_LONG).show();
                }
            }
        });
        toggle = findViewById(R.id.toggle);
        adminButton = findViewById(R.id.btn_admin);
        smart = findViewById(R.id.smart);
        page = findViewById(R.id.page_check);
        pageHelp = findViewById(R.id.page_help);
        input = findViewById(R.id.input);

        toggle.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { onToggle(); }
        });
        adminButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { onAdminButton(); }
        });

        smart.setChecked(Prefs.smart(this));
        smart.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                if (on == Prefs.smart(MainActivity.this)) return;
                if (!on && Prefs.locked(MainActivity.this)) {       // switching it off weakens protection
                    b.setChecked(true);
                    toastLocked();
                    return;
                }
                Prefs.setSmart(MainActivity.this, on);
                reloadService();
            }
        });

        page.setChecked(Prefs.pageCheck(this));
        page.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                if (on == Prefs.pageCheck(MainActivity.this)) return;
                if (!on && Prefs.locked(MainActivity.this)) {       // switching it off weakens protection
                    b.setChecked(true);
                    toastLocked();
                    return;
                }
                Prefs.setPageCheck(MainActivity.this, on);
                reloadService();
            }
        });

        findViewById(R.id.btn_block).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { addBlockRule(); }
        });
        findViewById(R.id.btn_allow).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { addAllowRule(); }
        });
        findViewById(R.id.btn_clear).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (Prefs.locked(MainActivity.this)) { toastLocked(); return; }
                Prefs.clearRules(MainActivity.this);
                reloadService();
                refresh();
            }
        });
        findViewById(R.id.btn_always_on).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                try {
                    startActivity(new Intent(Settings.ACTION_VPN_SETTINGS));
                } catch (RuntimeException e) {
                    Toast.makeText(MainActivity.this, R.string.open_settings_failed, Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Wanted on but not running (stopped from outside, or the phone restarted): bring it back.
        if (Prefs.enabled(this) && !BlockVpnService.running) {
            try {
                if (VpnService.prepare(this) == null) launchService();
            } catch (RuntimeException ignored) { }
        }
        handler.post(ticker);
    }

    @Override protected void onPause() { super.onPause(); handler.removeCallbacks(ticker); }

    // ---- the big button ----

    private void onToggle() {
        if (!Prefs.enabled(this) || !BlockVpnService.running) {      // off, or stopped from outside
            askVpnPermission();
            return;
        }
        LockTimer lock = Prefs.lock(this);
        if (lock.state == LockTimer.OPEN) {
            Prefs.setEnabled(this, false);
            Prefs.clearTurnOffRequest(this);
            startService(new Intent(this, BlockVpnService.class).setAction(BlockVpnService.ACTION_STOP));
            refreshSoon();
        } else if (lock.state == LockTimer.WAITING) {
            Prefs.clearTurnOffRequest(this);                         // changed their mind: stay protected
            refresh();
        } else {
            confirmRequest();
        }
    }

    private void confirmRequest() {
        int hours = (int) (LockTimer.DELAY_MS / 3600000L);
        new AlertDialog.Builder(this)
                .setTitle(R.string.request_title)
                .setMessage(getString(R.string.request_message, hours))
                .setNegativeButton(R.string.request_cancel, null)
                .setPositiveButton(R.string.request_confirm, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        Prefs.requestTurnOff(MainActivity.this);
                        refresh();
                    }
                })
                .show();
    }

    private void askVpnPermission() {
        Intent consent = VpnService.prepare(this);
        if (consent != null) startActivityForResult(consent, REQUEST_VPN);   // Android's own dialog
        else startProtection();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_VPN && resultCode == RESULT_OK) startProtection();
    }

    private void startProtection() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, REQUEST_NOTIFICATIONS);
        }
        Prefs.setEnabled(this, true);
        launchService();
    }

    private void launchService() {
        startForegroundService(new Intent(this, BlockVpnService.class).setAction(BlockVpnService.ACTION_START));
        refreshSoon();
    }

    private void reloadService() {
        if (BlockVpnService.running) {
            startService(new Intent(this, BlockVpnService.class).setAction(BlockVpnService.ACTION_RELOAD));
        }
    }

    // ---- uninstall protection ----

    private void onAdminButton() {
        if (!dpm.isAdminActive(admin)) {
            try {
                startActivity(new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                        .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
                        .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, getString(R.string.admin_explanation)));
            } catch (RuntimeException e) {
                Toast.makeText(this, R.string.open_settings_failed, Toast.LENGTH_LONG).show();
            }
        } else if (Prefs.locked(this)) {
            toastLocked();
        } else {
            dpm.removeActiveAdmin(admin);
            refreshSoon();
        }
    }

    // ---- the user's own rules ----

    private void addBlockRule() {
        String text = input.getText().toString();
        String domain = DomainMatcher.normalize(text);
        String word = domain == null ? DomainMatcher.normalizeWord(text) : null;
        if (domain != null) {
            Prefs.addBlock(this, domain);
            done(getString(R.string.added_block, domain));
        } else if (word != null) {
            Prefs.addWord(this, word);
            done(getString(R.string.added_word, word));
        } else {
            Toast.makeText(this, R.string.bad_domain, Toast.LENGTH_SHORT).show();
        }
    }

    private void addAllowRule() {
        if (Prefs.locked(this)) { toastLocked(); return; }           // allowing a site weakens protection
        String domain = DomainMatcher.normalize(input.getText().toString());
        if (domain == null) {
            Toast.makeText(this, R.string.bad_domain, Toast.LENGTH_SHORT).show();
            return;
        }
        Prefs.addAllow(this, domain);
        done(getString(R.string.added_allow, domain));
    }

    private void done(String message) {
        input.setText("");
        reloadService();
        refresh();
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private void toastLocked() {
        Toast.makeText(this, R.string.locked, Toast.LENGTH_LONG).show();
    }

    // ---- screen ----

    private void refreshSoon() {
        handler.postDelayed(new Runnable() { @Override public void run() { refresh(); } }, 500);
    }

    private String duration(long ms) {
        long minutes = Math.max(1, (ms + 59999) / 60000);
        long h = minutes / 60, m = minutes % 60;
        return h > 0 ? getString(R.string.duration_hm, h, m) : getString(R.string.duration_m, m);
    }

    private void refresh() {
        boolean wanted = Prefs.enabled(this);
        boolean on = BlockVpnService.running;
        LockTimer lock = Prefs.lock(this);
        int hours = (int) (LockTimer.DELAY_MS / 3600000L);

        if (!wanted) {
            status.setText(R.string.status_off);
            toggle.setText(R.string.turn_on);
            lockInfo.setText(getString(R.string.lock_hint_off, hours));
        } else if (!on) {
            status.setText(R.string.status_stopped);
            toggle.setText(R.string.turn_back_on);
            lockInfo.setText(R.string.lock_hint_stopped);
        } else if (lock.state == LockTimer.OPEN) {
            status.setText(R.string.status_on);
            toggle.setText(R.string.turn_off_now);
            lockInfo.setText(getString(R.string.lock_open, duration(lock.remainingMs)));
        } else if (lock.state == LockTimer.WAITING) {
            status.setText(R.string.status_on);
            toggle.setText(R.string.cancel_request);
            lockInfo.setText(getString(R.string.lock_waiting, duration(lock.remainingMs)));
        } else {
            status.setText(R.string.status_on);
            toggle.setText(R.string.request_turn_off);
            lockInfo.setText(getString(R.string.lock_hint_on, hours));
        }
        status.setTextColor(getColor(wanted && on ? R.color.on : R.color.off));
        count.setText(getString(R.string.blocked_count, Prefs.blockedCount(this)));

        boolean protectedFromUninstall = dpm.isAdminActive(admin);
        adminStatus.setText(protectedFromUninstall ? R.string.admin_on : R.string.admin_off);
        adminStatus.setTextColor(getColor(protectedFromUninstall ? R.color.on : R.color.off));
        adminButton.setText(protectedFromUninstall ? R.string.admin_remove : R.string.admin_add);

        boolean strict = GuardService.isOn(this);
        strictStatus.setText(strict ? R.string.strict_on : R.string.strict_off);
        strictStatus.setTextColor(getColor(strict ? R.color.on : R.color.off));

        if (smart.isChecked() != Prefs.smart(this)) smart.setChecked(Prefs.smart(this));
        if (page.isChecked() != Prefs.pageCheck(this)) page.setChecked(Prefs.pageCheck(this));
        pageHelp.setText(getString(R.string.page_help, Prefs.pageChecker(this).juCount()));

        List<String> r = BlockVpnService.recent();
        recent.setText(r.isEmpty() ? getString(R.string.recent_empty) : TextUtils.join("\n", r));

        Set<String> block = new TreeSet<>(Prefs.userBlock(this));
        Set<String> words = new TreeSet<>(Prefs.userWords(this));
        Set<String> allow = new TreeSet<>(Prefs.userAllow(this));
        if (block.isEmpty() && words.isEmpty() && allow.isEmpty()) {
            rules.setText(R.string.rules_empty);
        } else {
            StringBuilder sb = new StringBuilder();
            for (String w : words) sb.append("✖  *").append(w).append("*\n");
            for (String d : block) sb.append("✖  ").append(d).append('\n');
            for (String d : allow) sb.append("✔  ").append(d).append('\n');
            rules.setText(sb.toString().trim());
        }
    }
}
