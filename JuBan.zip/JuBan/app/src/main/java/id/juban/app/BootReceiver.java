package id.juban.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.VpnService;

/** Turns protection back on after the phone restarts, if it was on before. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || !Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;
        if (!Prefs.enabled(context)) return;
        try {
            if (VpnService.prepare(context) == null) {          // VPN permission still granted
                context.startForegroundService(new Intent(context, BlockVpnService.class)
                        .setAction(BlockVpnService.ACTION_START));
            }
        } catch (RuntimeException ignored) {
            // The app will offer "Turn back on" next time it is opened.
        }
    }
}
