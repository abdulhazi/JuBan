package id.juban.app;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Decides whether a host name is a gambling site.
 *
 * Three layers, checked in this order:
 *   1. the user's own allow list  (always wins)
 *   2. the user's own block list and brand words + the bundled block list
 *      (exact domain or any subdomain; a brand word matches anywhere in the name)
 *   3. "smart detection": naming patterns typical of online-gambling ("judol") domains,
 *      which change address far too often for a fixed list to keep up.
 *
 * Pure Java (no Android imports) so it can be unit-tested on a desktop JVM.
 */
public final class DomainMatcher {

    public static final String REASON_LIST = "list";
    public static final String REASON_CUSTOM = "custom";
    public static final String REASON_SMART = "smart";

    /** Legitimate sites that the naming patterns would otherwise catch. */
    private static final Set<String> BUILTIN_ALLOW = set(
            "toto.com", "toto.co.id", "totousa.com", "bet.com", "qq.com", "alphabet.com");

    /** Top-level domains reserved for gambling. */
    private static final Set<String> GAMBLING_TLDS = set("bet", "casino", "poker", "bingo", "lotto");

    /** If any part of the name contains one of these, it is blocked. */
    private static final String[] STRONG = {
            "togel", "gacor", "maxwin", "sbobet", "judol", "casino", "poker",
            "judibola", "judionline", "judiqq", "judimpo", "judislot",
            "bandarq", "dominoqq", "pkvgames", "sabungayam", "mixparlay", "taruhan",
            "mahjongways", "pragmaticplay", "pgsoft", "spadegaming", "gatesofolympus",
            "rtpslot", "rtplive", "bocoranrtp", "scatterhitam", "sportsbook", "betting",
            "jackpot", "roulette", "baccarat", "totomacau", "toto4d",
            "1xbet", "bet365", "betway", "188bet", "fun88", "joker123", "joker388",
            "nova88", "cmd368", "ibcbet", "alexis17",
            // game makers: their game servers carry these names (pragmaticplay and pgsoft above)
            "evogames", "evolutiongaming", "ezugi", "microgaming", "jiligame", "jokergaming",
            "cq9gaming", "playngo", "nolimitcity", "hacksawgaming", "redtigergaming",
            "yggdrasilgaming", "relaxgaming", "booongo", "spribe", "nextspin", "advantplay",
            "mega888", "918kiss", "sexybaccarat", "aesexy", "jdbgaming", "skywindgroup",
            "habanerosystems",
            // brands and phrases seen in the wild
            "mawartoto", "loginalternatif", "linkalternatif", "alternatiflogin"
    };

    /** Whole words (bounded by digits, hyphens or the ends of the name). */
    private static final Set<String> WORDS = set(
            "slot", "slots", "judi", "toto", "bet", "bets", "mpo", "w88", "m88");

    /** Ordinary words that merely end like a gambling name. */
    private static final Set<String> SUFFIX_EXCEPTIONS = set(
            "timeslot", "timeslots", "alphabet", "tibet", "sherbet", "abet", "cinema4d");

    /** Words that, glued to a "lucky number", make a typical judol brand (hoki88, raja777...). */
    private static final String[] BRAND_WORDS = {
            "hoki", "cuan", "jp", "win", "mpo", "dewa", "naga", "raja", "ratu", "sultan",
            "bos", "bola", "spin", "zeus", "bet", "slot", "toto", "play", "kaya", "mega",
            "asia", "indo", "king", "liga", "gol", "vip", "luck", "fortune", "emas", "gold",
            "menang", "untung", "jitu", "angka", "kartu", "club", "game", "olympus"
    };
    private static final Set<String> LUCKY_NUMBERS = set(
            "77", "88", "99", "123", "138", "168", "188", "189", "303", "328", "338", "365",
            "368", "388", "555", "666", "777", "789", "888", "999", "1000", "4d");

    private static final Pattern WORD_NUM = Pattern.compile("^([a-z]{2,14})(\\d{2,4}|4d)$");
    private static final Pattern NUM_WORD = Pattern.compile("^(\\d{2,4})([a-z]{2,14})$");

    /** A name ending in one of these after a hyphen: "something-win", "something-jp". */
    private static final Set<String> LAST_WORDS = set("win", "wins", "jp", "cuan", "hoki");
    /** A number followed by "win" or "jp" at the end: "ibiza168win", "raja99jp". */
    private static final Pattern NUM_THEN_WIN = Pattern.compile("[0-9]{2,4}(win|wins|jp)[0-9]*$");
    /** Triple lucky digits glued to letters anywhere in the name: "name888site". */
    private static final Pattern TRIPLE = Pattern.compile("(777|888|999)");

    private final Set<String> listed;
    private final Set<String> userBlock;
    private final Set<String> userAllow;
    private final Set<String> userWords;
    private final boolean smart;

    /**
     * @param userWords brand words chosen by the user; any address containing one is blocked.
     *                  This is what catches a brand that keeps moving to new addresses.
     */
    public DomainMatcher(Collection<String> listed, Collection<String> userBlock,
                         Collection<String> userWords, Collection<String> userAllow, boolean smart) {
        this.listed = new HashSet<>(listed);
        this.userBlock = new HashSet<>(userBlock);
        this.userWords = new HashSet<>(userWords);
        this.userAllow = new HashSet<>(userAllow);
        this.smart = smart;
    }

    private static Set<String> set(String... s) { return new HashSet<>(Arrays.asList(s)); }

    /** @return why the name is blocked (one of the REASON_ constants), or null if it is allowed. */
    public String check(String host) {
        if (host == null || host.isEmpty()) return null;
        String h = host.toLowerCase(Locale.ROOT);
        if (h.endsWith(".")) h = h.substring(0, h.length() - 1);

        if (inSet(userAllow, h)) return null;
        if (inSet(userBlock, h)) return REASON_CUSTOM;
        if (inSet(listed, h)) return REASON_LIST;

        String[] labels = h.split("\\.");
        if (labels.length < 2) return null;
        if (!userWords.isEmpty()) {
            for (int i = 0; i < labels.length - 1; i++) {
                String flat = labels[i].replace("-", "");
                for (String w : userWords) if (flat.contains(w)) return REASON_CUSTOM;
            }
        }
        if (!smart || inSet(BUILTIN_ALLOW, h)) return null;
        if (GAMBLING_TLDS.contains(labels[labels.length - 1])) return REASON_SMART;
        for (int i = 0; i < labels.length - 1; i++) {        // every part except the TLD
            if (looksLikeGambling(labels[i])) return REASON_SMART;
        }
        return null;
    }

    /** True if the user marked this site (or a parent domain) "Always allow". */
    public boolean allowedByUser(String host) {
        if (host == null) return false;
        String h = host.toLowerCase(Locale.ROOT);
        if (h.endsWith(".")) h = h.substring(0, h.length() - 1);
        return inSet(userAllow, h);
    }

    /** True if the domain or any parent domain is in the set. */
    private static boolean inSet(Set<String> s, String h) {
        if (s.isEmpty()) return false;
        String d = h;
        while (true) {
            if (s.contains(d)) return true;
            int dot = d.indexOf('.');
            if (dot < 0) return false;
            d = d.substring(dot + 1);
        }
    }

    static boolean looksLikeGambling(String label) {
        if (label.length() < 3 && !WORDS.contains(label)) return false;
        String flat = label.replace("-", "");
        for (String ok : SUFFIX_EXCEPTIONS) {
            if (flat.equals(ok) || (ok.length() >= 5 && flat.endsWith(ok))) return false;
        }

        for (String k : STRONG) if (flat.contains(k)) return true;

        // whole words: "slot-gacor", "judi88", "bet-303"
        for (String token : label.split("[^a-z]+")) {
            if (WORDS.contains(token)) return true;
        }
        for (String token : label.split("-")) {
            if (WORDS.contains(token)) return true;        // catches w88 / m88
        }

        // names built around a gambling word: megaslot, slotdana, rajatoto, indobet, agenjudi
        if (flat.startsWith("slot") || flat.endsWith("slot") || flat.endsWith("slots")) return true;
        if (flat.length() > 4 && (flat.endsWith("toto") || flat.endsWith("judi"))) return true;
        if (flat.length() > 4 && flat.endsWith("bet")) return true;
        if (flat.length() > 3 && (flat.endsWith("4d") || flat.endsWith("qq"))) return true;

        // "name-win", "name-jp"
        String[] parts = label.split("-");
        if (parts.length > 1 && LAST_WORDS.contains(parts[parts.length - 1])) return true;

        if (NUM_THEN_WIN.matcher(flat).find()) return true;

        // triple lucky digits glued to a name: "name888site", "x777"
        if (TRIPLE.matcher(flat).find() && flat.replaceAll("[^a-z]", "").length() >= 3) return true;

        // brand word + lucky number: hoki88, raja777, 88cuan, mpo123
        Matcher m = WORD_NUM.matcher(flat);
        if (m.matches()) {
            if (m.group(1).equals("mpo")) return true;
            if (LUCKY_NUMBERS.contains(m.group(2)) && hasBrandWord(m.group(1))) return true;
        }
        m = NUM_WORD.matcher(flat);
        if (m.matches() && LUCKY_NUMBERS.contains(m.group(1)) && hasBrandWord(m.group(2))) return true;

        return false;
    }

    private static boolean hasBrandWord(String word) {
        for (String b : BRAND_WORDS) if (word.contains(b)) return true;
        return false;
    }

    /**
     * Cleans up something a person typed ("https://www.Example.com/page") into a bare
     * domain ("example.com"). Returns null if it does not look like a domain.
     */
    public static String normalize(String input) {
        if (input == null) return null;
        String s = input.trim().toLowerCase(Locale.ROOT);
        int scheme = s.indexOf("://");
        if (scheme >= 0) s = s.substring(scheme + 3);
        int cut = s.indexOf('/');
        if (cut >= 0) s = s.substring(0, cut);
        cut = s.indexOf(':');
        if (cut >= 0) s = s.substring(0, cut);
        if (s.startsWith("www.")) s = s.substring(4);
        if (!s.matches("^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$")) return null;
        return s;
    }

    /**
     * Cleans up a brand word typed by a person ("Wahana"). Returns null unless it is
     * 4-20 letters or digits; shorter words would block far too much.
     */
    public static String normalizeWord(String input) {
        if (input == null) return null;
        String s = input.trim().toLowerCase(Locale.ROOT);
        return s.matches("^[a-z0-9]{4,20}$") ? s : null;
    }
}
