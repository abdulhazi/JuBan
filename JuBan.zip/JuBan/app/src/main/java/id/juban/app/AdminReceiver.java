package id.juban.app;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Uninstall protection. While JuBan is an active "device admin app", Android greys out
 * Uninstall. JuBan asks for no admin powers at all (see res/xml/device_admin.xml); being
 * on that list is the whole point.
 */
public class AdminReceiver extends DeviceAdminReceiver {

    /** Shown by Android when someone tries to deactivate JuBan in Settings. */
    @Override
    public CharSequence onDisableRequested(Context context, Intent intent) {
        return context.getString(R.string.admin_disable_warning);
    }
}
