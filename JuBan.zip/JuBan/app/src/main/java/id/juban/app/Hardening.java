package id.juban.app;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.UserManager;

/**
 * Optional "phone lock": extra protection that only exists when JuBan has been made the
 * device owner of the phone (one adb command from a computer, see the guide). As device owner
 * JuBan can switch off the usual ways round it: Safe Mode, factory reset from Settings,
 * uninstall, adding another user (which would have no protection) and changing Private DNS.
 * (Android's "no control apps" limit is not used: it would stop force-stop, clear data and
 * uninstall for every app on the phone, not just JuBan.)
 *
 * Nothing here does anything on a phone where JuBan is not the device owner.
 * Releasing it is locked behind the same 24-hour wait as turning protection off.
 */
final class Hardening {
    private Hardening() { }

    /** The limits JuBan sets, as user-restriction names (strings, so they exist on every Android). */
    static String[] restrictions() {
        return new String[] {
                UserManager.DISALLOW_SAFE_BOOT,
                UserManager.DISALLOW_FACTORY_RESET,
                UserManager.DISALLOW_ADD_USER,
                "no_config_private_dns",        // UserManager.DISALLOW_CONFIG_PRIVATE_DNS (Android 10+)
        };
    }

    static boolean isOwner(Context c) {
        try {
            DevicePolicyManager dpm = (DevicePolicyManager) c.getSystemService(Context.DEVICE_POLICY_SERVICE);
            return dpm != null && dpm.isDeviceOwnerApp(c.getPackageName());
        } catch (RuntimeException e) {
            return false;
        }
    }

    /** Sets every limit. Safe to call again and again; does nothing unless JuBan is the owner. */
    static void apply(Context c) {
        if (!isOwner(c)) return;
        DevicePolicyManager dpm = (DevicePolicyManager) c.getSystemService(Context.DEVICE_POLICY_SERVICE);
        ComponentName admin = new ComponentName(c, AdminReceiver.class);
        try {
            dpm.setUninstallBlocked(admin, c.getPackageName(), true);
        } catch (RuntimeException ignored) { }
        for (String r : restrictions()) {
            try {
                dpm.addUserRestriction(admin, r);
            } catch (RuntimeException ignored) { }   // an Android version that does not know it
        }
        try {
            // Android keeps JuBan's VPN running and restarts it. "Block connections without VPN"
            // stays off on purpose: JuBan's VPN only carries name lookups.
            dpm.setAlwaysOnVpnPackage(admin, c.getPackageName(), false);
        } catch (PackageManager.NameNotFoundException | RuntimeException ignored) { }
    }

    /**
     * Gives the phone back its normal controls and ends the device-owner role.
     * Returns false (and does nothing) while protection is locked.
     */
    static boolean release(Context c) {
        if (!isOwner(c) || Prefs.locked(c)) return false;
        DevicePolicyManager dpm = (DevicePolicyManager) c.getSystemService(Context.DEVICE_POLICY_SERVICE);
        ComponentName admin = new ComponentName(c, AdminReceiver.class);
        for (String r : restrictions()) {
            try {
                dpm.clearUserRestriction(admin, r);
            } catch (RuntimeException ignored) { }
        }
        try {
            dpm.setUninstallBlocked(admin, c.getPackageName(), false);
        } catch (RuntimeException ignored) { }
        try {
            dpm.setAlwaysOnVpnPackage(admin, null, false);
        } catch (PackageManager.NameNotFoundException | RuntimeException ignored) { }
        try {
            dpm.clearDeviceOwnerApp(c.getPackageName());
        } catch (RuntimeException ignored) { }
        return !isOwner(c);
    }
}
