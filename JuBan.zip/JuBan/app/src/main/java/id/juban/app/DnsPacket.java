package id.juban.app;

import java.nio.charset.StandardCharsets;

/**
 * Minimal IPv4/UDP/DNS packet handling. Pure Java (no Android imports) so it
 * can be unit-tested on a desktop JVM.
 */
public final class DnsPacket {

    private DnsPacket() {}

    /** A DNS query that arrived on the VPN interface. */
    public static final class Query {
        public final byte[] srcIp = new byte[4];
        public final byte[] dstIp = new byte[4];
        public int srcPort;
        public int dstPort;
        /** Offset and length of the DNS payload inside the IP packet. */
        public int dnsOffset;
        public int dnsLength;
        /** Offset (inside the IP packet) just past the first question. -1 if unparsed. */
        public int questionEnd = -1;
        /** Lower-case host name being looked up, or null if it could not be parsed. */
        public String name;
        public int qtype;
    }

    private static int u8(byte[] b, int i) { return b[i] & 0xff; }
    private static int u16(byte[] b, int i) { return (u8(b, i) << 8) | u8(b, i + 1); }
    private static void put16(byte[] b, int i, int v) { b[i] = (byte) (v >> 8); b[i + 1] = (byte) v; }

    /**
     * Parses an IP packet read from the tun device.
     * @return the query, or null if this is not an unfragmented IPv4 UDP packet to port 53.
     */
    public static Query parse(byte[] p, int len) {
        if (len < 28) return null;
        if ((u8(p, 0) >> 4) != 4) return null;              // IPv4 only
        int ihl = (u8(p, 0) & 0x0f) * 4;
        if (ihl < 20 || len < ihl + 8) return null;
        if (u8(p, 9) != 17) return null;                     // UDP only
        if ((u16(p, 6) & 0x3fff) != 0) return null;          // no fragments
        int udpLen = u16(p, ihl + 4);
        if (udpLen < 8 + 12 || ihl + udpLen > len) return null;

        Query q = new Query();
        System.arraycopy(p, 12, q.srcIp, 0, 4);
        System.arraycopy(p, 16, q.dstIp, 0, 4);
        q.srcPort = u16(p, ihl);
        q.dstPort = u16(p, ihl + 2);
        if (q.dstPort != 53) return null;
        q.dnsOffset = ihl + 8;
        q.dnsLength = udpLen - 8;

        int d = q.dnsOffset;
        int end = d + q.dnsLength;
        boolean isQuery = (u8(p, d + 2) & 0x80) == 0;
        int qdCount = u16(p, d + 4);
        if (!isQuery || qdCount < 1) return q;               // forward untouched

        // Read the first question name.
        StringBuilder sb = new StringBuilder();
        int i = d + 12;
        while (true) {
            if (i >= end) return q;
            int l = u8(p, i);
            if (l == 0) { i++; break; }
            if ((l & 0xc0) != 0) return q;                   // compression in a question: leave it
            if (i + 1 + l > end) return q;
            if (sb.length() > 0) sb.append('.');
            sb.append(new String(p, i + 1, l, StandardCharsets.US_ASCII));
            i += 1 + l;
        }
        if (i + 4 > end) return q;
        q.qtype = u16(p, i);
        q.questionEnd = i + 4;
        q.name = sb.toString().toLowerCase(java.util.Locale.ROOT);
        return q;
    }

    /** Builds a complete IP packet answering the query with NXDOMAIN ("no such site"). */
    public static byte[] buildBlockedResponse(byte[] p, Query q) {
        int qLen = q.questionEnd - q.dnsOffset;              // header + first question
        byte[] dns = new byte[qLen];
        System.arraycopy(p, q.dnsOffset, dns, 0, qLen);
        dns[2] = (byte) (0x80 | (dns[2] & 0x79));            // QR=1, keep opcode + RD
        dns[3] = (byte) 0x83;                                // RA=1, RCODE=3 (NXDOMAIN)
        put16(dns, 4, 1);                                    // one question
        put16(dns, 6, 0);
        put16(dns, 8, 0);
        put16(dns, 10, 0);
        return wrapResponse(q, dns, dns.length);
    }

    /** Wraps a DNS answer in UDP + IPv4 headers addressed back to whoever sent the query. */
    public static byte[] wrapResponse(Query q, byte[] dns, int dnsLen) {
        int total = 20 + 8 + dnsLen;
        byte[] o = new byte[total];
        o[0] = 0x45;
        put16(o, 2, total);
        o[6] = 0x40;                                         // don't fragment
        o[8] = 64;                                           // TTL
        o[9] = 17;                                           // UDP
        System.arraycopy(q.dstIp, 0, o, 12, 4);              // reply comes "from" the DNS address
        System.arraycopy(q.srcIp, 0, o, 16, 4);
        put16(o, 10, ipChecksum(o, 0, 20));
        put16(o, 20, q.dstPort);
        put16(o, 22, q.srcPort);
        put16(o, 24, 8 + dnsLen);
        // UDP checksum left at 0, which IPv4 allows.
        System.arraycopy(dns, 0, o, 28, dnsLen);
        return o;
    }

    static int ipChecksum(byte[] b, int off, int len) {
        long sum = 0;
        for (int i = off; i < off + len; i += 2) sum += u16(b, i);
        while ((sum >> 16) != 0) sum = (sum & 0xffff) + (sum >> 16);
        return (int) (~sum & 0xffff);
    }
}
