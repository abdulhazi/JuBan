package id.juban.app;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Indonesia's own blocklist, through the network's DNS.
 *
 * Indonesian ISPs must block the sites on Komdigi's TRUST+Positif list (millions of Ju sites)
 * in their DNS. JuBan normally asks Google's DNS, which does not, so it also asks the
 * network's own DNS and blocks what that one blocks.
 *
 * How a "blocked" answer is recognised: the network DNS answers a blocked name with the
 * address of its warning page, or with "no such site", while Google gives the real address.
 * Big sites can legitimately get different addresses from different DNS servers, so JuBan
 * first learns the warning page by asking about a few names that are surely on the list,
 * and only trusts an address that comes back for at least two different blocked names
 * (a warning page is shared by all of them; a real site's address never is).
 *
 * Pure Java (no Android imports) so it can be unit-tested on a desktop JVM.
 */
public final class IspCheck {

    /** Names that are surely on Indonesia's list (asked once per network, never opened). */
    public static final String[] PROBES = {
            "bet365.com", "1xbet.com", "sbobet.com", "pornhub.com", "xvideos.com", "stake.com"};

    /** An answer, reduced to what matters here. */
    public static final class Answer {
        public final int rcode;
        public final Set<String> addrs;
        public Answer(int rcode, Set<String> addrs) {
            this.rcode = rcode;
            this.addrs = addrs == null ? Collections.<String>emptySet() : addrs;
        }
        boolean resolves() { return rcode == 0 && !addrs.isEmpty(); }
        boolean noSuchSite() { return rcode == 3; }
    }

    private final Map<String, Set<String>> seenFor = new HashMap<>();   // warning-page candidate -> probe names
    private int nxProbes = 0;
    private volatile Set<String> blockAddrs = Collections.emptySet();
    private volatile boolean nxMeansBlocked = false;

    /** Learn from one probe: what the network DNS and Google said about a name on the list. */
    public synchronized void learn(String probe, Answer network, Answer google) {
        if (network == null || google == null || !google.resolves()) return;
        if (network.noSuchSite()) {
            if (++nxProbes >= 2) nxMeansBlocked = true;
            return;
        }
        if (!network.resolves() || !Collections.disjoint(network.addrs, google.addrs)) return;
        Set<String> trusted = new HashSet<>(blockAddrs);
        for (String a : network.addrs) {
            Set<String> probes = seenFor.get(a);
            if (probes == null) seenFor.put(a, probes = new HashSet<>());
            probes.add(probe);
            if (probes.size() >= 2) trusted.add(a);
        }
        blockAddrs = Collections.unmodifiableSet(trusted);
    }

    /** True once JuBan knows how this network's DNS answers a blocked name. */
    public boolean active() { return nxMeansBlocked || !blockAddrs.isEmpty(); }

    /** Forget everything (the phone moved to another network). */
    public synchronized void reset() {
        seenFor.clear();
        nxProbes = 0;
        blockAddrs = Collections.emptySet();
        nxMeansBlocked = false;
    }

    /** True if the network DNS blocks this name. */
    public boolean blocked(Answer network, Answer google) {
        if (network == null) return false;
        if (network.rcode == 0) {
            for (String a : network.addrs) if (blockAddrs.contains(a)) return true;
            return false;
        }
        return nxMeansBlocked && network.noSuchSite() && google != null && google.resolves();
    }

    /** Reads the result code and the A / AAAA addresses of a DNS answer. Null if unreadable. */
    public static Answer parse(byte[] m) {
        if (m == null || m.length < 12) return null;
        int rcode = m[3] & 0x0f;
        int qd = ((m[4] & 0xff) << 8) | (m[5] & 0xff);
        int an = ((m[6] & 0xff) << 8) | (m[7] & 0xff);
        int off = 12;
        for (int i = 0; i < qd; i++) {
            off = skipName(m, off);
            if (off < 0 || off + 4 > m.length) return new Answer(rcode, null);
            off += 4;
        }
        Set<String> addrs = new HashSet<>();
        for (int i = 0; i < an; i++) {
            off = skipName(m, off);
            if (off < 0 || off + 10 > m.length) break;
            int type = ((m[off] & 0xff) << 8) | (m[off + 1] & 0xff);
            int len = ((m[off + 8] & 0xff) << 8) | (m[off + 9] & 0xff);
            off += 10;
            if (off + len > m.length) break;
            if (type == 1 && len == 4) {
                addrs.add((m[off] & 0xff) + "." + (m[off + 1] & 0xff) + "." + (m[off + 2] & 0xff) + "." + (m[off + 3] & 0xff));
            } else if (type == 28 && len == 16) {
                StringBuilder sb = new StringBuilder();
                for (int j = 0; j < 16; j += 2) {
                    if (j > 0) sb.append(':');
                    sb.append(Integer.toHexString(((m[off + j] & 0xff) << 8) | (m[off + j + 1] & 0xff)));
                }
                addrs.add(sb.toString());
            }
            off += len;
        }
        return new Answer(rcode, addrs);
    }

    private static int skipName(byte[] m, int off) {
        while (off < m.length) {
            int l = m[off] & 0xff;
            if (l == 0) return off + 1;
            if ((l & 0xc0) == 0xc0) return off + 2 <= m.length ? off + 2 : -1;
            off += 1 + l;
        }
        return -1;
    }

    /** A standard query for one name (used for the probes). */
    public static byte[] query(int id, String name, int qtype) {
        java.io.ByteArrayOutputStream b = new java.io.ByteArrayOutputStream();
        b.write(id >> 8); b.write(id);
        b.write(0x01); b.write(0x00);               // recursion desired
        b.write(0); b.write(1);
        for (int i = 0; i < 6; i++) b.write(0);
        for (String l : name.split("\\.")) {
            if (l.isEmpty() || l.length() > 63) continue;
            b.write(l.length());
            for (char c : l.toCharArray()) b.write(c);
        }
        b.write(0);
        b.write(qtype >> 8); b.write(qtype);
        b.write(0); b.write(1);
        return b.toByteArray();
    }
}
