package id.juban.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.SystemClock;
import android.provider.Settings;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Saved settings, the user's own rules, the turn-off lock, and the bundled block list. */
final class Prefs {
    private static final String FILE = "juban";
    private static final String KEY_ENABLED = "enabled";
    private static final String KEY_SMART = "smart";
    private static final String KEY_PAGE = "page_check";
    private static final String KEY_BLOCK = "user_block";
    private static final String KEY_WORDS = "user_words";
    private static final String KEY_ALLOW = "user_allow";
    private static final String KEY_COUNT = "blocked_count";
    private static final String KEY_REQ_WALL = "off_request_wall";
    private static final String KEY_REQ_ELAPSED = "off_request_elapsed";
    private static final String KEY_REQ_BOOT = "off_request_boot";

    private Prefs() {}

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    // ---- protection on/off as chosen by the user (not whether the VPN happens to be up) ----

    static boolean enabled(Context c) { return sp(c).getBoolean(KEY_ENABLED, false); }
    static void setEnabled(Context c, boolean on) { sp(c).edit().putBoolean(KEY_ENABLED, on).apply(); }

    // ---- turn-off lock ----

    private static int bootCount(Context c) {
        try {
            return Settings.Global.getInt(c.getContentResolver(), Settings.Global.BOOT_COUNT, -1);
        } catch (RuntimeException e) {
            return -1;
        }
    }

    static void requestTurnOff(Context c) {
        sp(c).edit()
                .putLong(KEY_REQ_WALL, System.currentTimeMillis())
                .putLong(KEY_REQ_ELAPSED, SystemClock.elapsedRealtime())
                .putInt(KEY_REQ_BOOT, bootCount(c))
                .apply();
    }

    static void clearTurnOffRequest(Context c) {
        sp(c).edit().remove(KEY_REQ_WALL).remove(KEY_REQ_ELAPSED).remove(KEY_REQ_BOOT).apply();
    }

    static LockTimer lock(Context c) {
        SharedPreferences p = sp(c);
        long wall = p.getLong(KEY_REQ_WALL, 0);
        if (wall <= 0) return LockTimer.compute(0, 0, true, 0, 0);
        int boot = bootCount(c);
        boolean sameBoot = boot != -1 && boot == p.getInt(KEY_REQ_BOOT, -2);
        LockTimer t = LockTimer.compute(wall, p.getLong(KEY_REQ_ELAPSED, 0), sameBoot,
                System.currentTimeMillis(), SystemClock.elapsedRealtime());
        if (t.state == LockTimer.NONE) clearTurnOffRequest(c);       // expired
        return t;
    }

    /** True while settings that weaken protection must not be changed. */
    static boolean locked(Context c) {
        return enabled(c) && lock(c).state != LockTimer.OPEN;
    }

    // ---- rules ----

    static boolean smart(Context c) { return sp(c).getBoolean(KEY_SMART, true); }

    static boolean pageCheck(Context c) { return sp(c).getBoolean(KEY_PAGE, true); }
    static void setPageCheck(Context c, boolean on) { sp(c).edit().putBoolean(KEY_PAGE, on).apply(); }

    private static PageChecker checker;

    /** One page checker for the whole app, so verdicts are shared and loaded once. */
    static synchronized PageChecker pageChecker(Context c) {
        if (checker == null) {
            java.io.File dir = c.getApplicationContext().getFilesDir();
            java.io.File file = new java.io.File(dir, "verdicts2.txt");
            // 1.3 kept some sites as "clean" that should be checked again; keep only Ju verdicts.
            PageChecker.keepOnlyJu(new java.io.File(dir, "verdicts.txt"), file);
            checker = new PageChecker(file, null);
        }
        return checker;
    }
    static void setSmart(Context c, boolean on) { sp(c).edit().putBoolean(KEY_SMART, on).apply(); }

    static Set<String> userBlock(Context c) { return new HashSet<>(sp(c).getStringSet(KEY_BLOCK, new HashSet<String>())); }
    static Set<String> userWords(Context c) { return new HashSet<>(sp(c).getStringSet(KEY_WORDS, new HashSet<String>())); }
    static Set<String> userAllow(Context c) { return new HashSet<>(sp(c).getStringSet(KEY_ALLOW, new HashSet<String>())); }

    static void addBlock(Context c, String domain) {
        Set<String> block = userBlock(c);
        Set<String> allow = userAllow(c);
        block.add(domain);
        allow.remove(domain);
        sp(c).edit().putStringSet(KEY_BLOCK, block).putStringSet(KEY_ALLOW, allow).apply();
    }

    static void addWord(Context c, String word) {
        Set<String> words = userWords(c);
        words.add(word);
        sp(c).edit().putStringSet(KEY_WORDS, words).apply();
    }

    static void addAllow(Context c, String domain) {
        Set<String> block = userBlock(c);
        Set<String> allow = userAllow(c);
        allow.add(domain);
        block.remove(domain);
        sp(c).edit().putStringSet(KEY_BLOCK, block).putStringSet(KEY_ALLOW, allow).apply();
    }

    static void clearRules(Context c) {
        sp(c).edit().remove(KEY_BLOCK).remove(KEY_WORDS).remove(KEY_ALLOW).apply();
    }

    static long blockedCount(Context c) { return sp(c).getLong(KEY_COUNT, 0); }
    static void addBlocked(Context c) {
        SharedPreferences p = sp(c);
        p.edit().putLong(KEY_COUNT, p.getLong(KEY_COUNT, 0) + 1).apply();
    }

    static DomainMatcher buildMatcher(Context c) {
        List<String> listed = new ArrayList<>();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(
                c.getAssets().open("blocklist.txt"), StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) {
                line = line.trim().toLowerCase(java.util.Locale.ROOT);
                if (!line.isEmpty() && !line.startsWith("#")) listed.add(line);
            }
        } catch (IOException ignored) {
            // No list: smart detection and the user's own rules still work.
        }
        return new DomainMatcher(listed, userBlock(c), userWords(c), userAllow(c), smart(c));
    }
}
