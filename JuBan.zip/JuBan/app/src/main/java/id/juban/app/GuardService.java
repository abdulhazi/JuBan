package id.juban.app;

import android.accessibilityservice.AccessibilityService;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Toast;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Strict mode. While protection is locked (on, and the 24-hour wait has not passed), this
 * closes any system screen that could switch JuBan off: its App info page, the device admin
 * page, the uninstall dialog, its Accessibility switch and its VPN settings. See GuardRules
 * for exactly which screens. When the lock opens, it does nothing at all.
 *
 * It reads only system screens and keeps nothing it reads.
 */
public class GuardService extends AccessibilityService {

    private static final int MAX_NODES = 600;
    private static final int MAX_PAGE_NODES = 700;
    private static final int MAX_DEPTH = 60;
    private static final long READ_BUDGET_MS = 250;
    private static final long SCREEN_SCAN_MS = 2000;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private volatile boolean judging = false;
    private long lastScreenScan = 0;
    private long lastBlock = 0;
    private static final long BROWSER_LIST_MS = 5 * 60 * 1000;
    private Set<String> installedBrowsers = new HashSet<>();
    private long browsersAt = -BROWSER_LIST_MS;

    /**
     * Any app that can open a web link for a made-up address counts as a browser (Quetta, Kiwi,
     * Via, ...), not only the ones in the built-in list. Apps that only claim certain sites
     * (YouTube, Instagram, shops) do not match a made-up address, so they are not read.
     * The list is read from Android and refreshed every few minutes.
     */
    private boolean isBrowser(String pkg) {
        if (GuardRules.browser(pkg)) return true;
        long now = SystemClock.elapsedRealtime();
        if (now - browsersAt > BROWSER_LIST_MS) {
            browsersAt = now;
            Set<String> found = new HashSet<>();
            try {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://juban-probe-7f3a91.example/"));
                i.addCategory(Intent.CATEGORY_BROWSABLE);
                List<ResolveInfo> list = getPackageManager().queryIntentActivities(i, PackageManager.MATCH_ALL);
                for (ResolveInfo r : list) {
                    if (r.activityInfo != null) found.add(r.activityInfo.packageName);
                }
            } catch (RuntimeException ignored) { }
            found.remove(getPackageName());
            installedBrowsers = found;
        }
        return GuardRules.notShell(pkg) && installedBrowsers.contains(pkg);
    }

    /** True if the user has switched strict mode on in Android's Accessibility settings. */
    public static boolean isOn(Context c) {
        String list;
        try {
            list = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        } catch (RuntimeException e) {
            return false;
        }
        if (list == null) return false;
        String me = new ComponentName(c, GuardService.class).flattenToString();
        String shortMe = new ComponentName(c, GuardService.class).flattenToShortString();
        for (String s : list.split(":")) {
            if (s.equalsIgnoreCase(me) || s.equalsIgnoreCase(shortMe)) return true;
        }
        return false;
    }

    /**
     * Android switches a service off ("Not working") if it crashes or blocks for too long, so
     * nothing in here may throw, and slow work (scoring a page, saving a verdict) runs on a
     * separate thread.
     */
    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        try {
            handle(event);
        } catch (Throwable ignored) {
            // includes StackOverflowError / OutOfMemoryError from odd screens: skip this one
        }
    }

    private void handle(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        String pkg = event.getPackageName().toString();
        if (isBrowser(pkg)) {
            screenCheck();
            return;
        }
        boolean home = GuardRules.launcher(pkg);
        if (!home && !GuardRules.watched(pkg, getPackageName())) return;
        // On the home screen only new windows (a pop-up) matter, never scrolling or typing.
        if (home && event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        if (!Prefs.locked(this)) return;
        if (SystemClock.elapsedRealtime() - lastBlock < 800) return;

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        StringBuilder text = new StringBuilder();
        collect(root, text, MAX_NODES, null);
        boolean close = home ? GuardRules.launcherDialog(text.toString()) : GuardRules.dangerous(text.toString());
        if (!close) return;

        // Just step back out of that one screen or pop-up; never jump around the phone.
        lastBlock = SystemClock.elapsedRealtime();
        performGlobalAction(GLOBAL_ACTION_BACK);
        try {
            Toast.makeText(this, R.string.strict_blocked, Toast.LENGTH_LONG).show();
        } catch (RuntimeException ignored) { }
    }

    /**
     * Screen check: reads the page shown in a browser (on the phone only; nothing is kept)
     * and, if it is a Ju page, goes back and remembers the site so it is blocked from then on.
     */
    private void screenCheck() {
        if (judging || !Prefs.enabled(this) || !Prefs.screenCheck(this)) return;
        long now = SystemClock.elapsedRealtime();
        if (now - lastScreenScan < SCREEN_SCAN_MS || now - lastBlock < 1500) return;
        lastScreenScan = now;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        final StringBuilder text = new StringBuilder();
        final String[] host = {null};
        collect(root, text, MAX_PAGE_NODES, host);
        judging = true;
        worker.execute(new Runnable() {
            @Override public void run() {
                try {
                    judge(text.toString(), host[0]);
                } catch (Throwable ignored) {
                } finally {
                    judging = false;
                }
            }
        });
    }

    /** Runs on the worker thread. Goes back on the main thread only if the page is Ju. */
    private void judge(String text, final String host) {
        if (!ContentScorer.score(text).ju) return;
        if (host != null) {
            if (Prefs.buildMatcher(this).allowedByUser(host)) return;   // "Always allow" wins
            if (PageCheckPolicy.eligible(host, 1)) Prefs.pageChecker(this).markJu(host);
        }
        main.post(new Runnable() {
            @Override public void run() {
                try {
                    lastBlock = SystemClock.elapsedRealtime();
                    performGlobalAction(GLOBAL_ACTION_BACK);
                    BlockVpnService.noteScreenBlock(host != null ? host : "?");
                    Toast.makeText(GuardService.this, R.string.screen_blocked, Toast.LENGTH_SHORT).show();
                } catch (Throwable ignored) { }
            }
        });
    }

    /**
     * Reads the text on screen without recursion (web pages can be very deep), with limits on
     * the number of items, the depth and the time taken. If host is not null, it also picks the
     * site name out of the address bar.
     */
    private static void collect(AccessibilityNodeInfo root, StringBuilder out, int maxNodes, String[] host) {
        long until = SystemClock.elapsedRealtime() + READ_BUDGET_MS;
        ArrayDeque<AccessibilityNodeInfo> nodes = new ArrayDeque<>();
        ArrayDeque<Integer> depths = new ArrayDeque<>();
        nodes.add(root);
        depths.add(0);
        int seen = 0;
        while (!nodes.isEmpty() && seen++ < maxNodes) {
            if (SystemClock.elapsedRealtime() > until) break;
            AccessibilityNodeInfo node = nodes.poll();
            int depth = depths.poll();
            if (node == null) continue;
            try {
                CharSequence t = node.getText();
                if (t != null) {
                    out.append(t).append('\n');
                    if (host != null && host[0] == null) {
                        String id = node.getViewIdResourceName();
                        if (id != null && (id.contains("url") || id.contains("location_bar") || id.contains("address"))) {
                            host[0] = GuardRules.hostFromAddressBar(t.toString());
                        }
                    }
                }
                CharSequence d = node.getContentDescription();
                if (d != null) out.append(d).append('\n');
                if (depth < MAX_DEPTH) {
                    int n = node.getChildCount();
                    for (int i = 0; i < n; i++) {
                        AccessibilityNodeInfo c = node.getChild(i);
                        if (c != null) {
                            nodes.add(c);
                            depths.add(depth + 1);
                        }
                    }
                }
            } catch (RuntimeException ignored) {
                // a node that went away while reading: skip it
            }
        }
    }

    @Override
    public void onDestroy() {
        worker.shutdownNow();
        main.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    @Override
    public void onInterrupt() { }
}
