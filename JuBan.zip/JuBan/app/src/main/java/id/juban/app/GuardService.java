package id.juban.app;

import android.accessibilityservice.AccessibilityService;
import android.content.ComponentName;
import android.content.Context;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Toast;

/**
 * Strict mode. While protection is locked (on, and the 24-hour wait has not passed), this
 * closes any system screen that could switch JuBan off: its App info page, the device admin
 * page, the uninstall dialog, its Accessibility switch and its VPN settings. See GuardRules
 * for exactly which screens. When the lock opens, it does nothing at all.
 *
 * It reads only system screens and keeps nothing it reads.
 */
public class GuardService extends AccessibilityService {

    private static final int MAX_NODES = 600;
    private long lastBlock = 0;

    /** True if the user has switched strict mode on in Android's Accessibility settings. */
    public static boolean isOn(Context c) {
        String list;
        try {
            list = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        } catch (RuntimeException e) {
            return false;
        }
        if (list == null) return false;
        String me = new ComponentName(c, GuardService.class).flattenToString();
        String shortMe = new ComponentName(c, GuardService.class).flattenToShortString();
        for (String s : list.split(":")) {
            if (s.equalsIgnoreCase(me) || s.equalsIgnoreCase(shortMe)) return true;
        }
        return false;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        String pkg = event.getPackageName().toString();
        boolean home = GuardRules.launcher(pkg);
        if (!home && !GuardRules.watched(pkg, getPackageName())) return;
        // On the home screen only new windows (a pop-up) matter, never scrolling or typing.
        if (home && event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        if (!Prefs.locked(this)) return;
        if (SystemClock.elapsedRealtime() - lastBlock < 800) return;

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        StringBuilder text = new StringBuilder();
        collect(root, text, new int[]{0});
        boolean close = home ? GuardRules.launcherDialog(text.toString()) : GuardRules.dangerous(text.toString());
        if (!close) return;

        // Just step back out of that one screen or pop-up; never jump around the phone.
        lastBlock = SystemClock.elapsedRealtime();
        performGlobalAction(GLOBAL_ACTION_BACK);
        try {
            Toast.makeText(this, R.string.strict_blocked, Toast.LENGTH_LONG).show();
        } catch (RuntimeException ignored) { }
    }

    private static void collect(AccessibilityNodeInfo node, StringBuilder out, int[] count) {
        if (node == null || count[0]++ > MAX_NODES) return;
        CharSequence t = node.getText();
        if (t != null) out.append(t).append('\n');
        CharSequence d = node.getContentDescription();
        if (d != null) out.append(d).append('\n');
        for (int i = 0; i < node.getChildCount(); i++) {
            collect(node.getChild(i), out, count);
        }
    }

    @Override
    public void onInterrupt() { }
}
