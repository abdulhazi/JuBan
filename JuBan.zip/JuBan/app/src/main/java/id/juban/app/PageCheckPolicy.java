package id.juban.app;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Which site names are worth a page check. Phones look up hundreds of background names
 * (app servers, ad networks, picture servers); checking those would only add delay.
 *
 * Pure Java (no Android imports) so it can be unit-tested on a desktop JVM.
 */
public final class PageCheckPolicy {

    private PageCheckPolicy() {}

    /** Big, well-known sites and the services behind them. Subdomains are skipped too. */
    static final Set<String> SAFE = new HashSet<>(Arrays.asList(
            // Google, Apple, Microsoft, Samsung, Xiaomi and phone makers
            "google.com", "google.co.id", "googleapis.com", "gstatic.com", "googleusercontent.com",
            "googlevideo.com", "youtube.com", "ytimg.com", "ggpht.com", "gvt1.com", "gvt2.com",
            "android.com", "googlesyndication.com", "googleadservices.com", "doubleclick.net",
            "googletagmanager.com", "google-analytics.com", "app-measurement.com", "firebaseio.com",
            "firebaseapp.com", "crashlytics.com", "withgoogle.com", "blogger.com", "blogspot.com",
            "apple.com", "icloud.com", "mzstatic.com", "microsoft.com", "windows.com", "live.com",
            "office.com", "office.net", "msn.com", "bing.com", "azure.com", "azureedge.net",
            "windowsupdate.com", "skype.com", "outlook.com", "samsung.com", "samsungapps.com",
            "samsungcloud.com", "xiaomi.com", "xiaomi.net", "mi.com", "miui.com", "oppo.com",
            "heytapmobi.com", "vivo.com", "realme.com", "huawei.com", "hicloud.com",
            // social, messaging, video, music
            "facebook.com", "facebook.net", "fbcdn.net", "fb.com", "instagram.com", "cdninstagram.com",
            "whatsapp.com", "whatsapp.net", "messenger.com", "threads.net", "twitter.com", "x.com",
            "twimg.com", "t.co", "tiktok.com", "tiktokcdn.com", "tiktokv.com", "byteoversea.com",
            "ibytedtos.com", "ibyteimg.com", "capcut.com", "snapchat.com", "telegram.org", "t.me",
            "discord.com", "discordapp.com", "linkedin.com", "pinterest.com", "pinimg.com",
            "reddit.com", "redd.it", "redditmedia.com", "spotify.com", "scdn.co", "netflix.com",
            "nflxvideo.net", "vidio.com", "line.me", "line-scdn.net", "zoom.us",
            // infrastructure and content delivery
            "amazonaws.com", "cloudfront.net", "akamai.net", "akamaihd.net", "akamaized.net",
            "akamaiedge.net", "edgekey.net", "edgesuite.net", "cloudflare.com", "cloudflare.net",
            "fastly.net", "jsdelivr.net", "unpkg.com", "cdnjs.com", "bootstrapcdn.com",
            "gravatar.com", "wp.com", "wordpress.com", "github.com", "githubusercontent.com",
            "github.io", "gitlab.com", "stackoverflow.com", "sentry.io", "onesignal.com",
            "adjust.com", "appsflyer.com", "branch.io", "mixpanel.com", "segment.io",
            // AI and knowledge
            "claude.ai", "anthropic.com", "openai.com", "chatgpt.com", "gemini.google.com",
            "wikipedia.org", "wikimedia.org", "duolingo.com", "canva.com", "notion.so",
            // shopping, transport, payments, banks (Indonesia)
            "tokopedia.com", "tokopedia.net", "shopee.co.id", "shopee.com", "susercontent.com",
            "lazada.co.id", "lazada.com", "blibli.com", "bukalapak.com", "gojek.com", "gojekapi.com",
            "grab.com", "grabtaxi.com", "traveloka.com", "tiket.com", "dana.id", "ovo.id",
            "gopay.co.id", "linkaja.id", "bca.co.id", "klikbca.com", "bankmandiri.co.id",
            "bri.co.id", "bni.co.id", "btn.co.id", "cimbniaga.co.id", "jenius.com", "seabank.co.id",
            "telkomsel.com", "indosatooredoo.com", "xl.co.id", "smartfren.com", "indihome.co.id",
            // news (pages about Ju sites must not be blocked)
            "detik.com", "kompas.com", "kompas.id", "tribunnews.com", "liputan6.com",
            "cnnindonesia.com", "cnbcindonesia.com", "tempo.co", "antaranews.com", "okezone.com",
            "sindonews.com", "suara.com", "kumparan.com", "idntimes.com", "viva.co.id",
            "republika.co.id", "jawapos.com", "merdeka.com", "bisnis.com", "kontan.co.id",
            "katadata.co.id", "bbc.com", "bbc.co.uk", "cnn.com", "reuters.com", "nytimes.com",
            "theguardian.com"));

    /** Government, schools, universities and the military never host Ju sites on purpose. */
    static final String[] SAFE_ENDINGS = {".go.id", ".ac.id", ".sch.id", ".mil.id", ".gov", ".edu"};

    /** Names that are never a page someone visits. */
    static final Set<String> SKIP_TLDS = new HashSet<>(Arrays.asList(
            "local", "arpa", "lan", "home", "internal", "localhost", "localdomain", "test", "invalid"));

    /** First parts of names used by app servers and file servers, not websites. */
    static final Set<String> INFRA_FIRST = new HashSet<>(Arrays.asList(
            "api", "apis", "cdn", "static", "img", "images", "image", "assets", "media", "analytics",
            "metrics", "telemetry", "log", "logs", "push", "ws", "wss", "mqtt", "stun", "turn",
            "time", "ntp", "update", "updates", "download", "dl", "mtalk", "graph", "edge",
            "tracking", "track", "events", "collector", "sdk", "config", "connectivitycheck"));

    /** A, AAAA and HTTPS look-ups are what a browser makes before opening a page. */
    static boolean pageLookup(int qtype) {
        return qtype == 1 || qtype == 28 || qtype == 65;
    }

    public static boolean eligible(String host, int qtype) {
        if (host == null || !pageLookup(qtype)) return false;
        String h = host.toLowerCase(Locale.ROOT);
        if (h.endsWith(".")) h = h.substring(0, h.length() - 1);
        if (h.length() < 4 || h.length() > 253) return false;
        String[] labels = h.split("\\.");
        if (labels.length < 2) return false;
        if (SKIP_TLDS.contains(labels[labels.length - 1])) return false;
        if (h.matches("^[0-9.]+$")) return false;                      // an IP address
        if (labels.length > 2 && INFRA_FIRST.contains(labels[0])) return false;
        for (String e : SAFE_ENDINGS) if (h.endsWith(e)) return false;
        String d = h;
        while (true) {
            if (SAFE.contains(d)) return false;
            int dot = d.indexOf('.');
            if (dot < 0) return true;
            d = d.substring(dot + 1);
        }
    }
}
