package id.juban.app;

import java.util.Locale;

/**
 * Strict mode: which screens would switch JuBan off, and must be closed while the lock is on.
 *
 * Only system screens are looked at (Settings, the app installer, security centres), and
 * only when they mention JuBan together with a word for switching something off. Chats,
 * browsers and other apps are never looked at, so a message saying "uninstall JuBan" is
 * left alone.
 *
 * The home screen and app list are NOT checked like that: they show the JuBan icon next to
 * dozens of other labels, which made 1.5 close the home screen itself. There, only a small
 * pop-up asking to uninstall JuBan is closed (see launcherDialog).
 *
 * Pure Java (no Android imports) so it can be unit-tested on a desktop JVM.
 */
public final class GuardRules {

    private GuardRules() {}

    /** Exact packages of system screens on common phones (Pixel, Samsung, Xiaomi, Oppo, Vivo...). */
    static final String[] PACKAGES = {
            "com.android.settings", "com.google.android.packageinstaller", "com.android.packageinstaller",
            "com.miui.packageinstaller", "com.miui.securitycenter", "com.miui.securitycore",
            "com.coloros.safecenter",
            "com.oplus.safecenter", "com.vivo.permissionmanager", "com.huawei.systemmanager",
            "com.google.android.permissioncontroller", "com.android.permissioncontroller",
            "com.samsung.android.packageinstaller", "com.samsung.android.sm_cn", "com.samsung.android.lool",
    };

    /** Home screens. Only an uninstall pop-up is closed there. */
    static final String[] LAUNCHERS = {
            "com.miui.home", "com.mi.android.globallauncher", "com.sec.android.app.launcher",
            "com.google.android.apps.nexuslauncher", "com.android.launcher3", "com.oppo.launcher",
            "com.bbk.launcher2", "com.huawei.android.launcher",
    };

    /** Parts of package names that other phone makers use for the same screens. */
    static final String[] PACKAGE_PARTS = {
            "settings", "packageinstaller", "securitycenter", "safecenter", "permission",
            "systemmanager",
    };

    /** Words of an uninstall pop-up. */
    static final String[] UNINSTALL = {"uninstall", "uninstal", "hapus instalan", "copot"};

    /** A pop-up has a handful of lines; a home screen or app list has dozens. */
    static final int POPUP_MAX_LINES = 8;

    /** Words for switching something off, in English and Indonesian. */
    static final String[] DANGER = {
            // English
            "uninstall", "force stop", "deactivate", "device admin", "clear storage", "clear data",
            "use juban", "juban shortcut", "strict mode shortcut", "turn off", "disable", "forget", "disconnect",
            "always-on vpn", "remove",
            // Indonesian
            "copot", "uninstal", "hapus instalan", "paksa berhenti", "nonaktifkan", "admin perangkat",
            "hapus penyimpanan", "hapus data", "gunakan juban", "pintasan juban",
            "gunakan mode ketat", "pintasan mode ketat", "matikan",
            "lupakan", "putuskan", "vpn selalu aktif", "hapus",
    };

    /** Browsers, for the screen check (reads the page you are looking at). */
    static final String[] BROWSERS = {
            "com.android.chrome", "com.chrome.beta", "com.chrome.dev", "com.chrome.canary",
            "org.mozilla.firefox", "org.mozilla.firefox_beta", "org.mozilla.focus", "org.mozilla.fenix",
            "com.microsoft.emmx", "com.opera.browser", "com.opera.mini.native", "com.opera.gx",
            "com.brave.browser", "com.sec.android.app.sbrowser", "com.mi.globalbrowser",
            "com.android.browser", "com.UCMobile.intl", "com.uc.browser.en", "com.kiwibrowser.browser",
            "com.duckduckgo.mobile.android", "mark.via.gp", "com.vivaldi.browser",
            "com.yandex.browser", "com.huawei.browser", "com.heytap.browser", "com.vivo.browser",
            "com.google.android.googlequicksearchbox",
    };

    public static boolean browser(String pkg) {
        if (pkg == null) return false;
        for (String b : BROWSERS) if (b.equals(pkg)) return true;
        return false;
    }

    private static final java.util.regex.Pattern HOST = java.util.regex.Pattern.compile(
            "^(?:https?://)?([a-z0-9]([a-z0-9-]*[a-z0-9])?(\\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+)(?:[:/?#].*)?$");

    /** The site in a browser's address bar ("https://a.b.com/x" or "a.b.com/x"), or null. */
    public static String hostFromAddressBar(String text) {
        if (text == null) return null;
        java.util.regex.Matcher m = HOST.matcher(text.trim().toLowerCase(Locale.ROOT));
        if (!m.matches()) return null;
        String h = m.group(1);
        return h.startsWith("www.") ? h.substring(4) : h;
    }

    /** True for screens that belong to the system, not to ordinary apps. */
    public static boolean watched(String pkg, String ownPackage) {
        if (pkg == null || pkg.equals(ownPackage) || launcher(pkg)) return false;
        String p = pkg.toLowerCase(Locale.ROOT);
        for (String x : PACKAGES) if (p.equals(x)) return true;
        for (String x : PACKAGE_PARTS) if (p.contains(x)) return true;
        return false;
    }

    /** True for home-screen apps. */
    public static boolean launcher(String pkg) {
        if (pkg == null) return false;
        String p = pkg.toLowerCase(Locale.ROOT);
        for (String x : LAUNCHERS) if (p.equals(x)) return true;
        return p.contains("launcher");
    }

    /**
     * On a home screen: true only for a small pop-up that asks to uninstall JuBan
     * (some phones, Xiaomi included, ask from the home screen instead of the installer).
     */
    public static boolean launcherDialog(String screenText) {
        if (screenText == null) return false;
        String t = screenText.toLowerCase(Locale.ROOT);
        if (!t.contains("juban")) return false;
        int lines = 0;
        for (String l : t.split("\n")) if (!l.trim().isEmpty()) lines++;
        if (lines > POPUP_MAX_LINES) return false;
        // A real pop-up asks a question and has a Cancel button.
        if (!t.contains("?") || !(t.contains("cancel") || t.contains("batal"))) return false;
        for (String u : UNINSTALL) if (t.contains(u)) return true;
        return false;
    }

    /**
     * @param screenText all text on the screen
     * @return true if this screen could switch JuBan off or remove it
     */
    public static boolean dangerous(String screenText) {
        if (screenText == null) return false;
        String t = screenText.toLowerCase(Locale.ROOT);
        if (!t.contains("juban") && !t.contains("id.juban.app")) return false;
        for (String d : DANGER) if (t.contains(d)) return true;
        return false;
    }
}
