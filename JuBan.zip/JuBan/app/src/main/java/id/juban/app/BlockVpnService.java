package id.juban.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.net.VpnService;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.system.ErrnoException;
import android.system.Os;
import android.system.OsConstants;
import android.system.StructPollfd;

import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketTimeoutException;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 * A local "VPN" that never sends your traffic anywhere. It only becomes the phone's DNS
 * server: every time an app looks up a site name, the lookup arrives here. Blocked names
 * get the answer "no such site"; everything else is passed on to a normal DNS server.
 *
 * Page check: the first time an unknown site is looked up, JuBan opens its front page
 * (see PageChecker) and holds the answer for up to HOLD_MS. If the page turns out to be a
 * Ju site, the browser gets "no such site" even on that first visit.
 *
 * If protection is switched off from outside the app (Android's VPN settings) while the
 * user still wants it on, the service switches itself back on.
 */
public class BlockVpnService extends VpnService implements Runnable {

    public static final String ACTION_START = "id.juban.app.START";
    public static final String ACTION_STOP = "id.juban.app.STOP";
    public static final String ACTION_RELOAD = "id.juban.app.RELOAD";

    private static final String VPN_ADDRESS = "10.111.222.1";
    private static final String VPN_DNS = "10.111.222.2";
    private static final String[] UPSTREAM_DNS = {"8.8.8.8", "1.1.1.1"};
    private static final String CHANNEL = "protection";
    private static final String CHANNEL_ALERT = "alert";
    private static final int NOTIFICATION_ID = 1;
    private static final int ALERT_ID = 2;
    /** Longest a first visit to an unknown site waits for the page check. */
    private static final long HOLD_MS = 3000;

    /** True while protection is active. Read by the screen. */
    public static volatile boolean running = false;

    private static final ArrayDeque<String> RECENT = new ArrayDeque<>();
    private static String lastBlocked = "";
    private static long lastBlockedAt = 0;

    private ParcelFileDescriptor tun;
    private volatile FileOutputStream tunOut;
    private Thread thread;
    private ExecutorService pool;
    private volatile DomainMatcher matcher;
    private volatile boolean pageCheck;
    private volatile PageChecker checker;
    private final Handler main = new Handler(Looper.getMainLooper());

    /** Most recent blocked look-ups, newest first. */
    public static List<String> recent() {
        synchronized (RECENT) { return new ArrayList<>(RECENT); }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            // The screen only sends this once the turn-off delay has passed.
            if (!Prefs.enabled(this)) {
                stopVpn(true);
                stopSelf();
                return START_NOT_STICKY;
            }
            return START_STICKY;
        }
        if (ACTION_RELOAD.equals(action)) {
            if (running) {
                matcher = Prefs.buildMatcher(this);
                pageCheck = Prefs.pageCheck(this);
            }
            else stopSelf();
            return START_STICKY;
        }
        // ACTION_START, a restart by the system, or Android's "Always-on VPN".
        if (!ACTION_START.equals(action) && !Prefs.enabled(this)) {
            stopSelf();                              // the user turned protection off; stay off
            return START_NOT_STICKY;
        }
        startVpn();
        return START_STICKY;
    }

    private synchronized void startVpn() {
        showNotification();
        matcher = Prefs.buildMatcher(this);
        pageCheck = Prefs.pageCheck(this);
        checker = Prefs.pageChecker(this);
        if (thread != null) return;

        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE);
        try {
            Builder b = new Builder()
                    .setSession(getString(R.string.app_name))
                    .addAddress(VPN_ADDRESS, 32)
                    .addDnsServer(VPN_DNS)
                    .addRoute(VPN_DNS, 32)          // only DNS goes through us, nothing else
                    .setConfigureIntent(pi);
            if (Build.VERSION.SDK_INT >= 29) b.setMetered(false);
            // JuBan's own page checks must not come back through JuBan.
            try {
                b.addDisallowedApplication(getPackageName());
            } catch (PackageManager.NameNotFoundException ignored) { }
            tun = b.establish();
        } catch (Exception e) {
            tun = null;
        }
        if (tun == null) {                           // permission not granted (or revoked)
            stopForeground(true);
            if (Prefs.enabled(this)) showAlert();
            stopSelf();
            return;
        }
        clearAlert();
        tunOut = new FileOutputStream(tun.getFileDescriptor());
        pool = Executors.newFixedThreadPool(24);
        running = true;
        thread = new Thread(this, "juban-dns");
        thread.start();
    }

    private synchronized void stopVpn(boolean dropNotification) {
        running = false;
        Thread t = thread;
        thread = null;
        if (t != null) {
            try { t.join(2500); } catch (InterruptedException ignored) { }
        }
        if (pool != null) { pool.shutdownNow(); pool = null; }
        if (tun != null) {
            try { tun.close(); } catch (IOException ignored) { }
            tun = null;
        }
        tunOut = null;
        if (dropNotification) stopForeground(true);
    }

    /** Android calls this when the VPN is disconnected in Settings or another VPN takes over. */
    @Override
    public void onRevoke() {
        main.post(new Runnable() {
            @Override public void run() {
                if (!Prefs.enabled(BlockVpnService.this)) {
                    stopVpn(true);
                    stopSelf();
                    return;
                }
                stopVpn(false);
                // The user still wants protection: bring it straight back.
                main.postDelayed(new Runnable() {
                    @Override public void run() { restartAfterRevoke(); }
                }, 2000);
            }
        });
    }

    private void restartAfterRevoke() {
        if (running || !Prefs.enabled(this)) return;
        boolean allowed;
        try {
            allowed = VpnService.prepare(this) == null;
        } catch (RuntimeException e) {
            allowed = false;
        }
        if (allowed) {
            startVpn();                              // shows the alert itself if this fails
        } else {
            stopForeground(true);
            showAlert();
            stopSelf();
        }
    }

    @Override
    public void onDestroy() {
        main.removeCallbacksAndMessages(null);
        stopVpn(true);
        super.onDestroy();
    }

    /** Reads DNS look-ups from the tun device until protection is switched off. */
    @Override
    public void run() {
        FileDescriptor fd = tun.getFileDescriptor();
        StructPollfd pfd = new StructPollfd();
        pfd.fd = fd;
        pfd.events = (short) OsConstants.POLLIN;
        StructPollfd[] fds = {pfd};
        byte[] buf = new byte[32767];

        while (running) {
            try {
                if (Os.poll(fds, 1000) <= 0) continue;           // wake up every second to check "running"
                if ((pfd.revents & OsConstants.POLLIN) == 0) break;
                int n = Os.read(fd, buf, 0, buf.length);
                if (n <= 0) continue;
                handle(Arrays.copyOf(buf, n));
            } catch (ErrnoException e) {
                if (e.errno == OsConstants.EINTR || e.errno == OsConstants.EAGAIN) continue;
                break;
            } catch (IOException e) {
                break;
            } catch (RuntimeException e) {
                // One malformed packet must never take protection down.
            }
        }
    }

    private void handle(final byte[] packet) {
        final DnsPacket.Query q = DnsPacket.parse(packet, packet.length);
        if (q == null) return;

        final DomainMatcher m = matcher;
        boolean known = q.name != null && q.questionEnd > 0 && m != null;
        if (known && m.check(q.name) != null) {
            block(packet, q);
            return;
        }
        final PageChecker pc = checker;
        boolean checkPage = known && pageCheck && pc != null
                && PageCheckPolicy.eligible(q.name, q.qtype) && !m.allowedByUser(q.name);
        if (checkPage) {
            int v = pc.cached(q.name);
            if (v == PageChecker.JU) {
                block(packet, q);
                return;
            }
            checkPage = v == PageChecker.UNKNOWN;
        }
        final boolean firstVisit = checkPage;
        ExecutorService p = pool;
        if (p != null) {
            try {
                p.execute(new Runnable() {
                    @Override public void run() {
                        if (firstVisit) checkThenAnswer(packet, q, pc);
                        else forward(packet, q);
                    }
                });
            } catch (RuntimeException ignored) { }               // shutting down
        }
    }

    private void block(byte[] packet, DnsPacket.Query q) {
        write(DnsPacket.buildBlockedResponse(packet, q));
        recordBlocked(q.name);
    }

    /**
     * First visit to an unknown site: ask real DNS and read the site's front page at the
     * same time, and answer only when the page has been judged (or HOLD_MS has passed).
     */
    private void checkThenAnswer(byte[] packet, DnsPacket.Query q, PageChecker pc) {
        long start = System.currentTimeMillis();
        Future<Integer> verdict = pc.check(q.name);
        byte[] answer = exchange(packet, q);
        if (answer != null && answer.length >= 4 && (answer[3] & 0x0f) == 3) {
            write(DnsPacket.wrapResponse(q, answer, answer.length));   // the site does not exist anyway
            return;
        }
        int v = PageChecker.UNKNOWN;
        try {
            long wait = Math.max(0, HOLD_MS - (System.currentTimeMillis() - start));
            v = verdict.get(wait, TimeUnit.MILLISECONDS);
        } catch (Exception notYet) {
            // Not judged in time: let this visit through; the next one uses the verdict.
        }
        if (v == PageChecker.JU) {
            block(packet, q);
        } else if (answer != null) {
            write(DnsPacket.wrapResponse(q, answer, answer.length));
        }
    }

    /** Asks a real DNS server and hands its answer back to the app that asked. */
    private void forward(byte[] packet, DnsPacket.Query q) {
        byte[] answer = exchange(packet, q);
        if (answer != null) write(DnsPacket.wrapResponse(q, answer, answer.length));
    }

    /** Asks the real DNS servers in turn. @return the DNS answer, or null. */
    private byte[] exchange(byte[] packet, DnsPacket.Query q) {
        DatagramSocket socket = null;
        try {
            socket = new DatagramSocket();
            protect(socket);                                     // this socket must bypass the VPN
            socket.setSoTimeout(3000);
            byte[] answer = new byte[4096];
            for (String server : UPSTREAM_DNS) {
                try {
                    socket.send(new DatagramPacket(packet, q.dnsOffset, q.dnsLength,
                            InetAddress.getByName(server), 53));
                    DatagramPacket reply = new DatagramPacket(answer, answer.length);
                    socket.receive(reply);
                    return Arrays.copyOf(answer, reply.getLength());
                } catch (SocketTimeoutException tryNext) {
                    // fall through to the next server
                }
            }
        } catch (IOException ignored) {
            // No network right now; the app will simply retry its look-up.
        } finally {
            if (socket != null) socket.close();
        }
        return null;
    }

    private void write(byte[] ipPacket) {
        FileOutputStream out = tunOut;
        if (out == null || !running) return;
        synchronized (out) {
            try { out.write(ipPacket); } catch (IOException ignored) { }
        }
    }

    private void recordBlocked(String name) {
        long now = System.currentTimeMillis();
        synchronized (RECENT) {
            // A browser asks several times for the same name; count that as one block.
            if (name.equals(lastBlocked) && now - lastBlockedAt < 10000) return;
            lastBlocked = name;
            lastBlockedAt = now;
            String time = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date(now));
            RECENT.addFirst(time + "  " + name);
            while (RECENT.size() > 30) RECENT.removeLast();
        }
        Prefs.addBlocked(this);
    }

    private void showNotification() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(
                    CHANNEL, getString(R.string.channel_name), NotificationManager.IMPORTANCE_LOW));
            Intent open = new Intent(this, MainActivity.class);
            PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE);
            Notification n = new Notification.Builder(this, CHANNEL)
                    .setSmallIcon(R.drawable.ic_shield)
                    .setContentTitle(getString(R.string.notif_title))
                    .setContentText(getString(R.string.notif_text))
                    .setContentIntent(pi)
                    .setOngoing(true)
                    .build();
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED);
            } else {
                startForeground(NOTIFICATION_ID, n);
            }
        } catch (RuntimeException e) {
            // Blocking still works without the notification.
        }
    }

    /** Tells the user protection went off without their say-so and offers the way back. */
    private void showAlert() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(
                    CHANNEL_ALERT, getString(R.string.channel_alert), NotificationManager.IMPORTANCE_DEFAULT));
            Intent open = new Intent(this, MainActivity.class);
            PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE);
            nm.notify(ALERT_ID, new Notification.Builder(this, CHANNEL_ALERT)
                    .setSmallIcon(R.drawable.ic_shield)
                    .setContentTitle(getString(R.string.alert_title))
                    .setContentText(getString(R.string.alert_text))
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .build());
        } catch (RuntimeException ignored) { }
    }

    private void clearAlert() {
        try {
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).cancel(ALERT_ID);
        } catch (RuntimeException ignored) { }
    }
}
