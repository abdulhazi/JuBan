import id.juban.app.LockTimer;

/** Desktop test for the turn-off delay. */
public class LockTest {
    static int failures = 0;
    static void check(boolean ok, String what) { if (!ok) { failures++; System.out.println("FAIL: " + what); } }

    public static void main(String[] a) {
        final long H = 3600_000L, D = LockTimer.DELAY_MS, W = LockTimer.WINDOW_MS;
        long t0 = 1_800_000_000_000L, e0 = 5 * H;

        check(LockTimer.compute(0, 0, true, t0, e0).state == LockTimer.NONE, "no request");

        LockTimer l = LockTimer.compute(t0, e0, true, t0 + H, e0 + H);
        check(l.state == LockTimer.WAITING && l.remainingMs == D - H, "waiting after 1h");

        l = LockTimer.compute(t0, e0, true, t0 + D, e0 + D);
        check(l.state == LockTimer.OPEN && l.remainingMs == W, "opens exactly at the delay");

        l = LockTimer.compute(t0, e0, true, t0 + D + W, e0 + D + W);
        check(l.state == LockTimer.NONE, "expires after the window");

        // Clock pushed forward two days, phone not restarted: still waiting.
        l = LockTimer.compute(t0, e0, true, t0 + 48 * H, e0 + 10 * 60_000);
        check(l.state == LockTimer.WAITING, "moving the clock forward does not unlock");

        // Phone restarted: falls back to the clock.
        l = LockTimer.compute(t0, e0, false, t0 + D + 60_000, 2 * 60_000);
        check(l.state == LockTimer.OPEN, "after restart uses clock time");
        l = LockTimer.compute(t0, e0, false, t0 + 2 * H, 2 * 60_000);
        check(l.state == LockTimer.WAITING && l.remainingMs == D - 2 * H, "after restart still waiting");

        // Clock moved backwards after a restart: never negative.
        l = LockTimer.compute(t0, e0, false, t0 - 5 * H, 60_000);
        check(l.state == LockTimer.WAITING && l.remainingMs == D, "clock moved back");

        System.out.println(failures == 0 ? "LOCK TESTS PASSED" : failures + " FAILURE(S)");
        System.exit(failures == 0 ? 0 : 1);
    }
}
