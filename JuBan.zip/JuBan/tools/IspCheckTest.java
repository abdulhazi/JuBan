import id.juban.app.IspCheck;

import java.io.ByteArrayOutputStream;
import java.util.Arrays;
import java.util.HashSet;

/** Desktop test for the Indonesia's-list check. No arguments. */
public class IspCheckTest {
    static int failures = 0;
    static void check(boolean ok, String what) { if (!ok) { failures++; System.out.println("FAIL: " + what); } }

    static IspCheck.Answer a(int rcode, String... addrs) { return new IspCheck.Answer(rcode, new HashSet<>(Arrays.asList(addrs))); }

    /** A real DNS answer with compression pointers, to test parsing. */
    static byte[] answer(String name, int rcode, int[]... ipv4s) {
        byte[] q = IspCheck.query(0x1234, name, 1);
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        b.write(q, 0, q.length);
        byte[] m = b.toByteArray();
        m[2] = (byte) 0x81; m[3] = (byte) (0x80 | rcode);
        m[7] = (byte) ipv4s.length;
        b = new ByteArrayOutputStream();
        b.write(m, 0, m.length);
        for (int[] ip : ipv4s) {
            b.write(0xc0); b.write(12);              // name: pointer to the question
            b.write(0); b.write(1); b.write(0); b.write(1);
            b.write(0); b.write(0); b.write(0); b.write(60);
            b.write(0); b.write(4);
            for (int x : ip) b.write(x);
        }
        return b.toByteArray();
    }

    public static void main(String[] args) {
        // Parsing.
        IspCheck.Answer p = IspCheck.parse(answer("situs.example", 0, new int[]{36, 86, 63, 185}, new int[]{10, 0, 0, 1}));
        check(p != null && p.rcode == 0 && p.addrs.contains("36.86.63.185") && p.addrs.size() == 2, "parse A records " + (p == null ? null : p.addrs));
        IspCheck.Answer nx = IspCheck.parse(answer("nothing.example", 3));
        check(nx != null && nx.rcode == 3 && nx.addrs.isEmpty(), "parse no such site");
        check(IspCheck.parse(new byte[]{1, 2, 3}) == null, "parse junk");

        // A network that answers blocked names with its warning page 36.86.63.185.
        IspCheck c = new IspCheck();
        check(!c.active(), "not active before learning");
        c.learn("bet365.com", a(0, "36.86.63.185"), a(0, "5.226.180.10"));
        check(!c.active(), "one probe is not enough (could be a CDN difference)");
        c.learn("pornhub.com", a(0, "36.86.63.185"), a(0, "66.254.114.41"));
        check(c.active(), "two probes agree: warning page learnt");
        check(c.blocked(a(0, "36.86.63.185"), a(0, "104.21.5.5")), "Ju site on Indonesia's list is blocked");
        check(!c.blocked(a(0, "142.250.4.100"), a(0, "142.250.4.101")), "normal site with a different CDN address is fine");
        check(!c.blocked(a(3), a(0, "1.2.3.4")), "no-such-site is not a block on this network");

        // A CDN difference for ONE probe must never become a warning page.
        IspCheck d = new IspCheck();
        d.learn("bet365.com", a(0, "23.1.1.1"), a(0, "23.9.9.9"));     // CDN in Jakarta vs elsewhere
        d.learn("pornhub.com", a(0, "36.86.63.185"), a(0, "66.254.114.41"));
        d.learn("xvideos.com", a(0, "36.86.63.185"), a(0, "185.88.181.2"));
        check(d.active() && !d.blocked(a(0, "23.1.1.1"), a(0, "23.9.9.9")), "CDN address seen once is not trusted");
        check(d.blocked(a(0, "36.86.63.185"), null), "warning page trusted after two probes");

        // A network that says "no such site" for blocked names.
        IspCheck e = new IspCheck();
        e.learn("bet365.com", a(3), a(0, "5.226.180.10"));
        check(!e.active(), "one no-such-site probe is not enough");
        e.learn("1xbet.com", a(3), a(0, "104.18.1.1"));
        check(e.active(), "two no-such-site probes: learnt");
        check(e.blocked(a(3), a(0, "104.21.9.9")), "blocked: network says no such site, Google resolves it");
        check(!e.blocked(a(3), a(3)), "really does not exist: not counted as a block");

        // A network that does not filter at all (same answers as Google).
        IspCheck f = new IspCheck();
        for (String probe : IspCheck.PROBES) f.learn(probe, a(0, "5.5.5.5"), a(0, "5.5.5.5"));
        check(!f.active() && !f.blocked(a(0, "5.5.5.5"), a(0, "5.5.5.5")), "unfiltered network: inactive");

        c.reset();
        check(!c.active(), "reset when the network changes");

        System.out.println(failures == 0 ? "ISP CHECK TESTS PASSED" : failures + " FAILURE(S)");
        System.exit(failures == 0 ? 0 : 1);
    }
}
