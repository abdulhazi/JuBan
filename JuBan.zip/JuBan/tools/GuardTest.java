import id.juban.app.GuardRules;

/** Desktop test for strict mode's screen rules. No arguments. */
public class GuardTest {
    static int failures = 0;
    static void check(boolean ok, String what) { if (!ok) { failures++; System.out.println("FAIL: " + what); } }

    public static void main(String[] a) {
        String me = "id.juban.app";

        // Which apps are looked at at all.
        for (String p : new String[]{"com.android.settings", "com.miui.securitycenter", "com.miui.packageinstaller",
                "com.google.android.packageinstaller", "com.samsung.android.packageinstaller",
                "com.oplus.safecenter", "com.android.permissioncontroller"}) {
            check(GuardRules.watched(p, me), "should watch " + p);
        }
        for (String p : new String[]{"com.whatsapp", "com.android.chrome", "com.anthropic.claude",
                "com.android.systemui", "com.instagram.android", me, null,
                // home screens are handled separately (pop-ups only)
                "com.miui.home", "com.transsion.XOSLauncher", "com.google.android.apps.nexuslauncher"}) {
            check(!GuardRules.watched(p, me), "should ignore " + p);
        }

        // Screens that must be closed while locked (English and Indonesian, Pixel and Xiaomi wording).
        String[] closeThese = {
                "App info\nJuBan\nversion 1.5\nOpen\nUninstall\nForce stop\nNotifications\nPermissions",
                "Info aplikasi\nJuBan\nBuka\nCopot pemasangan\nPaksa berhenti\nNotifikasi",
                "JuBan\nDo you want to uninstall this app?\nCancel\nOK",
                "Hapus instalan JuBan?\nBatal\nHapus instalan",
                "Device admin apps\nActivate this device admin app?\nJuBan\nDeactivate this device admin app",
                "Aplikasi admin perangkat\nJuBan\nNonaktifkan aplikasi admin perangkat ini",
                "JuBan strict mode\nUse JuBan strict mode\nJuBan strict mode shortcut\nSettings",
                "Mode ketat JuBan\nGunakan Mode ketat JuBan\nPintasan Mode ketat JuBan",
                "JuBan\nAlways-on VPN\nBlock connections without VPN\nForget VPN",
                "JuBan\nVPN selalu aktif\nLupakan VPN",
                "Manage apps\nJuBan\n12 MB\nUninstall",                                  // Xiaomi app manager
                "JuBan\nStorage & cache\nClear storage\nClear cache",
        };
        for (String s : closeThese) check(GuardRules.dangerous(s), "should close: " + s.replace('\n', '|'));

        // Screens that must stay open.
        String[] leaveThese = {
                "Wi-Fi\nHome-5G\nConnected\nForget\nSaved networks",                      // no JuBan on it
                "Network & internet\nVPN\nJuBan\nConnected",                             // VPN list, no off words
                "Accessibility\nDownloaded apps\nJuBan strict mode\nOn\nTalkBack",        // list page, no off words
                "Battery\nJuBan\n2% since last full charge",
                "Display\nBrightness\nDark theme\nTurn off automatically",                // off word, no JuBan
                "",
        };
        for (String s : leaveThese) check(!GuardRules.dangerous(s), "should leave open: " + s.replace('\n', '|'));

        // Home screens: the 1.5 bug. Never close a home screen or app list, whatever is on it.
        check(GuardRules.launcher("com.miui.home") && GuardRules.launcher("com.transsion.XOSLauncher"), "launchers");
        String homeScreen = "Clock\nCalendar\nJuBan\nSettings\nPlay Store\nCamera\nGallery\nWhatsApp\n"
                + "Instagram\nFile Manager\nCleaner\nRemove ads\nUninstall unused apps\nSecurity\nThemes\nSearch apps";
        check(!GuardRules.launcherDialog(homeScreen), "home screen must stay usable");
        check(!GuardRules.launcherDialog("Search apps\nju\nJuBan\nJuBan Lite\nYouTube Music\nJupiter\nJust Dance\nUninstall"),
                "typing a search in the app list must stay usable");
        check(GuardRules.launcherDialog("Uninstall \u201cJuBan\u201d?\nCancel\nUninstall"), "Xiaomi home-screen uninstall pop-up");
        check(GuardRules.launcherDialog("Hapus instalan JuBan?\nBatal\nHapus instalan"), "Indonesian pop-up");
        check(!GuardRules.launcherDialog("JuBan\nApp info\nWidgets\nEdit"), "long-press menu without uninstall stays");

        System.out.println(failures == 0 ? "GUARD TESTS PASSED" : failures + " FAILURE(S)");
        System.exit(failures == 0 ? 0 : 1);
    }
}
