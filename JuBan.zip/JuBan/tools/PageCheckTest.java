import com.sun.net.httpserver.HttpServer;
import id.juban.app.ContentScorer;
import id.juban.app.PageCheckPolicy;
import id.juban.app.PageChecker;

import java.io.File;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/** Desktop test for the page check. No arguments. */
public class PageCheckTest {
    static int failures = 0;
    static void check(boolean ok, String what) { if (!ok) { failures++; System.out.println("FAIL: " + what); } }

    // Modelled on real pages seen on 14 Nov 2026 (titles and menu items).
    static final String KANGTOTO = "<html><head><title>Daftar Agen Situs Toto Togel Online Resmi - Kangtoto</title>"
            + "<meta name=\"description\" content=\"Ayo daftar agen toto togel online sekarang juga di situs Kangtoto, link resmi togel\">"
            + "</head><body><nav>PAY4D TOGEL PAY4D KUPON PRAGMATIC PLAY PG SOFT JILI MEGAWIN HABANERO SPADEGAMING "
            + "LIVE CASINO SPORT SABUNG ARCADE BERANDA PROMOSI EVENT LIVECHAT</nav><a>Masuk</a><a>Daftar Sekarang</a></body></html>";
    static final String HSS = "<html><head><title>HSS303 - SITUS PROGRAM BANDAR JUDI RESMI LIVE CASINO ONLINE TERPERCAYA HARI INI 2026</title>"
            + "</head><body><h1>HSS303</h1><a>DOWNLOAD APK HSS303 FREE CHIP RP 5.000</a><a>MASUK LOGIN HSS303 NOW!</a>"
            + "<a>GABUNG DAFTAR AKUN GACOR SEKARANG JUGA!!</a></body></html>";
    // A slot page whose text is mostly drawn by scripts: only the title and a few words remain.
    static final String THIN = "<html><head><title>SLOT GACOR Hari Ini | Link Situs Slot88 Maxwin</title>"
            + "<script>var x = 'lots of code';</script></head><body><div id=app></div></body></html>";
    // Seen 15 Nov 2026 on alexiscaelum.com / alexisrora.com (names with nothing suspicious in them).
    static final String ALEXIS = "<html><head><title>ALEXISTOGEL \u2668 Platform Agen Resmi Situs Game Online Toto Togel 4D Amanah Tentu Bayar</title>"
            + "</head><body><a>LOGIN</a><a>DAFTAR</a> Situs TOGEL ONLINE MIN DEPO 5K | MINIMAL WD 25K "
            + "Cara Bermain History Nomor Buku Mimpi Referral Promosi Prediksi Togel Live RTP Gacor "
            + "TURNOVER CASINO &amp; SLOT BULANAN LINK ALTERNATIF</body></html>";
    static final String NEWS = "<html><head><title>Satgas Berantas Judi Online, 1.000 Situs Slot Diblokir Komdigi</title></head>"
            + "<body><p>Kementerian Komunikasi dan Digital bersama Polri memblokir situs judi online dan slot gacor. "
            + "Para tersangka ditangkap. Redaksi.</p></body></html>";
    static final String SHOP = "<html><head><title>Toko Sepatu Murah - Daftar dan Login untuk Bonus Member</title></head>"
            + "<body>Daftar sekarang, dapat bonus member baru. Promosi akhir tahun. Login. Hadiah menarik. "
            + "Sepatu lari, sepatu sekolah dan sandal untuk seluruh keluarga dengan harga terjangkau. "
            + "Gratis ongkir ke seluruh Indonesia untuk pembelian di atas seratus ribu rupiah. Hubungi kami.</body></html>";
    static final String RESTAURANT = "<html><head><title>Manhattan Restaurant Olsztyn</title></head><body>"
            + "Welcome to our restaurant in the heart of the old town. Steaks, burgers, salads and desserts, "
            + "freshly prepared every day. Book a table for your family dinner or business lunch. "
            + "Open Monday to Sunday from noon until ten in the evening. Contact and reservations below.</body></html>";
    static final String CHALLENGE = "<html><head><title>Just a moment...</title></head><body>"
            + "Checking your browser before accessing the site. Enable JavaScript and cookies to continue."
            + "<script src=\"/cdn-cgi/challenge-platform/h/b/orchestrate/chl_page/v1\"></script></body></html>";
    static final String RECAPTCHA_SHOP = SHOP.replace("</body>",
            "<script src=\"https://www.google.com/recaptcha/api.js\"></script> Just a moment of your time: fill in the form.</body>");
    static final String TIME_SLOTS = "<html><head><title>Book a time slot - Dentist Jakarta</title></head>"
            + "<body>Choose a slot. Login to manage bookings. Member discount. Jackpot of savings!</body></html>";
    static final String PLACEHOLDER = "<html><head><title>Site is created successfully!</title></head>"
            + "<body>Congratulations, the site is created successfully!</body></html>";
    static final String GAME_STORE = "<html><head><title>Board games: poker chips, roulette sets and blackjack tables</title></head>"
            + "<body>Buy a poker set. Casino night party kit. Free delivery.</body></html>";

    public static void main(String[] a) throws Exception {
        // ---- scoring ----
        check(ContentScorer.score(KANGTOTO).ju, "kangtoto page " + ContentScorer.score(KANGTOTO));
        check(ContentScorer.score(HSS).ju, "hss303 page " + ContentScorer.score(HSS));
        check(ContentScorer.score(THIN).ju, "script-drawn page " + ContentScorer.score(THIN));
        check(ContentScorer.score(ALEXIS).ju, "alexistogel page " + ContentScorer.score(ALEXIS));
        check(!ContentScorer.score(NEWS).ju, "news article " + ContentScorer.score(NEWS));
        check(!ContentScorer.score(SHOP).ju, "shop " + ContentScorer.score(SHOP));
        check(!ContentScorer.score(TIME_SLOTS).ju, "time slot booking " + ContentScorer.score(TIME_SLOTS));
        check(!ContentScorer.score(PLACEHOLDER).ju, "placeholder");
        check(!ContentScorer.score(GAME_STORE).ju, "board game store " + ContentScorer.score(GAME_STORE));
        check(!ContentScorer.score("").ju && !ContentScorer.score(null).ju, "empty");
        check(ContentScorer.unreadable(CHALLENGE, ContentScorer.score(CHALLENGE)), "protection screen is unreadable");
        check(ContentScorer.unreadable(THIN.replace("SLOT GACOR Hari Ini | Link Situs Slot88 Maxwin", ""),
                ContentScorer.score(THIN.replace("SLOT GACOR Hari Ini | Link Situs Slot88 Maxwin", ""))), "empty script page is unreadable");
        check(!ContentScorer.unreadable(SHOP, ContentScorer.score(SHOP)), "shop is readable");
        check(!ContentScorer.unreadable(RECAPTCHA_SHOP, ContentScorer.score(RECAPTCHA_SHOP)), "shop with a form check is readable");
        check(!ContentScorer.unreadable(THIN, ContentScorer.score(THIN)), "a Ju page is never 'unreadable'");
        check("https://next.example/x".equals(ContentScorer.findRedirect(
                "<meta http-equiv=\"refresh\" content=\"0; url=https://next.example/x\">")), "meta refresh");
        check("https://next.example/".equals(ContentScorer.findRedirect(
                "<script>window.location.href = 'https://next.example/';</script>")), "script redirect");

        // ---- which names get checked ----
        check(PageCheckPolicy.eligible("4.kangtotorace.com", 1), "policy: unknown site");
        check(PageCheckPolicy.eligible("pumpkinhss303.it.com", 28), "policy: AAAA");
        check(!PageCheckPolicy.eligible("www.google.com", 1), "policy: google");
        check(!PageCheckPolicy.eligible("rr3---sn-abc.googlevideo.com", 1), "policy: video server");
        check(!PageCheckPolicy.eligible("news.detik.com", 1), "policy: news");
        check(!PageCheckPolicy.eligible("kemdikbud.go.id", 1), "policy: government");
        check(!PageCheckPolicy.eligible("api.someapp.com", 1), "policy: app server");
        check(!PageCheckPolicy.eligible("example.com", 16), "policy: TXT lookup");
        check(!PageCheckPolicy.eligible("printer.local", 1), "policy: local");
        check(!PageCheckPolicy.eligible("192.168.1.1", 1), "policy: ip");

        // ---- the real fetcher against a local web server ----
        HttpServer srv = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        srv.createContext("/", ex -> {
            String host = ex.getRequestHeaders().getFirst("Host");
            String path = ex.getRequestURI().getPath();
            String body;
            int code = 200;
            if (path.equals("/ju")) body = KANGTOTO;
            else if (path.equals("/hop")) { code = 302; ex.getResponseHeaders().add("Location", "/ju"); body = ""; }
            else if (path.equals("/refresh")) body = "<meta http-equiv=refresh content=\"0;url=/ju\">";
            else if (path.equals("/shop")) body = SHOP;
            else if (path.equals("/cloaked")) {
                String ref = ex.getRequestHeaders().getFirst("Referer");
                body = ref != null && ref.contains("google.") ? HSS : RESTAURANT;   // Ju page only for Google visitors
            }
            else if (path.equals("/challenge")) { code = 403; body = CHALLENGE; }
            else if (path.equals("/challenge200")) body = CHALLENGE;
            else if (path.equals("/error")) { code = 503; body = RESTAURANT; }
            else { code = 404; body = "not found"; }
            byte[] b = body.getBytes(StandardCharsets.UTF_8);
            ex.getResponseHeaders().add("Content-Type", "text/html; charset=utf-8");
            ex.sendResponseHeaders(code, b.length == 0 ? -1 : b.length);
            if (b.length > 0) try (OutputStream o = ex.getResponseBody()) { o.write(b); }
            ex.close();
        });
        srv.start();
        String base = "http://127.0.0.1:" + srv.getAddress().getPort();
        PageChecker.HttpFetcher http = new PageChecker.HttpFetcher();
        PageChecker.Page p = http.fetch(base + "/hop");
        check(p != null && p.finalUrl.endsWith("/ju") && p.html.contains("Kangtoto"), "follows redirects");
        check(http.fetch("http://127.0.0.1:1/") == null, "unreachable returns null");

        // ---- verdicts, forwarding pages, memory ----
        File f = File.createTempFile("verdicts", ".txt");
        f.delete();
        final String b = base;
        PageChecker.Fetcher routed = url -> {
            String host = url.replaceFirst("^https?://", "").replaceFirst("/.*$", "");
            if (url.startsWith("https://")) return null;                       // no TLS here: fall back to http
            switch (host) {
                case "ju.test": return http.fetch(b + "/ju");
                case "hop.test": return http.fetch(b + "/hop");
                case "refresh.test": {
                    PageChecker.Page r = http.fetch(b + "/refresh");
                    return r == null ? null : new PageChecker.Page(r.html, b + "/refresh");
                }
                case "shop.test": return http.fetch(b + "/shop");
                case "cloaked.test": return http.fetch(b + "/cloaked");
                case "challenge.test": return http.fetch(b + "/challenge");
                case "challenge200.test": return http.fetch(b + "/challenge200");
                case "error.test": return http.fetch(b + "/error");
                default: return host.startsWith("127.0.0.1") ? http.fetch(url) : null;
            }
        };
        final int[] told = {0};
        PageChecker pc = new PageChecker(f, routed);
        pc.setListener((host, why) -> told[0]++);
        check(pc.check("ju.test").get(5, TimeUnit.SECONDS) == PageChecker.JU, "ju.test");
        check(pc.check("hop.test").get(5, TimeUnit.SECONDS) == PageChecker.JU, "hop.test via redirect");
        check(pc.check("refresh.test").get(5, TimeUnit.SECONDS) == PageChecker.JU, "refresh.test via meta refresh");
        check(pc.check("shop.test").get(5, TimeUnit.SECONDS) == PageChecker.CLEAN, "shop.test clean");
        check(pc.check("gone.test").get(5, TimeUnit.SECONDS) == PageChecker.FAILED, "gone.test failed");
        check(pc.cached("ju.test") == PageChecker.JU && pc.cached("shop.test") == PageChecker.CLEAN, "cached");
        check(pc.check("cloaked.test").get(5, TimeUnit.SECONDS) == PageChecker.JU, "hacked site that hides its Ju page from direct visitors");
        check(pc.check("challenge.test").get(5, TimeUnit.SECONDS) == PageChecker.FAILED, "403 protection screen is not clean");
        check(pc.check("challenge200.test").get(5, TimeUnit.SECONDS) == PageChecker.FAILED, "protection screen is not clean");
        check(pc.check("error.test").get(5, TimeUnit.SECONDS) == PageChecker.FAILED, "error page is not clean");
        check(pc.juCount() == 4 && told[0] == 4, "ju count " + pc.juCount() + " told " + told[0]);

        Future<Integer> x = pc.check("shop2.test"), y = pc.check("shop2.test");
        check(x == y || y.isDone(), "same host checked once");

        // Verdicts survive a restart; clean ones expire after 7 days, Ju ones never.
        PageChecker again = new PageChecker(f, routed);
        check(again.cached("ju.test") == PageChecker.JU && again.juCount() == 4, "kept after restart");
        again.setClockForTest(System.currentTimeMillis() + 8L * 24 * 3600 * 1000);
        check(again.cached("shop.test") == PageChecker.UNKNOWN, "clean expires");
        check(again.cached("ju.test") == PageChecker.JU, "ju never expires");
        again.forget("ju.test");
        check(again.cached("ju.test") == PageChecker.CLEAN && again.juCount() == 3, "forget");

        // Upgrading from 1.3: keep Ju verdicts, drop "clean" ones so those sites are re-checked.
        File old = File.createTempFile("old", ".txt"), neu = File.createTempFile("new", ".txt");
        neu.delete();
        java.nio.file.Files.write(old.toPath(), ("a.test 1 " + Long.MAX_VALUE + "\nb.test 2 " + Long.MAX_VALUE
                + "\nc.test 3 " + Long.MAX_VALUE + "\n").getBytes(StandardCharsets.UTF_8));
        PageChecker.keepOnlyJu(old, neu);
        PageChecker up = new PageChecker(neu, routed);
        check(!old.exists() && up.cached("a.test") == PageChecker.JU && up.cached("b.test") == PageChecker.UNKNOWN
                && up.cached("c.test") == PageChecker.UNKNOWN && up.juCount() == 1, "upgrade keeps only Ju verdicts");
        up.shutdown();
        neu.delete();

        srv.stop(0);
        pc.shutdown();
        again.shutdown();
        f.delete();
        System.out.println(failures == 0 ? "PAGE CHECK TESTS PASSED" : failures + " FAILURE(S)");
        System.exit(failures == 0 ? 0 : 1);
    }
}
