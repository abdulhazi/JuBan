"""Copies the page-check word lists from the Android (Java) code into windows/lists_gen.go,
so the phone and Windows apps always use exactly the same lists. Run from the repo root:
    python3 tools/gen_go_lists.py && gofmt -w windows/lists_gen.go
"""
import re

J = 'app/src/main/java/id/juban/app/'
cs = open(J + 'ContentScorer.java').read()
pp = open(J + 'PageCheckPolicy.java').read()


def arr(src, name):
    m = re.search(r'\b' + name + r'\s*=\s*(?:\{|new HashSet<>\(Arrays\.asList\(|new HashSet<>\(java\.util\.Arrays\.asList\()(.*?)(?:\};|\)\);)', src, re.S)
    assert m, name
    return re.findall(r'"([^"]*)"', re.sub(r'//[^\n]*', '', m.group(1)))


lists = {
    'strongPhrases': arr(cs, 'STRONG'), 'mediumWords': arr(cs, 'MEDIUM'), 'titleWords': arr(cs, 'TITLE_WORDS'),
    'counterWords': arr(cs, 'COUNTER'), 'challengeTitles': arr(cs, 'CHALLENGE_TITLES'),
    'challengeMarks': arr(cs, 'CHALLENGE_MARKS'), 'safeSites': arr(pp, 'SAFE'), 'safeEndings': arr(pp, 'SAFE_ENDINGS'),
    'skipTLDs': arr(pp, 'SKIP_TLDS'), 'infraFirst': arr(pp, 'INFRA_FIRST')}
ordered = ('strongPhrases', 'challengeTitles', 'challengeMarks', 'safeEndings')

out = ['// Code generated from ContentScorer.java and PageCheckPolicy.java. DO NOT EDIT BY HAND:',
       '// change the Java lists and run tools/gen_go_lists.py, so both apps always agree.', '', 'package main', '']
for k, v in lists.items():
    items = ', '.join('"%s"' % x for x in v)
    out.append(('var %s = []string{%s}' if k in ordered else 'var %s = set(%s)') % (k, items))
    out.append('')
open('windows/lists_gen.go', 'w').write('\n'.join(out))
