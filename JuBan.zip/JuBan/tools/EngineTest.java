import id.juban.app.DnsPacket;
import id.juban.app.DomainMatcher;

import java.io.ByteArrayOutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Desktop test for the blocking engine. Args: blocklist.txt matcher-cases.txt */
public class EngineTest {
    static int failures = 0;

    static void check(boolean ok, String what) {
        if (!ok) { failures++; System.out.println("FAIL: " + what); }
    }

    static byte[] query(String name, int qtype) {
        ByteArrayOutputStream dns = new ByteArrayOutputStream();
        dns.write(0x12); dns.write(0x34);          // id
        dns.write(0x01); dns.write(0x00);          // RD
        dns.write(0); dns.write(1);                // qdcount
        for (int i = 0; i < 6; i++) dns.write(0);
        for (String l : name.split("\\.")) { dns.write(l.length()); dns.write(l.getBytes(), 0, l.length()); }
        dns.write(0);
        dns.write(qtype >> 8); dns.write(qtype);
        dns.write(0); dns.write(1);
        byte[] d = dns.toByteArray();
        byte[] p = new byte[28 + d.length];
        p[0] = 0x45; p[2] = (byte) (p.length >> 8); p[3] = (byte) p.length; p[8] = 64; p[9] = 17;
        p[12] = 10; p[13] = 111; p[14] = (byte) 222; p[15] = 1;
        p[16] = 10; p[17] = 111; p[18] = (byte) 222; p[19] = 2;
        p[20] = (byte) 0xC3; p[21] = 0x50;         // src port 50000
        p[22] = 0; p[23] = 53;
        int ul = 8 + d.length; p[24] = (byte) (ul >> 8); p[25] = (byte) ul;
        System.arraycopy(d, 0, p, 28, d.length);
        return p;
    }

    public static void main(String[] a) throws Exception {
        // ---- DNS packets ----
        byte[] p = query("WWW.Slot-Gacor88.com", 1);
        DnsPacket.Query q = DnsPacket.parse(p, p.length);
        check(q != null && "www.slot-gacor88.com".equals(q.name), "name parsed + lower-cased");
        check(q.qtype == 1 && q.srcPort == 50000 && q.dstPort == 53, "ports/qtype");
        byte[] r = DnsPacket.buildBlockedResponse(p, q);
        check(r.length == p.length, "blocked reply has same size as query");
        check(r[12] == 10 && r[15] == 2 && r[19] == 1, "addresses swapped");
        check(((r[20] & 0xff) << 8 | (r[21] & 0xff)) == 53 && ((r[22] & 0xff) << 8 | (r[23] & 0xff)) == 50000, "ports swapped");
        check(r[28] == 0x12 && r[29] == 0x34, "dns id preserved");
        check((r[30] & 0x80) != 0 && (r[31] & 0x0f) == 3, "QR set, NXDOMAIN");
        // header checksum must verify to 0
        long sum = 0;
        for (int i = 0; i < 20; i += 2) sum += ((r[i] & 0xff) << 8) | (r[i + 1] & 0xff);
        while ((sum >> 16) != 0) sum = (sum & 0xffff) + (sum >> 16);
        check(sum == 0xffff, "ip checksum valid");
        check(DnsPacket.parse(new byte[10], 10) == null, "short packet ignored");
        byte[] tcp = p.clone(); tcp[9] = 6;
        check(DnsPacket.parse(tcp, tcp.length) == null, "tcp ignored");
        byte[] other = p.clone(); other[23] = 80;
        check(DnsPacket.parse(other, other.length) == null, "non-dns port ignored");
        byte[] cut = p.clone();
        check(DnsPacket.parse(cut, cut.length - 6) == null, "truncated packet ignored");

        // ---- matcher ----
        List<String> list = new ArrayList<>();
        for (String line : Files.readAllLines(Paths.get(a[0]))) {
            line = line.trim();
            if (!line.isEmpty() && !line.startsWith("#")) list.add(line);
        }
        System.out.println("bundled list: " + list.size() + " domains");
        DomainMatcher m = new DomainMatcher(list, Collections.singleton("contoh-diblokir.com"),
                Collections.singleton("merekcontoh"), Collections.singleton("slotted.co"), true);

        int cases = 0;
        for (String line : Files.readAllLines(Paths.get(a[1]))) {
            line = line.trim();
            if (line.isEmpty() || line.startsWith("#")) continue;
            String[] c = line.split("\\s+");
            String got = m.check(c[1]);
            if (c[0].equals("block")) check(got != null, "should block " + c[1]);
            else check(got == null, "should allow " + c[1] + " (got " + got + ")");
            cases++;
        }
        System.out.println("matcher cases: " + cases);

        DomainMatcher plain = new DomainMatcher(list, Collections.<String>emptySet(), Collections.<String>emptySet(),
                Collections.<String>emptySet(), false);
        check(plain.check("slotgacor.xyz") == null, "smart off: pattern not applied");
        check(plain.check("bet365.com") != null, "smart off: list still applied");

        check("example.com".equals(DomainMatcher.normalize(" https://www.Example.com/a?b=1 ")), "normalize url");
        check(DomainMatcher.normalize("not a domain") == null, "normalize rejects junk");
        check(DomainMatcher.normalize("localhost") == null, "normalize rejects bare word");
        check("wahana".equals(DomainMatcher.normalizeWord(" Wahana ")), "normalizeWord");
        check(DomainMatcher.normalizeWord("abc") == null, "normalizeWord rejects short word");
        check(DomainMatcher.normalizeWord("two words") == null, "normalizeWord rejects spaces");

        System.out.println(failures == 0 ? "ALL TESTS PASSED" : failures + " FAILURE(S)");
        System.exit(failures == 0 ? 0 : 1);
    }
}
