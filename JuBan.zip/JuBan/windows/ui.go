package main

// The control page, served only to this computer at http://127.0.0.1:53053/.
// Protections: requests must name 127.0.0.1/localhost as host (stops DNS-rebinding
// tricks), every button press carries a secret token only this page knows (stops other
// websites from pressing buttons), and the page cannot be framed.

import (
	"encoding/json"
	"fmt"
	"html/template"
	"net/http"
	"net/url"
	"strings"
	"sync"
)

type UI struct {
	app   *App
	hosts map[string]bool
	tmpl  *template.Template

	flashMu sync.Mutex
	flash   string // shown once on the next page load
}

func NewUI(app *App, port int) *UI {
	u := &UI{
		app: app,
		hosts: map[string]bool{
			fmt.Sprintf("127.0.0.1:%d", port): true,
			fmt.Sprintf("localhost:%d", port): true,
		},
	}
	u.tmpl = template.Must(template.New("page").Parse(pageHTML))
	return u
}

func (u *UI) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if !u.hosts[r.Host] {
		http.Error(w, "forbidden", http.StatusForbidden)
		return
	}
	h := w.Header()
	h.Set("X-Frame-Options", "DENY")
	h.Set("Content-Security-Policy", "default-src 'self'; style-src 'self' 'unsafe-inline'; frame-ancestors 'none'")
	h.Set("Cache-Control", "no-store")
	h.Set("Referrer-Policy", "no-referrer")

	switch {
	case r.URL.Path == "/" && r.Method == http.MethodGet:
		u.page(w, r)
	case r.URL.Path == "/do" && r.Method == http.MethodPost:
		u.do(w, r)
	case r.URL.Path == "/status" && r.Method == http.MethodGet:
		u.status(w, r)
	case r.URL.Path == "/app.js" && r.Method == http.MethodGet:
		h.Set("Content-Type", "text/javascript; charset=utf-8")
		fmt.Fprint(w, appJS)
	case r.URL.Path == "/version" && r.Method == http.MethodGet:
		h.Set("Content-Type", "text/plain")
		fmt.Fprint(w, version)
	default:
		http.NotFound(w, r)
	}
}

func lang(r *http.Request) map[string]string {
	for _, part := range strings.Split(r.Header.Get("Accept-Language"), ",") {
		tag := strings.ToLower(strings.TrimSpace(strings.SplitN(part, ";", 2)[0]))
		if tag == "id" || strings.HasPrefix(tag, "id-") || tag == "in" {
			return textID
		}
		if tag == "en" || strings.HasPrefix(tag, "en-") {
			return textEN
		}
	}
	return textEN
}

func (u *UI) do(w http.ResponseWriter, r *http.Request) {
	if err := r.ParseForm(); err != nil {
		http.Error(w, "bad request", http.StatusBadRequest)
		return
	}
	if o := r.Header.Get("Origin"); o != "" && o != "null" {
		ou, err := url.Parse(o)
		if err != nil || !u.hosts[ou.Host] {
			http.Error(w, "forbidden", http.StatusForbidden)
			return
		}
	}
	if r.PostForm.Get("t") != u.app.token {
		http.Error(w, "forbidden", http.StatusForbidden)
		return
	}
	t := lang(r)
	key, arg := u.app.Do(r.PostForm.Get("a"), r.PostForm.Get("v"))
	if key != "" {
		msg := t[key]
		if strings.Contains(msg, "%s") {
			msg = fmt.Sprintf(msg, arg)
		}
		u.flashMu.Lock()
		u.flash = msg
		u.flashMu.Unlock()
	}
	http.Redirect(w, r, "/", http.StatusSeeOther)
}

// stateKey changes whenever the page should be redrawn.
func stateKey(v View) string {
	return fmt.Sprintf("%v-%v-%v-%v-%d-%v", v.Enabled, v.Running, v.Smart, v.PageCheck, v.Lock.State, v.Quitting)
}

func (u *UI) status(w http.ResponseWriter, r *http.Request) {
	v := u.app.View()
	t := lang(r)
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]any{
		"state":  stateKey(v),
		"count":  fmt.Sprintf(t["count"], v.Count),
		"recent": v.Recent,
		"empty":  t["recent_empty"],
	})
}

type pageData struct {
	T                 map[string]string
	V                 View
	Token, Version    string
	State             string
	Status, StatusCls string
	CountText         string
	Button, ButtonAct string
	ButtonConfirm     string
	LockInfo          string
	Flash             string
	HasRules          bool
	PageHelp          string
}

func (u *UI) page(w http.ResponseWriter, r *http.Request) {
	t := lang(r)
	v := u.app.View()
	d := pageData{T: t, V: v, Token: u.app.token, Version: version, State: stateKey(v)}
	d.CountText = fmt.Sprintf(t["count"], v.Count)
	dur := func() string { return formatDuration(v.Lock.Remaining, t["dur_hm"], t["dur_m"]) }

	switch {
	case !v.Enabled:
		d.Status, d.StatusCls = t["status_off"], "off"
		d.Button, d.ButtonAct = t["turn_on"], "on"
		d.LockInfo = t["lock_hint_off"]
	case !v.Running:
		d.Status, d.StatusCls = t["status_failed"], "off"
		d.Button, d.ButtonAct = t["turn_on"], "on"
		d.LockInfo = t["lock_hint_failed"]
	case v.Lock.State == LockOpen:
		d.Status, d.StatusCls = t["status_on"], "on"
		d.Button, d.ButtonAct = t["off_now"], "off"
		d.LockInfo = fmt.Sprintf(t["lock_open"], dur())
	case v.Lock.State == LockWaiting:
		d.Status, d.StatusCls = t["status_on"], "on"
		d.Button, d.ButtonAct = t["cancel"], "cancel"
		d.LockInfo = fmt.Sprintf(t["lock_waiting"], dur())
	default:
		d.Status, d.StatusCls = t["status_on"], "on"
		d.Button, d.ButtonAct = t["request"], "request"
		d.ButtonConfirm = t["confirm_request"]
		d.LockInfo = t["lock_hint_on"]
	}
	d.HasRules = len(v.Block)+len(v.Words)+len(v.Allow) > 0
	d.PageHelp = fmt.Sprintf(t["page_help"], v.Found)

	u.flashMu.Lock()
	d.Flash, u.flash = u.flash, ""
	u.flashMu.Unlock()

	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	if err := u.tmpl.Execute(w, d); err != nil {
		fmt.Fprint(w, "error")
	}
}

const appJS = `
document.querySelectorAll('form[data-confirm]').forEach(function (f) {
  f.addEventListener('submit', function (e) {
    if (!window.confirm(f.getAttribute('data-confirm'))) e.preventDefault();
  });
});
var state = document.body.getAttribute('data-state');
function poll() {
  fetch('/status').then(function (r) { return r.json(); }).then(function (s) {
    if (s.state !== state) { location.reload(); return; }
    document.getElementById('count').textContent = s.count;
    var box = document.getElementById('recent');
    box.textContent = (s.recent && s.recent.length) ? s.recent.join('\n') : s.empty;
  }).catch(function () {});
}
setInterval(poll, 4000);
`

const pageHTML = `<!DOCTYPE html>
<html lang="{{.T.lang}}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>JuBan</title>
<style>
  :root { --bg:#F6F4EF; --card:#fff; --ink:#12263A; --muted:#5C6B7A; --on:#1B7F6B; --off:#C4352B; --line:#E3E0D8; }
  * { box-sizing: border-box; }
  body { margin:0; background:var(--bg); color:var(--ink); font:16px/1.5 "Segoe UI", system-ui, sans-serif; }
  main { max-width: 640px; margin: 0 auto; padding: 32px 20px 64px; }
  h1 { font-size: 30px; margin: 0; }
  h2 { font-size: 18px; margin: 32px 0 6px; }
  .muted { color: var(--muted); font-size: 14px; }
  .card { background: var(--card); border-radius: 16px; padding: 24px; margin-top: 20px; text-align: center; }
  .status { font-size: 22px; font-weight: 700; margin: 4px 0; }
  .status.on { color: var(--on); } .status.off { color: var(--off); }
  button { font: inherit; border: 0; border-radius: 10px; padding: 12px 18px; cursor: pointer; background: #E4E2DC; color: var(--ink); }
  button.primary { background: var(--ink); color: #fff; width: 100%; font-size: 17px; margin-top: 16px; }
  button.link { background: none; padding: 6px 0; color: var(--muted); text-decoration: underline; }
  .row { display: flex; gap: 8px; margin-top: 8px; } .row > * { flex: 1; }
  input[type=text] { font: inherit; width: 100%; padding: 12px; border: 1px solid var(--line); border-radius: 10px; background: #fff; }
  ul.rules { list-style: none; padding: 0; margin: 8px 0; } ul.rules li { padding: 2px 0; }
  pre { font: 13px/1.6 Consolas, monospace; color: var(--muted); white-space: pre-wrap; margin: 0; }
  .flash { background: #FFF6D6; border-radius: 10px; padding: 10px 14px; margin-top: 16px; }
  .error { background: #FBE3E1; border-radius: 10px; padding: 10px 14px; margin-top: 16px; }
  .switch { display: flex; justify-content: space-between; align-items: center; }
  footer { margin-top: 40px; }
</style>
</head>
<body data-state="{{.State}}">
<main>
  <h1>JuBan</h1>
  <div class="muted">{{.T.tagline}}</div>

  {{if .V.Quitting}}
    <div class="card"><div class="status">{{.T.removed}}</div></div>
  {{else}}

  {{if .Flash}}<div class="flash">{{.Flash}}</div>{{end}}
  {{if .V.Error}}<div class="error">{{.T.error_prefix}} {{.V.Error}}</div>{{end}}

  <div class="card">
    <div class="status {{.StatusCls}}">{{.Status}}</div>
    <div class="muted" id="count">{{.CountText}}</div>
    <form method="post" action="/do"{{if .ButtonConfirm}} data-confirm="{{.ButtonConfirm}}"{{end}}>
      <input type="hidden" name="t" value="{{.Token}}">
      <button class="primary" name="a" value="{{.ButtonAct}}">{{.Button}}</button>
    </form>
    <div class="muted" style="margin-top:10px">{{.LockInfo}}</div>
  </div>

  <h2>{{.T.smart_title}}</h2>
  <form method="post" action="/do" class="switch">
    <input type="hidden" name="t" value="{{.Token}}">
    <strong>{{if .V.Smart}}{{.T.on_word}}{{else}}{{.T.off_word}}{{end}}</strong>
    {{if .V.Smart}}
      <button name="a" value="smart">{{.T.smart_turn_off}}</button>
    {{else}}
      <input type="hidden" name="v" value="1"><button name="a" value="smart">{{.T.smart_turn_on}}</button>
    {{end}}
  </form>
  <div class="muted">{{.T.smart_help}}</div>

  <h2>{{.T.page_title}}</h2>
  <form method="post" action="/do" class="switch">
    <input type="hidden" name="t" value="{{.Token}}">
    <strong>{{if .V.PageCheck}}{{.T.on_word}}{{else}}{{.T.off_word}}{{end}}</strong>
    {{if .V.PageCheck}}
      <button name="a" value="page">{{.T.smart_turn_off}}</button>
    {{else}}
      <input type="hidden" name="v" value="1"><button name="a" value="page">{{.T.smart_turn_on}}</button>
    {{end}}
  </form>
  <div class="muted">{{.PageHelp}}</div>

  <h2>{{.T.rules_title}}</h2>
  <div class="muted">{{.T.rules_help}}</div>
  <form method="post" action="/do">
    <input type="hidden" name="t" value="{{.Token}}">
    <div class="row" style="margin-top:10px"><input type="text" name="v" placeholder="{{.T.input_hint}}" autocomplete="off" spellcheck="false"></div>
    <div class="row">
      <button name="a" value="block">{{.T.btn_block}}</button>
      <button name="a" value="allow">{{.T.btn_allow}}</button>
    </div>
  </form>
  {{if .HasRules}}
    <ul class="rules">
      {{range .V.Words}}<li>✖ *{{.}}*</li>{{end}}
      {{range .V.Block}}<li>✖ {{.}}</li>{{end}}
      {{range .V.Allow}}<li>✔ {{.}}</li>{{end}}
    </ul>
    <form method="post" action="/do" data-confirm="{{.T.confirm_clear}}">
      <input type="hidden" name="t" value="{{.Token}}">
      <button class="link" name="a" value="clear">{{.T.btn_clear}}</button>
    </form>
  {{else}}
    <p class="muted">{{.T.rules_empty}}</p>
  {{end}}

  <h2>{{.T.recent_title}}</h2>
  <pre id="recent">{{if .V.Recent}}{{range $i, $r := .V.Recent}}{{if $i}}
{{end}}{{$r}}{{end}}{{else}}{{.T.recent_empty}}{{end}}</pre>

  <h2>{{.T.notes_title}}</h2>
  <div class="muted">{{.T.notes}}</div>

  <h2>{{.T.uninstall_title}}</h2>
  {{if .V.Enabled}}
    <div class="muted">{{.T.uninstall_locked}}</div>
  {{else}}
    <div class="muted">{{.T.uninstall_help}}</div>
    <form method="post" action="/do" data-confirm="{{.T.confirm_uninstall}}">
      <input type="hidden" name="t" value="{{.Token}}">
      <button name="a" value="uninstall" style="margin-top:8px">{{.T.uninstall_btn}}</button>
    </form>
  {{end}}

  {{end}}
  <footer class="muted">JuBan {{.Version}}</footer>
</main>
<script src="/app.js"></script>
</body>
</html>`

var textEN = map[string]string{
	"lang":              "en",
	"tagline":           "Blocks Ju sites on this computer",
	"status_on":         "Protection is ON",
	"status_off":        "Protection is OFF",
	"status_failed":     "Protection could not start",
	"turn_on":           "Turn on protection",
	"request":           "Request turn-off",
	"cancel":            "Cancel turn-off request",
	"off_now":           "Turn off now",
	"count":             "%d Ju sites blocked so far",
	"lock_hint_off":     "Once it is on, turning it off takes 24 hours. Add any “Always allow” sites before you start.",
	"lock_hint_on":      "Turning off takes 24 hours.",
	"lock_hint_failed":  "Something else on this computer is using what JuBan needs. Your internet still works. Try again, or restart the computer.",
	"lock_waiting":      "Turn-off requested. Still protected for %s.",
	"lock_open":         "Unlocked. You can turn off or change settings for %s.",
	"dur_hm":            "%d h %d min",
	"dur_m":             "%d min",
	"confirm_request":   "Protection stays on for another 24 hours. After that you get one hour in which you can turn it off. You can cancel this request at any time, and the urge usually passes sooner than the wait.",
	"on_word":           "ON",
	"off_word":          "OFF",
	"smart_title":       "Smart detection",
	"smart_turn_off":    "Switch off",
	"smart_turn_on":     "Switch on",
	"smart_help":        "Also blocks sites whose address looks like a Ju site, even brand-new ones. If a normal site is blocked by mistake, add it under “Always allow” (only possible while protection is off or unlocked).",
	"page_title":        "Page check",
	"page_help":         "The first time a site is opened, JuBan reads its front page. If it is full of Ju words, the site is blocked, even on that first visit. A new site can take a second or two longer to open the first time. Found so far: %d sites.",
	"rules_title":       "My own rules",
	"rules_help":        "Type a site address to block that site. Or type just a brand name (one word, no dots) to block every address that contains it.",
	"input_hint":        "example.com or brandname",
	"btn_block":         "Block",
	"btn_allow":         "Always allow",
	"btn_clear":         "Remove all my rules",
	"confirm_clear":     "Remove all your own rules?",
	"rules_empty":       "No rules of your own yet.",
	"bad_domain":        "Type a site address, or one word of 4 to 20 letters.",
	"added_block":       "%s is now blocked",
	"added_word":        "Every address containing “%s” is now blocked",
	"added_allow":       "%s is now always allowed",
	"locked":            "Locked while protection is on. Request turn-off and wait first.",
	"start_failed":      "Could not turn on: %s",
	"recent_title":      "Recently blocked",
	"recent_empty":      "Nothing blocked yet.",
	"notes_title":       "Good to know",
	"notes":             "JuBan works for every browser and app on this computer, for every Windows user, and starts by itself when the computer starts. It only checks site names; your browsing is not sent anywhere. Chrome and Edge may say “Managed by your organization”: that is JuBan switching off their own secure-DNS option so they cannot go around the block. To open this page again, use the JuBan shortcut on the desktop or in the Start menu.",
	"uninstall_title":   "Remove JuBan",
	"uninstall_help":    "Removes JuBan from this computer and puts the internet settings back to normal.",
	"uninstall_locked":  "Possible only while protection is off.",
	"uninstall_btn":     "Remove JuBan",
	"confirm_uninstall": "Remove JuBan from this computer?",
	"removed":           "JuBan has been removed. You can close this tab.",
	"error_prefix":      "Problem:",
}

var textID = map[string]string{
	"lang":              "id",
	"tagline":           "Memblokir situs Ju di komputer ini",
	"status_on":         "Perlindungan AKTIF",
	"status_off":        "Perlindungan MATI",
	"status_failed":     "Perlindungan gagal dijalankan",
	"turn_on":           "Aktifkan perlindungan",
	"request":           "Ajukan penonaktifan",
	"cancel":            "Batalkan pengajuan",
	"off_now":           "Matikan sekarang",
	"count":             "%d situs Ju sudah diblokir",
	"lock_hint_off":     "Setelah aktif, mematikannya butuh 24 jam. Atur dulu situs “Selalu izinkan” sebelum mulai.",
	"lock_hint_on":      "Mematikan butuh waktu 24 jam.",
	"lock_hint_failed":  "Ada program lain di komputer ini yang memakai bagian yang dibutuhkan JuBan. Internet Anda tetap berjalan. Coba lagi, atau nyalakan ulang komputer.",
	"lock_waiting":      "Penonaktifan diajukan. Masih terlindungi selama %s.",
	"lock_open":         "Terbuka. Anda bisa mematikan atau mengubah pengaturan selama %s.",
	"dur_hm":            "%d jam %d menit",
	"dur_m":             "%d menit",
	"confirm_request":   "Perlindungan tetap aktif selama 24 jam lagi. Setelah itu Anda punya waktu satu jam untuk mematikannya. Pengajuan ini bisa dibatalkan kapan saja, dan biasanya keinginan itu hilang lebih cepat daripada waktu tunggunya.",
	"on_word":           "AKTIF",
	"off_word":          "MATI",
	"smart_title":       "Deteksi pintar",
	"smart_turn_off":    "Matikan",
	"smart_turn_on":     "Aktifkan",
	"smart_help":        "Juga memblokir situs yang alamatnya mirip situs Ju, termasuk yang baru muncul. Jika situs biasa ikut terblokir, tambahkan lewat “Selalu izinkan” (hanya bisa saat perlindungan mati atau terbuka).",
	"page_title":        "Cek halaman",
	"page_help":         "Saat sebuah situs dibuka pertama kali, JuBan membaca halaman depannya. Jika penuh kata-kata Ju, situs itu diblokir, bahkan pada kunjungan pertama. Situs baru bisa butuh satu-dua detik lebih lama saat pertama dibuka. Sejauh ini ditemukan: %d situs.",
	"rules_title":       "Aturan saya",
	"rules_help":        "Ketik alamat situs untuk memblokir situs itu. Atau ketik nama mereknya saja (satu kata, tanpa titik) untuk memblokir semua alamat yang mengandung kata itu.",
	"input_hint":        "contoh.com atau namamerek",
	"btn_block":         "Blokir",
	"btn_allow":         "Selalu izinkan",
	"btn_clear":         "Hapus semua aturan saya",
	"confirm_clear":     "Hapus semua aturan Anda?",
	"rules_empty":       "Belum ada aturan sendiri.",
	"bad_domain":        "Ketik alamat situs, atau satu kata berisi 4 sampai 20 huruf.",
	"added_block":       "%s sekarang diblokir",
	"added_word":        "Semua alamat yang mengandung “%s” sekarang diblokir",
	"added_allow":       "%s sekarang selalu diizinkan",
	"locked":            "Terkunci selama perlindungan aktif. Ajukan penonaktifan lalu tunggu dulu.",
	"start_failed":      "Gagal mengaktifkan: %s",
	"recent_title":      "Baru saja diblokir",
	"recent_empty":      "Belum ada yang diblokir.",
	"notes_title":       "Perlu diketahui",
	"notes":             "JuBan bekerja untuk semua browser dan aplikasi di komputer ini, untuk semua pengguna Windows, dan berjalan sendiri saat komputer dinyalakan. JuBan hanya memeriksa nama situs; data penjelajahan Anda tidak dikirim ke mana pun. Chrome dan Edge mungkin menulis “Dikelola oleh organisasi Anda”: itu karena JuBan mematikan opsi DNS aman bawaan mereka agar blokir tidak bisa diakali. Untuk membuka halaman ini lagi, pakai pintasan JuBan di desktop atau menu Start.",
	"uninstall_title":   "Hapus JuBan",
	"uninstall_help":    "Menghapus JuBan dari komputer ini dan mengembalikan pengaturan internet seperti semula.",
	"uninstall_locked":  "Hanya bisa saat perlindungan mati.",
	"uninstall_btn":     "Hapus JuBan",
	"confirm_uninstall": "Hapus JuBan dari komputer ini?",
	"removed":           "JuBan sudah dihapus. Tab ini boleh ditutup.",
	"error_prefix":      "Masalah:",
}
