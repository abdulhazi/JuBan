package main

// Page check: the first time an unknown site is looked up, open its front page (like
// someone who clicked a Google result), score the text, and remember the verdict.
// A line-by-line port of ContentScorer.java, PageCheckPolicy.java and PageChecker.java;
// the word lists come from the Java code via lists_gen.go.

import (
	"bufio"
	"context"
	"fmt"
	"io"
	"math"
	"net"
	"net/http"
	"net/url"
	"os"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"time"
)

// ---------------- scoring (ContentScorer.java) ----------------

type ScoreResult struct {
	Ju                                        bool
	Strong, Medium, TitleHits, Counter, Words int
	Title                                     string
}

var (
	titleRe       = regexp.MustCompile(`(?is)<title[^>]*>(.*?)</title>`)
	hiddenRes     = []*regexp.Regexp{regexp.MustCompile(`(?is)<script[^>]*>.*?</script>`), regexp.MustCompile(`(?is)<style[^>]*>.*?</style>`), regexp.MustCompile(`(?is)<noscript[^>]*>.*?</noscript>`), regexp.MustCompile(`(?is)<svg[^>]*>.*?</svg>`)}
	metaContentRe = regexp.MustCompile(`(?i)<meta[^>]+content\s*=\s*["']([^"']*)["']`)
	altRe         = regexp.MustCompile(`(?i)\salt\s*=\s*["']([^"']*)["']`)
	tagRe         = regexp.MustCompile(`<[^>]*>`)
	nonWordRe     = regexp.MustCompile(`[^a-z0-9]+`)
	spacesRe      = regexp.MustCompile(`\s+`)
	metaRefreshRe = regexp.MustCompile(`(?i)<meta[^>]+http-equiv\s*=\s*["']?refresh[^>]*url\s*=\s*['"]?([^'"\s>]+)`)
	jsLocationRe  = regexp.MustCompile(`(?i)location(?:\.href)?\s*(?:=|\.replace\(|\.assign\()\s*['"](https?://[^'"]+)['"]`)
)

func pageWords(s string) string {
	t := strings.ToLower(s)
	t = strings.NewReplacer("&amp;", "&", "&nbsp;", " ", "&#39;", "'", "&quot;", "\"").Replace(t)
	return " " + strings.TrimSpace(nonWordRe.ReplaceAllString(t, " ")) + " "
}

func fields(s string) []string {
	s = strings.TrimSpace(s)
	if s == "" {
		return nil
	}
	return strings.Split(s, " ")
}

func ScorePage(html string) ScoreResult {
	var r ScoreResult
	if len(html) > 400_000 {
		html = html[:400_000]
	}
	title := ""
	if m := titleRe.FindStringSubmatch(html); m != nil {
		title = m[1]
	}
	r.Title = spacesRe.ReplaceAllString(strings.TrimSpace(title), " ")
	if len(r.Title) > 160 {
		r.Title = r.Title[:160]
	}

	var text strings.Builder
	text.WriteString(title + " ")
	for _, m := range metaContentRe.FindAllStringSubmatch(html, -1) {
		text.WriteString(m[1] + " ")
	}
	for _, m := range altRe.FindAllStringSubmatch(html, -1) {
		text.WriteString(m[1] + " ")
	}
	body := html
	for _, re := range hiddenRes {
		body = re.ReplaceAllString(body, " ")
	}
	text.WriteString(tagRe.ReplaceAllString(body, " "))

	all := pageWords(text.String())
	t := pageWords(title)
	r.Words = len(fields(all))

	titleSeen := map[string]bool{}
	for _, p := range strongPhrases {
		needle := " " + p + " "
		if strings.Contains(all, needle) {
			r.Strong++
		}
		if strings.Contains(t, needle) {
			titleSeen[p] = true
		}
	}
	for _, w := range fields(t) {
		if titleWords[w] {
			titleSeen[w] = true
		}
	}
	r.TitleHits = len(titleSeen)

	med, counter := map[string]bool{}, map[string]bool{}
	for _, w := range fields(all) {
		if mediumWords[w] {
			med[w] = true
		}
		if counterWords[w] {
			counter[w] = true
		}
	}
	r.Medium, r.Counter = len(med), len(counter)

	ju := r.TitleHits >= 2 || (r.TitleHits >= 1 && r.Strong >= 2) || r.Strong >= 3 || (r.Strong >= 2 && r.Medium >= 4)
	if r.Counter >= 2 && r.Strong < 6 {
		ju = false // a news or government page about Ju sites
	}
	r.Ju = ju
	return r
}

// Unreadable: a protection screen or (almost) no text. Never to be remembered as clean.
func Unreadable(html string, r ScoreResult) bool {
	if r.Ju {
		return false
	}
	if r.Words < 25 {
		return true
	}
	if r.Words >= 300 {
		return false
	}
	title := strings.ToLower(r.Title)
	for _, t := range challengeTitles {
		if strings.Contains(title, t) {
			return true
		}
	}
	h := html
	if len(h) > 60_000 {
		h = h[:60_000]
	}
	h = strings.ToLower(h)
	for _, m := range challengeMarks {
		if strings.Contains(h, m) {
			return true
		}
	}
	return false
}

// FindRedirect: where a page that only forwards the visitor sends them ("" if nowhere).
func FindRedirect(html string) string {
	if m := metaRefreshRe.FindStringSubmatch(html); m != nil {
		return m[1]
	}
	if m := jsLocationRe.FindStringSubmatch(html); m != nil {
		return m[1]
	}
	return ""
}

// ---------------- which names to check (PageCheckPolicy.java) ----------------

var ipOnlyRe = regexp.MustCompile(`^[0-9.]+$`)

func pageLookup(qtype uint16) bool { return qtype == 1 || qtype == 28 || qtype == 65 }

func Eligible(host string, qtype uint16) bool {
	if !pageLookup(qtype) {
		return false
	}
	h := strings.TrimSuffix(strings.ToLower(host), ".")
	if len(h) < 4 || len(h) > 253 {
		return false
	}
	labels := strings.Split(h, ".")
	if len(labels) < 2 || skipTLDs[labels[len(labels)-1]] || ipOnlyRe.MatchString(h) {
		return false
	}
	if len(labels) > 2 && infraFirst[labels[0]] {
		return false
	}
	for _, e := range safeEndings {
		if strings.HasSuffix(h, e) {
			return false
		}
	}
	return !inSet(safeSites, h)
}

// ---------------- verdicts (PageChecker.java) ----------------

const (
	VerdictUnknown = 0
	VerdictJu      = 1
	VerdictClean   = 2
	VerdictFailed  = 3

	cleanFor  = 7 * 24 * time.Hour
	failedFor = 6 * time.Hour
)

type Page struct {
	HTML, FinalURL string
	Status         int
}

// Fetcher opens a page; nil means it could not be opened.
type Fetcher func(url string) *Page

type verdict struct {
	v     int
	until int64 // unix ms
}

type checkCall struct {
	done chan struct{}
	v    int
}

// Wait returns the verdict, or VerdictUnknown if it is not ready within d.
func (c *checkCall) Wait(d time.Duration) int {
	if d <= 0 {
		select {
		case <-c.done:
			return c.v
		default:
			return VerdictUnknown
		}
	}
	t := time.NewTimer(d)
	defer t.Stop()
	select {
	case <-c.done:
		return c.v
	case <-t.C:
		return VerdictUnknown
	}
}

type Checker struct {
	path  string
	fetch Fetcher
	now   func() time.Time
	sem   chan struct{}

	mu       sync.Mutex
	verdicts map[string]verdict
	inflight map[string]*checkCall
	fileMu   sync.Mutex
}

func NewChecker(path string, fetch Fetcher) *Checker {
	c := &Checker{path: path, fetch: fetch, now: time.Now, sem: make(chan struct{}, 6),
		verdicts: map[string]verdict{}, inflight: map[string]*checkCall{}}
	c.load()
	return c
}

func (c *Checker) Cached(host string) int {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.cachedLocked(host)
}

func (c *Checker) cachedLocked(host string) int {
	v, ok := c.verdicts[host]
	if !ok {
		return VerdictUnknown
	}
	if v.v != VerdictJu && v.until < c.now().UnixMilli() {
		delete(c.verdicts, host)
		return VerdictUnknown
	}
	return v.v
}

func (c *Checker) JuCount() int {
	c.mu.Lock()
	defer c.mu.Unlock()
	n := 0
	for _, v := range c.verdicts {
		if v.v == VerdictJu {
			n++
		}
	}
	return n
}

// Check starts a check (or joins one already running for this host).
func (c *Checker) Check(host string) *checkCall {
	c.mu.Lock()
	if call, ok := c.inflight[host]; ok {
		c.mu.Unlock()
		return call
	}
	call := &checkCall{done: make(chan struct{})}
	c.inflight[host] = call
	c.mu.Unlock()
	go func() {
		c.sem <- struct{}{}
		v := c.run(host)
		<-c.sem
		c.mu.Lock()
		delete(c.inflight, host)
		c.mu.Unlock()
		call.v = v
		close(call.done)
	}()
	return call
}

func (c *Checker) run(host string) int {
	if v := c.Cached(host); v != VerdictUnknown {
		return v
	}
	page := c.fetch("https://" + host + "/")
	if page == nil {
		page = c.fetch("http://" + host + "/")
	}
	if page == nil {
		c.remember(host, VerdictFailed)
		return VerdictFailed
	}
	r := ScorePage(page.HTML)
	readable := page.Status < 400 && !Unreadable(page.HTML, r)
	if !r.Ju {
		if next := FindRedirect(page.HTML); next != "" {
			if base, err := url.Parse(page.FinalURL); err == nil {
				if u, err := base.Parse(next); err == nil {
					if p2 := c.fetch(u.String()); p2 != nil {
						r = ScorePage(p2.HTML)
						readable = p2.Status < 400 && !Unreadable(p2.HTML, r)
					}
				}
			}
		}
	}
	if !r.Ju && !readable {
		c.remember(host, VerdictFailed)
		return VerdictFailed
	}
	v := VerdictClean
	if r.Ju {
		v = VerdictJu
		logf("page check: %s is a Ju site (%q)", host, r.Title)
	}
	c.remember(host, v)
	// The site it forwarded to gets the same verdict (not big known sites such as Telegram).
	if u, err := url.Parse(page.FinalURL); err == nil {
		fh := strings.ToLower(u.Hostname())
		if fh != host && Eligible(fh, 1) && c.Cached(fh) == VerdictUnknown {
			c.remember(fh, v)
		}
	}
	return v
}

func (c *Checker) remember(host string, v int) {
	until := int64(math.MaxInt64)
	switch v {
	case VerdictClean:
		until = c.now().Add(cleanFor).UnixMilli()
	case VerdictFailed:
		until = c.now().Add(failedFor).UnixMilli()
	}
	c.mu.Lock()
	c.verdicts[host] = verdict{v, until}
	c.mu.Unlock()
	c.append(host, v, until)
}

func (c *Checker) append(host string, v int, until int64) {
	if c.path == "" {
		return
	}
	c.fileMu.Lock()
	defer c.fileMu.Unlock()
	if fi, err := os.Stat(c.path); err == nil && fi.Size() > 512*1024 {
		c.compact()
	}
	f, err := os.OpenFile(c.path, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o644)
	if err != nil {
		return
	}
	fmt.Fprintf(f, "%s %d %d\n", host, v, until)
	f.Close()
}

func (c *Checker) compact() { // fileMu held
	now := c.now().UnixMilli()
	var b strings.Builder
	c.mu.Lock()
	for h, v := range c.verdicts {
		if v.v == VerdictJu || v.until > now {
			fmt.Fprintf(&b, "%s %d %d\n", h, v.v, v.until)
		}
	}
	c.mu.Unlock()
	tmp := c.path + ".tmp"
	if os.WriteFile(tmp, []byte(b.String()), 0o644) == nil {
		os.Rename(tmp, c.path)
	}
}

func (c *Checker) load() {
	f, err := os.Open(c.path)
	if err != nil {
		return
	}
	defer f.Close()
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		p := strings.Fields(sc.Text())
		if len(p) != 3 {
			continue
		}
		v, err1 := strconv.Atoi(p[1])
		until, err2 := strconv.ParseInt(p[2], 10, 64)
		if err1 == nil && err2 == nil {
			c.verdicts[p[0]] = verdict{v, until}
		}
	}
}

// ---------------- opening pages ----------------

const (
	checkReferer   = "https://www.google.com/"
	checkUserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"
	checkTimeout   = 2500 * time.Millisecond
	checkMaxBytes  = 300_000
)

// HTTPFetcher opens pages like a visitor arriving from a Google search. resolve finds a
// site's addresses; JuBan uses its own DNS look-up here, because the computer's DNS
// points at JuBan itself and would wait for this very check.
func HTTPFetcher(resolve func(host string) []net.IP) Fetcher {
	dialer := &net.Dialer{Timeout: checkTimeout}
	tr := &http.Transport{
		TLSHandshakeTimeout:   checkTimeout,
		ResponseHeaderTimeout: checkTimeout,
		DisableKeepAlives:     true,
		Proxy:                 nil,
		DialContext: func(ctx context.Context, network, addr string) (net.Conn, error) {
			host, port, err := net.SplitHostPort(addr)
			if err != nil {
				return nil, err
			}
			if resolve == nil || net.ParseIP(host) != nil {
				return dialer.DialContext(ctx, network, addr)
			}
			var last error = fmt.Errorf("no address for %s", host)
			for _, ip := range resolve(host) {
				c, err := dialer.DialContext(ctx, "tcp", net.JoinHostPort(ip.String(), port))
				if err == nil {
					return c, nil
				}
				last = err
			}
			return nil, last
		},
	}
	client := &http.Client{
		Transport:     tr,
		Timeout:       2 * checkTimeout,
		CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse },
	}
	return func(start string) *Page {
		current := start
		for hop := 0; hop < 5; hop++ {
			req, err := http.NewRequest("GET", current, nil)
			if err != nil {
				return nil
			}
			req.Header.Set("User-Agent", checkUserAgent)
			req.Header.Set("Accept", "text/html,application/xhtml+xml;q=0.9,*/*;q=0.8")
			req.Header.Set("Accept-Language", "id-ID,id;q=0.9,en;q=0.8")
			req.Header.Set("Referer", checkReferer)
			resp, err := client.Do(req)
			if err != nil {
				return nil
			}
			if resp.StatusCode >= 300 && resp.StatusCode < 400 {
				loc := resp.Header.Get("Location")
				resp.Body.Close()
				base, _ := url.Parse(current)
				next, err := base.Parse(loc)
				if loc == "" || err != nil {
					return nil
				}
				current = next.String()
				continue
			}
			ct := strings.ToLower(resp.Header.Get("Content-Type"))
			if ct != "" && !strings.Contains(ct, "html") {
				resp.Body.Close()
				return nil
			}
			b, _ := io.ReadAll(io.LimitReader(resp.Body, checkMaxBytes))
			resp.Body.Close()
			return &Page{HTML: string(b), FinalURL: current, Status: resp.StatusCode}
		}
		return nil
	}
}

// ResolveVia looks up a site's addresses by asking the given DNS servers directly.
func ResolveVia(upstreams func() []string) func(string) []net.IP {
	return func(host string) []net.IP {
		for _, qt := range []uint16{1, 28} {
			r := Exchange(BuildQuery(0x4a42, host, qt), upstreams(), false, 2*time.Second)
			if ips := ParseAddrs(r, qt); len(ips) > 0 {
				return ips
			}
		}
		return nil
	}
}
