package main

// Screen check (Windows): a small helper that runs in the signed-in person's own session,
// reads the page shown in the browser window in front, and asks JuBan to block the site if
// it is a Ju page. The reading itself (Windows UI Automation) is in screen_windows.go; this
// file is the part that decides, and it can be tested anywhere.

import (
	"crypto/rand"
	"encoding/base64"
	"encoding/hex"
	"net/url"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"time"
)

// loadAgentKey returns the secret shared with the helper, creating it the first time.
func loadAgentKey(dir string) string {
	path := filepath.Join(dir, "agent.key")
	if b, err := os.ReadFile(path); err == nil && len(strings.TrimSpace(string(b))) >= 16 {
		return strings.TrimSpace(string(b))
	}
	var b [16]byte
	rand.Read(b[:])
	k := hex.EncodeToString(b[:])
	os.MkdirAll(dir, 0o755)
	if err := os.WriteFile(path, []byte(k), 0o644); err != nil {
		return "" // no key, no helper: the screen check simply stays idle
	}
	return k
}

var hostRe = regexp.MustCompile(`^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$`)

// HostFromAddress reads the site name out of what the address bar shows ("https://a.b/c",
// "a.b/c", "a.b"). It returns "" when the bar shows something else (a search, a blank tab).
func HostFromAddress(s string) string {
	s = strings.ToLower(strings.TrimSpace(s))
	if s == "" || strings.ContainsAny(s, " \t") {
		return ""
	}
	if !strings.Contains(s, "://") {
		s = "http://" + s
	}
	u, err := url.Parse(s)
	if err != nil {
		return ""
	}
	h := strings.TrimSuffix(strings.TrimPrefix(u.Hostname(), "www."), ".")
	if !hostRe.MatchString(h) || ipOnlyRe.MatchString(h) || h == "localhost" {
		return ""
	}
	return h
}

// ScreenIsJu scores the window title and the page text the way the Android screen check does.
func ScreenIsJu(title, text string) bool {
	if len(text) > 200_000 {
		text = text[:200_000]
	}
	text = strings.NewReplacer("<", " ", ">", " ").Replace(text)
	title = strings.NewReplacer("<", " ", ">", " ").Replace(title)
	return ScorePage("<title>" + title + "</title>" + text).Ju
}

// ScreenLine is one reading from the browser window: the address bar, the window title
// and the text of the page.
type ScreenLine struct {
	Window     string // opaque id of the window, to tell when it is still the same one
	Address    string
	Title, Doc string
}

// ParseScreenLine reads "JB1|window|b64(address)|b64(title)|b64(text)".
func ParseScreenLine(line string) (ScreenLine, bool) {
	parts := strings.Split(strings.TrimSpace(line), "|")
	if len(parts) != 5 || parts[0] != "JB1" {
		return ScreenLine{}, false
	}
	dec := func(s string) string {
		b, err := base64.StdEncoding.DecodeString(s)
		if err != nil {
			return ""
		}
		return string(b)
	}
	return ScreenLine{Window: parts[1], Address: dec(parts[2]), Title: dec(parts[3]), Doc: dec(parts[4])}, true
}

// Screen is the helper's decision logic. The three functions are how it talks to the rest
// of the system, so tests can stand in for them.
type Screen struct {
	Ask       func(host string) bool // tell JuBan; true when it accepted ("ju")
	CloseTab  func(window string)    // close the tab in that window
	Now       func() time.Time
	lastBlock time.Time
	seen      map[string]time.Time // address+text already judged -> when
}

func NewScreen(ask func(string) bool, closeTab func(string)) *Screen {
	return &Screen{Ask: ask, CloseTab: closeTab, Now: time.Now, seen: map[string]time.Time{}}
}

// Handle looks at one reading. It reports true when it closed a tab.
func (s *Screen) Handle(l ScreenLine) bool {
	host := HostFromAddress(l.Address)
	if host == "" || !Eligible(host, 1) {
		return false // search page, blank tab, JuBan's own page, or a site on the safe list
	}
	now := s.Now()
	if now.Sub(s.lastBlock) < 3*time.Second {
		return false
	}
	key := host + "|" + l.Title + "|" + l.Doc
	if len(key) > 4096 {
		key = key[:4096]
	}
	if t, ok := s.seen[key]; ok && now.Sub(t) < 30*time.Second {
		return false
	}
	if len(s.seen) > 200 {
		s.seen = map[string]time.Time{}
	}
	s.seen[key] = now
	if !ScreenIsJu(l.Title, l.Doc) {
		return false
	}
	if !s.Ask(host) {
		return false
	}
	s.lastBlock = now
	s.CloseTab(l.Window)
	return true
}
