package main

import (
	"encoding/binary"
	"net"
	"strings"
	"testing"
	"time"
)

func ans(rcode int, addrs ...string) *DNSAnswer {
	a := &DNSAnswer{Rcode: rcode, Addrs: map[string]bool{}}
	for _, x := range addrs {
		a.Addrs[x] = true
	}
	return a
}

// Same cases as tools/IspCheckTest.java.
func TestIspCheckRules(t *testing.T) {
	var c IspCheck
	c.Learn("bet365.com", ans(0, "36.86.63.185"), ans(0, "5.226.180.10"))
	if c.Active() {
		t.Error("one probe is not enough")
	}
	c.Learn("pornhub.com", ans(0, "36.86.63.185"), ans(0, "66.254.114.41"))
	if !c.Active() || !c.Blocked(ans(0, "36.86.63.185"), ans(0, "104.21.5.5")) {
		t.Error("warning page learnt and used")
	}
	if c.Blocked(ans(0, "142.250.4.100"), ans(0, "142.250.4.101")) || c.Blocked(ans(3), ans(0, "1.2.3.4")) {
		t.Error("normal answers are not blocks")
	}

	var d IspCheck
	d.Learn("bet365.com", ans(0, "23.1.1.1"), ans(0, "23.9.9.9"))
	d.Learn("pornhub.com", ans(0, "36.86.63.185"), ans(0, "66.254.114.41"))
	d.Learn("xvideos.com", ans(0, "36.86.63.185"), ans(0, "185.88.181.2"))
	if !d.Active() || d.Blocked(ans(0, "23.1.1.1"), ans(0, "23.9.9.9")) || !d.Blocked(ans(0, "36.86.63.185"), nil) {
		t.Error("a CDN address seen once must not be trusted")
	}

	var e IspCheck
	e.Learn("bet365.com", ans(3), ans(0, "5.226.180.10"))
	e.Learn("1xbet.com", ans(3), ans(0, "104.18.1.1"))
	if !e.Active() || !e.Blocked(ans(3), ans(0, "104.21.9.9")) || e.Blocked(ans(3), ans(3)) {
		t.Error("no-such-site networks")
	}

	var f IspCheck
	for _, p := range ispProbes {
		f.Learn(p, ans(0, "5.5.5.5"), ans(0, "5.5.5.5"))
	}
	if f.Active() {
		t.Error("an unfiltered network stays inactive")
	}
}

// fakeDNS answers with whatever pick() says for each name.
func fakeDNS(t *testing.T, pick func(name string) (rcode byte, ip string)) string {
	c, err := net.ListenPacket("udp4", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { c.Close() })
	go func() {
		buf := make([]byte, 1500)
		for {
			n, from, err := c.ReadFrom(buf)
			if err != nil {
				return
			}
			q, ok := ParseQuery(buf[:n])
			if !ok {
				continue
			}
			rc, ip := pick(q.Name)
			r := Reply(buf[:n], q.QEnd, rc)
			if rc == 0 && ip != "" && q.QType == 1 {
				binary.BigEndian.PutUint16(r[6:], 1)
				r = append(r, 0xc0, 12, 0, 1, 0, 1, 0, 0, 0, 60, 0, 4)
				r = append(r, net.ParseIP(ip).To4()...)
			}
			c.WriteTo(r, from)
		}
	}()
	return c.LocalAddr().String()
}

func TestIndonesiasListEndToEnd(t *testing.T) {
	onList := func(name string) bool {
		for _, p := range ispProbes {
			if name == p {
				return true
			}
		}
		return strings.Contains(name, "situsbaru-acak")
	}
	google := fakeDNS(t, func(name string) (byte, string) { return 0, "104.21.7.7" })
	isp := fakeDNS(t, func(name string) (byte, string) {
		if onList(name) {
			return 0, "36.86.63.185" // the ISP's warning page
		}
		return 0, "104.21.8.8" // a different but normal CDN address
	})

	h := newHarness(t)
	h.post("on", "")
	h.app.SetUpstreamsForTest([]string{google})
	h.app.SetNetworkDNSForTest([]string{isp}, []string{google})
	if !h.app.isp.Active() {
		t.Fatal("did not learn the warning page")
	}
	if rc := h.lookup("situsbaru-acak.xyz"); rc != rcodeNXDomain {
		t.Errorf("site on Indonesia's list: rcode %d", rc)
	}
	if !h.app.IspBlockedNow("situsbaru-acak.xyz") {
		t.Error("should be remembered")
	}
	if rc := h.lookup("www.wikipedia.org"); rc != 0 {
		t.Errorf("normal site with a different CDN address: rcode %d", rc)
	}
	// "Always allow" beats Indonesia's list too (once unlocked).
	h.post("request", "")
	h.clock = h.clock.Add(24*time.Hour + time.Minute)
	h.post("allow", "situsbaru-acak.xyz")
	if rc := h.lookup("situsbaru-acak.xyz"); rc != 0 {
		t.Errorf("always allow: rcode %d", rc)
	}
}
