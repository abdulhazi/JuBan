//go:build windows

package main

import (
	"encoding/base64"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"syscall"
	"unicode/utf16"
	"unsafe"
)

const (
	createNoWindow         = 0x08000000
	createBreakawayFromJob = 0x01000000
	taskName               = "JuBan"
	safetyTaskName         = "JuBan-Safety"
)

func programDir() string {
	pf := os.Getenv("ProgramFiles")
	if pf == "" {
		pf = `C:\Program Files`
	}
	return filepath.Join(pf, "JuBan")
}

func dataDir() string {
	pd := os.Getenv("ProgramData")
	if pd == "" {
		pd = `C:\ProgramData`
	}
	return filepath.Join(pd, "JuBan")
}

func system32(name string) string {
	root := os.Getenv("SystemRoot")
	if root == "" {
		root = `C:\Windows`
	}
	return filepath.Join(root, "System32", name)
}

func hidden(name string, args ...string) *exec.Cmd {
	c := exec.Command(name, args...)
	c.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: createNoWindow}
	return c
}

// powershell runs a script without showing a window and returns what it printed.
func powershell(script string) (string, error) {
	u := utf16.Encode([]rune(script))
	b := make([]byte, 2*len(u))
	for i, c := range u {
		b[2*i], b[2*i+1] = byte(c), byte(c>>8)
	}
	enc := base64.StdEncoding.EncodeToString(b)
	ps := filepath.Join(system32("WindowsPowerShell"), "v1.0", "powershell.exe")
	out, err := hidden(ps, "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-EncodedCommand", enc).CombinedOutput()
	return string(out), err
}

type winSystem struct{}

func newSystem() System { return winSystem{} }

const ensureDNSScript = `
$ErrorActionPreference = 'SilentlyContinue'
$useV6 = %s
$changed = $false
foreach ($a in @(Get-NetAdapter | Where-Object { $_.Status -eq 'Up' })) {
  $i = $a.ifIndex
  $v4 = @((Get-DnsClientServerAddress -InterfaceIndex $i -AddressFamily IPv4).ServerAddresses) -join ','
  $o6 = Get-DnsClientServerAddress -InterfaceIndex $i -AddressFamily IPv6
  $v6 = @($o6.ServerAddresses) -join ','
  $good = ($v4 -eq '127.0.0.1') -and ((-not $useV6) -or ($null -eq $o6) -or ($v6 -eq '::1'))
  if (-not $good) {
    if ($useV6 -and ($null -ne $o6)) {
      Set-DnsClientServerAddress -InterfaceIndex $i -ServerAddresses @('127.0.0.1', '::1')
    } else {
      Set-DnsClientServerAddress -InterfaceIndex $i -ServerAddresses @('127.0.0.1')
    }
    $changed = $true
    Write-Output ("SET " + $a.Name)
  }
  $key = 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\' + $a.InterfaceGuid
  $d = (Get-ItemProperty -Path $key -Name DhcpNameServer).DhcpNameServer
  if ($d) { Write-Output ("DHCP " + $d) }
}
if ($changed) { Clear-DnsClientCache }
Write-Output "DONE"
`

func (winSystem) EnsureDNS(v6 bool) ([]string, error) {
	flag := "$false"
	if v6 {
		flag = "$true"
	}
	out, err := powershell(fmt.Sprintf(ensureDNSScript, flag))
	if !strings.Contains(out, "DONE") {
		if err == nil {
			err = fmt.Errorf("powershell: %s", strings.TrimSpace(out))
		}
		return nil, err
	}
	var dns []string
	for _, line := range strings.Split(out, "\n") {
		line = strings.TrimSpace(line)
		if strings.HasPrefix(line, "SET ") {
			logf("dns pointed at JuBan: %s", line[4:])
		}
		if strings.HasPrefix(line, "DHCP ") {
			dns = append(dns, strings.FieldsFunc(line[5:], func(r rune) bool { return r == ' ' || r == ',' })...)
		}
	}
	return dns, nil
}

const restoreDNSScript = `
$ErrorActionPreference = 'SilentlyContinue'
foreach ($a in @(Get-NetAdapter -IncludeHidden)) {
  $s = @(Get-DnsClientServerAddress -InterfaceIndex $a.ifIndex | ForEach-Object { $_.ServerAddresses })
  if (($s -contains '127.0.0.1') -or ($s -contains '::1')) {
    Set-DnsClientServerAddress -InterfaceIndex $a.ifIndex -ResetServerAddresses
    Write-Output ("RESET " + $a.Name)
  }
}
Clear-DnsClientCache
Write-Output "DONE"
`

func (winSystem) RestoreDNS() error {
	out, err := powershell(restoreDNSScript)
	if !strings.Contains(out, "DONE") {
		if err == nil {
			err = fmt.Errorf("powershell: %s", strings.TrimSpace(out))
		}
		return err
	}
	for _, line := range strings.Split(out, "\n") {
		if l := strings.TrimSpace(line); strings.HasPrefix(l, "RESET ") {
			logf("dns put back to automatic: %s", l[6:])
		}
	}
	return nil
}

const policiesOnScript = `
$ErrorActionPreference = 'SilentlyContinue'
foreach ($p in @('HKLM:\SOFTWARE\Policies\Google\Chrome', 'HKLM:\SOFTWARE\Policies\Microsoft\Edge', 'HKLM:\SOFTWARE\Policies\BraveSoftware\Brave')) {
  if (-not (Test-Path $p)) { New-Item -Path $p -Force | Out-Null }
  New-ItemProperty -Path $p -Name 'DnsOverHttpsMode' -Value 'off' -PropertyType String -Force | Out-Null
}
$f = 'HKLM:\SOFTWARE\Policies\Mozilla\Firefox\DNSOverHTTPS'
if (-not (Test-Path $f)) { New-Item -Path $f -Force | Out-Null }
New-ItemProperty -Path $f -Name 'Enabled' -Value 0 -PropertyType DWord -Force | Out-Null
New-ItemProperty -Path $f -Name 'Locked' -Value 1 -PropertyType DWord -Force | Out-Null
Write-Output "DONE"
`

const policiesOffScript = `
$ErrorActionPreference = 'SilentlyContinue'
foreach ($p in @('HKLM:\SOFTWARE\Policies\Google\Chrome', 'HKLM:\SOFTWARE\Policies\Microsoft\Edge', 'HKLM:\SOFTWARE\Policies\BraveSoftware\Brave')) {
  Remove-ItemProperty -Path $p -Name 'DnsOverHttpsMode'
}
$f = 'HKLM:\SOFTWARE\Policies\Mozilla\Firefox\DNSOverHTTPS'
Remove-ItemProperty -Path $f -Name 'Enabled'
Remove-ItemProperty -Path $f -Name 'Locked'
Write-Output "DONE"
`

func (winSystem) SetBrowserPolicies(on bool) error {
	script := policiesOffScript
	if on {
		script = policiesOnScript
	}
	out, err := powershell(script)
	if !strings.Contains(out, "DONE") && err == nil {
		err = fmt.Errorf("powershell: %s", strings.TrimSpace(out))
	}
	return err
}

func shortcutPaths() []string {
	pd := os.Getenv("ProgramData")
	if pd == "" {
		pd = `C:\ProgramData`
	}
	pub := os.Getenv("PUBLIC")
	if pub == "" {
		pub = `C:\Users\Public`
	}
	return []string{
		filepath.Join(pd, `Microsoft\Windows\Start Menu\Programs\JuBan.url`),
		filepath.Join(pub, `Desktop\JuBan.url`),
	}
}

func (winSystem) Uninstall() error {
	hidden(system32("schtasks.exe"), "/Delete", "/TN", taskName, "/F").Run()
	hidden(system32("schtasks.exe"), "/Delete", "/TN", safetyTaskName, "/F").Run()
	for _, p := range shortcutPaths() {
		os.Remove(p)
	}
	// The program and its data folder can only be deleted after this process exits,
	// so leave that to a small command that waits a few seconds first.
	line := fmt.Sprintf(`%s /c "ping -n 6 127.0.0.1 >nul & rmdir /s /q "%s" & rmdir /s /q "%s""`,
		system32("cmd.exe"), programDir(), dataDir())
	for _, flags := range []uint32{createNoWindow | createBreakawayFromJob, createNoWindow} {
		c := exec.Command(system32("cmd.exe"))
		c.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CmdLine: line, CreationFlags: flags}
		if err := c.Start(); err == nil {
			c.Process.Release()
			return nil
		}
	}
	return fmt.Errorf("could not schedule file removal")
}

// ---- small Windows helpers used by the installer ----

var (
	shell32           = syscall.NewLazyDLL("shell32.dll")
	user32            = syscall.NewLazyDLL("user32.dll")
	procIsUserAnAdmin = shell32.NewProc("IsUserAnAdmin")
	procShellExecute  = shell32.NewProc("ShellExecuteW")
	procMessageBox    = user32.NewProc("MessageBoxW")
)

func isAdmin() bool {
	r, _, _ := procIsUserAnAdmin.Call()
	return r != 0
}

const (
	mbIconError = 0x10
	mbIconInfo  = 0x40
)

func messageBox(text string, icon uintptr) {
	t, _ := syscall.UTF16PtrFromString(text)
	c, _ := syscall.UTF16PtrFromString("JuBan")
	procMessageBox.Call(0, uintptr(unsafe.Pointer(t)), uintptr(unsafe.Pointer(c)), icon)
}

// runElevated starts this program again with administrator rights (Windows asks the user).
func runElevated(args string) error {
	exe, err := os.Executable()
	if err != nil {
		return err
	}
	verb, _ := syscall.UTF16PtrFromString("runas")
	file, _ := syscall.UTF16PtrFromString(exe)
	params, _ := syscall.UTF16PtrFromString(args)
	r, _, _ := procShellExecute.Call(0, uintptr(unsafe.Pointer(verb)), uintptr(unsafe.Pointer(file)),
		uintptr(unsafe.Pointer(params)), 0, 1)
	if r <= 32 {
		return fmt.Errorf("ShellExecute failed (%d)", r)
	}
	return nil
}

func openBrowser(url string) {
	hidden(system32("rundll32.exe"), "url.dll,FileProtocolHandler", url).Start()
}
