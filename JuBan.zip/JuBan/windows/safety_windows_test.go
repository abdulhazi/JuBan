//go:build windows

package main

import (
	"encoding/xml"
	"fmt"
	"strings"
	"testing"
)

func TestSafetyScript(t *testing.T) {
	s := safetyScript(`C:\Program Files\JuBan\JuBan.exe`)
	for _, want := range []string{`Test-Path -LiteralPath 'C:\Program Files\JuBan\JuBan.exe'`, "'127.0.0.1'", "'::1'", "-ResetServerAddresses", "53053", "Start-Sleep"} {
		if !strings.Contains(s, want) {
			t.Errorf("missing %q", want)
		}
	}
	if strings.Contains(s, `"`) {
		t.Error("script must not contain double quotes (it is wrapped in them)")
	}
	if strings.Contains(xmlEscape(s), "<") {
		t.Error("xml")
	}
}

func TestScreenTaskAndScript(t *testing.T) {
	x := fmt.Sprintf(screenTaskXML, xmlEscape(`C:\Program Files\JuBan\JuBan.exe`))
	if err := xml.Unmarshal([]byte(strings.Replace(x, `encoding="UTF-16"`, `encoding="UTF-8"`, 1)), new(struct{ XMLName xml.Name })); err != nil {
		t.Errorf("screen task XML: %v", err)
	}
	s := fmt.Sprintf(readerScript, 1234)
	if strings.Contains(s, "%!") || !strings.Contains(s, "$parent = 1234") {
		t.Error("reader script not filled in")
	}
}
