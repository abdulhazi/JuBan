//go:build windows

package main

import (
	"strings"
	"testing"
)

func TestSafetyScript(t *testing.T) {
	s := safetyScript(`C:\Program Files\JuBan\JuBan.exe`)
	for _, want := range []string{`Test-Path -LiteralPath 'C:\Program Files\JuBan\JuBan.exe'`, "'127.0.0.1'", "'::1'", "-ResetServerAddresses"} {
		if !strings.Contains(s, want) {
			t.Errorf("missing %q", want)
		}
	}
	if strings.Contains(s, `"`) {
		t.Error("script must not contain double quotes (it is wrapped in them)")
	}
	if strings.Contains(xmlEscape(s), "<") {
		t.Error("xml")
	}
}
