//go:build windows

package main

import (
	"bufio"
	"encoding/base64"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"syscall"
	"time"
	"unicode/utf16"
)

const screenLockAddr = "127.0.0.1:53054" // a second copy of the helper in the same session cannot start

var (
	procGetForeground = user32.NewProc("GetForegroundWindow")
	procKeybdEvent    = user32.NewProc("keybd_event")
)

// screenCommand is "JuBan.exe screen": started by Windows when someone signs in.
func screenCommand() {
	if f, err := os.OpenFile(filepath.Join(os.TempDir(), "juban-screen.log"), os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o600); err == nil {
		log.SetOutput(f)
	}
	ln, err := net.Listen("tcp4", screenLockAddr)
	if err != nil {
		return // already running for this person
	}
	defer ln.Close()
	key := ""
	for key == "" {
		if b, err := os.ReadFile(filepath.Join(dataDir(), "agent.key")); err == nil {
			key = strings.TrimSpace(string(b))
		}
		if key == "" {
			time.Sleep(10 * time.Second) // JuBan has not started yet
		}
	}
	log.Printf("screen helper %s starting", version)

	api := &agentAPI{key: key, c: http.Client{Timeout: 4 * time.Second}}
	sc := NewScreen(api.ask, closeTabIn)
	for {
		runReader(sc, api)
		time.Sleep(5 * time.Second)
	}
}

type agentAPI struct {
	key     string
	c       http.Client
	on      bool
	checked time.Time
}

func (a *agentAPI) do(method, path, body string) (string, bool) {
	req, err := http.NewRequest(method, uiURL+strings.TrimPrefix(path, "/"), strings.NewReader(body))
	if err != nil {
		return "", false
	}
	req.Header.Set("X-JuBan-Agent", a.key)
	r, err := a.c.Do(req)
	if err != nil {
		return "", false
	}
	defer r.Body.Close()
	b, _ := io.ReadAll(io.LimitReader(r.Body, 64))
	return strings.TrimSpace(string(b)), r.StatusCode == 200
}

func (a *agentAPI) ask(host string) bool {
	s, ok := a.do("POST", "agent/ju", host)
	log.Printf("ju page %s -> %s", host, s)
	return ok && s == "ju"
}

// enabled asks JuBan (at most every 15 seconds) whether the screen check is switched on.
func (a *agentAPI) enabled() bool {
	if time.Since(a.checked) > 15*time.Second {
		s, ok := a.do("GET", "agent/state", "")
		a.on, a.checked = ok && s == "1", time.Now()
	}
	return a.on
}

func runReader(sc *Screen, api *agentAPI) {
	script := fmt.Sprintf(readerScript, os.Getpid())
	u := utf16.Encode([]rune(script))
	b := make([]byte, 0, len(u)*2)
	for _, c := range u {
		b = append(b, byte(c), byte(c>>8))
	}
	enc := base64.StdEncoding.EncodeToString(b)
	ps := filepath.Join(system32("WindowsPowerShell"), "v1.0", "powershell.exe")
	cmd := exec.Command(ps, "-NoProfile", "-NonInteractive", "-WindowStyle", "Hidden", "-ExecutionPolicy", "Bypass", "-EncodedCommand", enc)
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: createNoWindow}
	out, err := cmd.StdoutPipe()
	if err != nil {
		return
	}
	if err := cmd.Start(); err != nil {
		log.Printf("reader: %v", err)
		return
	}
	defer func() { cmd.Process.Kill(); cmd.Wait() }()
	r := bufio.NewReaderSize(out, 1<<20)
	for {
		line, err := r.ReadString('\n')
		if len(line) > 0 && api.enabled() {
			if l, ok := ParseScreenLine(line); ok {
				sc.Handle(l)
			}
		}
		if err != nil {
			return
		}
	}
}

func foreground() uintptr {
	h, _, _ := procGetForeground.Call()
	return h
}

// closeTabIn presses Ctrl+W, but only if that window is still the one in front.
func closeTabIn(window string) {
	want, err := strconv.ParseInt(window, 10, 64)
	if err != nil || uintptr(want) != foreground() {
		return
	}
	const (
		vkControl = 0x11
		vkW       = 0x57
		keyUp     = 0x0002
	)
	key := func(vk uintptr, flags uintptr) { procKeybdEvent.Call(vk, 0, flags, 0) }
	key(vkControl, 0)
	key(vkW, 0)
	key(vkW, keyUp)
	key(vkControl, keyUp)
	log.Printf("closed a tab")
}

// readerScript runs inside one PowerShell process and prints a line for the browser window in
// front every two seconds: JB1|window|address|title|text (the three texts in base64).
// It uses Windows UI Automation, the same thing screen readers use. %d is JuBan's process id:
// the script stops by itself when JuBan is gone.
const readerScript = `
$ErrorActionPreference = 'SilentlyContinue'
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public class JBW{[DllImport("user32.dll")]public static extern IntPtr GetForegroundWindow();}'
$parent = %d
$AE = [System.Windows.Automation.AutomationElement]
$CT = [System.Windows.Automation.ControlType]
$DS = [System.Windows.Automation.TreeScope]::Descendants
$utf8 = New-Object System.Text.UTF8Encoding($false)
function B([string]$s) { [Convert]::ToBase64String($utf8.GetBytes($s)) }
$editC = New-Object System.Windows.Automation.PropertyCondition($AE::ControlTypeProperty, $CT::Edit)
$docC = New-Object System.Windows.Automation.PropertyCondition($AE::ControlTypeProperty, $CT::Document)
$textC = New-Object System.Windows.Automation.PropertyCondition($AE::ControlTypeProperty, $CT::Text)
$out = [Console]::Out
while ($true) {
  Start-Sleep -Milliseconds 2000
  if (-not (Get-Process -Id $parent -ErrorAction SilentlyContinue)) { exit }
  try {
    $h = [JBW]::GetForegroundWindow()
    if ($h -eq [IntPtr]::Zero) { continue }
    $root = $AE::FromHandle($h)
    $cls = $root.Current.ClassName
    if ($cls -ne 'Chrome_WidgetWin_1' -and $cls -ne 'MozillaWindowClass') { continue }
    $addr = ''
    $e = $root.FindFirst($DS, $editC)
    if ($e) { $vp = $null; if ($e.TryGetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern, [ref]$vp)) { $addr = $vp.Current.Value } }
    if ([string]::IsNullOrWhiteSpace($addr)) { continue }
    $text = ''
    $d = $root.FindFirst($DS, $docC)
    if ($d) {
      $tp = $null
      if ($d.TryGetCurrentPattern([System.Windows.Automation.TextPattern]::Pattern, [ref]$tp)) { $text = $tp.DocumentRange.GetText(60000) }
      if ([string]::IsNullOrWhiteSpace($text)) {
        $sb = New-Object System.Text.StringBuilder
        $all = $d.FindAll($DS, $textC)
        $n = [Math]::Min($all.Count, 800)
        for ($i = 0; $i -lt $n; $i++) { [void]$sb.Append($all.Item($i).Current.Name).Append([char]10) }
        $text = $sb.ToString()
      }
    }
    $out.WriteLine('JB1|' + $h.ToInt64() + '|' + (B $addr) + '|' + (B $root.Current.Name) + '|' + (B $text))
    $out.Flush()
  } catch { }
}
`
