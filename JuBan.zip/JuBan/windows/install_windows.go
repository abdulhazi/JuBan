//go:build windows

package main

import (
	"encoding/xml"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"syscall"
	"time"
	"unicode/utf16"
)

// launch is what happens on double-click.
func launch() {
	if runningVersion() == version {
		openBrowser(uiURL)
		return
	}
	// Not installed, not running, or an older version: installing needs admin rights.
	if isAdmin() {
		if err := install(); err != nil {
			messageBox("JuBan could not be installed:\n\n"+err.Error(), mbIconError)
			return
		}
	} else if err := runElevated("install"); err != nil {
		messageBox("JuBan needs administrator permission to install.\n\nJuBan butuh izin administrator untuk dipasang.", mbIconError)
		return
	}
	if waitForVersion(version, 2*time.Minute) {
		openBrowser(uiURL)
	} else {
		messageBox("JuBan was installed but did not start. Restart the computer, then open JuBan from the Start menu.\n\n"+
			"JuBan sudah terpasang tetapi belum berjalan. Nyalakan ulang komputer, lalu buka JuBan dari menu Start.", mbIconError)
	}
}

// installCommand runs elevated (started by launch).
func installCommand() {
	if !isAdmin() {
		messageBox("JuBan needs administrator permission to install.", mbIconError)
		return
	}
	if err := install(); err != nil {
		messageBox("JuBan could not be installed:\n\n"+err.Error(), mbIconError)
	}
}

func install() error {
	self, err := os.Executable()
	if err != nil {
		return err
	}
	dir := programDir()
	dst := filepath.Join(dir, "JuBan.exe")
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return err
	}

	// Stop an older copy so its file can be replaced. Settings are kept.
	hidden(system32("schtasks.exe"), "/End", "/TN", taskName).Run()

	if !sameFile(self, dst) {
		data, err := os.ReadFile(self)
		if err != nil {
			return err
		}
		var copyErr error
		for i := 0; i < 20; i++ { // the old copy may need a moment to exit
			tmp := dst + ".new"
			if copyErr = os.WriteFile(tmp, data, 0o755); copyErr == nil {
				if copyErr = os.Rename(tmp, dst); copyErr == nil {
					break
				}
			}
			time.Sleep(500 * time.Millisecond)
		}
		if copyErr != nil {
			return fmt.Errorf("copying program: %w", copyErr)
		}
	}

	// Settings folder: everyone may read, only administrators and Windows may change.
	data := dataDir()
	os.MkdirAll(data, 0o755)
	hidden(system32("icacls.exe"), data, "/inheritance:r",
		"/grant:r", "*S-1-5-18:(OI)(CI)F", "*S-1-5-32-544:(OI)(CI)F", "*S-1-5-32-545:(OI)(CI)RX").Run()

	if err := createTask(dst); err != nil {
		return err
	}
	if err := createSafetyTask(dst); err != nil {
		logf("safety task: %v", err) // protection still works without it
	}
	for _, p := range shortcutPaths() {
		os.MkdirAll(filepath.Dir(p), 0o755)
		os.WriteFile(p, []byte("[InternetShortcut]\r\nURL="+uiURL+"\r\n"), 0o644)
	}
	hidden(system32("schtasks.exe"), "/Run", "/TN", taskName).Run()
	return nil
}

func sameFile(a, b string) bool {
	fa, err1 := os.Stat(a)
	fb, err2 := os.Stat(b)
	return err1 == nil && err2 == nil && os.SameFile(fa, fb)
}

// The scheduled task runs JuBan as SYSTEM at startup, restarts it if it stops, and
// checks every 5 minutes that it is running (a second copy just exits).
const taskXML = `<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo>
    <Description>JuBan: blocks Ju sites on this computer.</Description>
  </RegistrationInfo>
  <Triggers>
    <BootTrigger>
      <Enabled>true</Enabled>
    </BootTrigger>
    <TimeTrigger>
      <Repetition>
        <Interval>PT5M</Interval>
        <StopAtDurationEnd>false</StopAtDurationEnd>
      </Repetition>
      <StartBoundary>%s</StartBoundary>
      <Enabled>true</Enabled>
    </TimeTrigger>
  </Triggers>
  <Principals>
    <Principal id="Author">
      <UserId>S-1-5-18</UserId>
      <RunLevel>HighestAvailable</RunLevel>
    </Principal>
  </Principals>
  <Settings>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <AllowHardTerminate>true</AllowHardTerminate>
    <StartWhenAvailable>true</StartWhenAvailable>
    <RunOnlyIfNetworkAvailable>false</RunOnlyIfNetworkAvailable>
    <IdleSettings>
      <StopOnIdleEnd>false</StopOnIdleEnd>
      <RestartOnIdle>false</RestartOnIdle>
    </IdleSettings>
    <AllowStartOnDemand>true</AllowStartOnDemand>
    <Enabled>true</Enabled>
    <Hidden>false</Hidden>
    <RunOnlyIfIdle>false</RunOnlyIfIdle>
    <WakeToRun>false</WakeToRun>
    <ExecutionTimeLimit>PT0S</ExecutionTimeLimit>
    <Priority>5</Priority>
    <RestartOnFailure>
      <Interval>PT1M</Interval>
      <Count>999</Count>
    </RestartOnFailure>
  </Settings>
  <Actions Context="Author">
    <Exec>
      <Command>%s</Command>
      <Arguments>run</Arguments>
    </Exec>
  </Actions>
</Task>
`

func xmlEscape(s string) string {
	var b strings.Builder
	xml.EscapeText(&b, []byte(s))
	return b.String()
}

func createTask(exe string) error {
	start := time.Now().Add(-time.Hour).Format("2006-01-02T15:04:05")
	text := fmt.Sprintf(taskXML, start, xmlEscape(exe))
	err := registerTaskXML(taskName, text)
	if err == nil {
		return nil
	}
	logf("task from XML failed: %v", err)

	// Simpler fallback: start at boot only.
	c := exec.Command(system32("schtasks.exe"))
	c.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: createNoWindow,
		CmdLine: fmt.Sprintf(`schtasks.exe /Create /TN %s /TR "\"%s\" run" /SC ONSTART /RU SYSTEM /RL HIGHEST /F`, taskName, exe)}
	if out2, err2 := c.CombinedOutput(); err2 != nil {
		return fmt.Errorf("could not create the startup task: %v %s", err2, strings.TrimSpace(string(out2)))
	}
	return nil
}

// The safety task runs every 5 minutes, separately from JuBan. If JuBan.exe has gone
// (for example removed by antivirus), the computer would still be asking JuBan for every
// site name and nothing would open. Then it puts DNS back to automatic.
const safetyTaskXML = `<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo>
    <Description>JuBan safety: keeps the internet working if JuBan has been removed.</Description>
  </RegistrationInfo>
  <Triggers>
    <BootTrigger>
      <Delay>PT2M</Delay>
      <Enabled>true</Enabled>
    </BootTrigger>
    <TimeTrigger>
      <Repetition>
        <Interval>PT5M</Interval>
        <StopAtDurationEnd>false</StopAtDurationEnd>
      </Repetition>
      <StartBoundary>%s</StartBoundary>
      <Enabled>true</Enabled>
    </TimeTrigger>
  </Triggers>
  <Principals>
    <Principal id="Author">
      <UserId>S-1-5-18</UserId>
      <RunLevel>HighestAvailable</RunLevel>
    </Principal>
  </Principals>
  <Settings>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <AllowHardTerminate>true</AllowHardTerminate>
    <StartWhenAvailable>true</StartWhenAvailable>
    <RunOnlyIfNetworkAvailable>false</RunOnlyIfNetworkAvailable>
    <IdleSettings>
      <StopOnIdleEnd>false</StopOnIdleEnd>
      <RestartOnIdle>false</RestartOnIdle>
    </IdleSettings>
    <AllowStartOnDemand>true</AllowStartOnDemand>
    <Enabled>true</Enabled>
    <Hidden>false</Hidden>
    <RunOnlyIfIdle>false</RunOnlyIfIdle>
    <WakeToRun>false</WakeToRun>
    <ExecutionTimeLimit>PT2M</ExecutionTimeLimit>
    <Priority>7</Priority>
  </Settings>
  <Actions Context="Author">
    <Exec>
      <Command>%s</Command>
      <Arguments>%s</Arguments>
    </Exec>
  </Actions>
</Task>
`

// safetyScript resets only adapters that point at JuBan, and only if JuBan.exe is missing.
func safetyScript(exe string) string {
	return `if (-not (Test-Path -LiteralPath '` + strings.ReplaceAll(exe, "'", "''") + `')) { ` +
		`Get-DnsClientServerAddress | Where-Object { ($_.ServerAddresses -contains '127.0.0.1') -or ($_.ServerAddresses -contains '::1') } | ` +
		`ForEach-Object { Set-DnsClientServerAddress -InterfaceIndex $_.InterfaceIndex -ResetServerAddresses }; Clear-DnsClientCache }`
}

func createSafetyTask(exe string) error {
	ps := filepath.Join(system32("WindowsPowerShell"), "v1.0", "powershell.exe")
	args := `-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -Command "` + safetyScript(exe) + `"`
	start := time.Now().Add(-time.Hour).Format("2006-01-02T15:04:05")
	text := fmt.Sprintf(safetyTaskXML, start, xmlEscape(ps), xmlEscape(args))
	return registerTaskXML(safetyTaskName, text)
}

// registerTaskXML writes the task definition as UTF-16 (what schtasks expects) and registers it.
func registerTaskXML(name, text string) error {
	u := utf16.Encode([]rune(text))
	b := []byte{0xFF, 0xFE}
	for _, c := range u {
		b = append(b, byte(c), byte(c>>8))
	}
	tmp := filepath.Join(os.TempDir(), "juban-"+name+".xml")
	if err := os.WriteFile(tmp, b, 0o644); err != nil {
		return err
	}
	defer os.Remove(tmp)
	out, err := hidden(system32("schtasks.exe"), "/Create", "/TN", name, "/XML", tmp, "/F").CombinedOutput()
	if err != nil {
		return fmt.Errorf("%v %s", err, strings.TrimSpace(string(out)))
	}
	return nil
}

// restoreDNSCommand is the emergency way back if JuBan is broken and the internet is gone.
func restoreDNSCommand() {
	if runningVersion() != "" {
		openBrowser(uiURL)
		messageBox("JuBan is running. Turn it off from its page (Request turn-off).\n\n"+
			"JuBan sedang berjalan. Matikan dari halamannya (Ajukan penonaktifan).", mbIconInfo)
		return
	}
	if !isAdmin() {
		if err := runElevated("restore-dns"); err != nil {
			messageBox("Administrator permission is needed.", mbIconError)
		}
		return
	}
	if err := (winSystem{}).RestoreDNS(); err != nil {
		messageBox("Could not restore the internet settings:\n\n"+err.Error(), mbIconError)
		return
	}
	messageBox("Internet settings are back to automatic.\n\nPengaturan internet sudah kembali otomatis.", mbIconInfo)
}
