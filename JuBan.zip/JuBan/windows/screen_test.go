package main

import (
	"encoding/base64"
	"net/http"
	"strings"
	"testing"
	"time"
)

const juText = "DEWA33 Slot Gacor Hari Ini. Situs slot online terpercaya, bocoran rtp live, pola gacor, " +
	"maxwin setiap hari. Daftar slot dan login slot, bonus new member 100, deposit pulsa tanpa potongan. " +
	"Pragmatic Play, PG Soft, Habanero, Joker gaming, live casino, sabung ayam, togel online."

const newsText = "Polisi menangkap pelaku judi online dan situs slot ilegal. Kominfo memblokir ribuan situs. " +
	"Bahaya judi online: kecanduan, kerugian keluarga, dan dampak hukum bagi pelaku. Satgas berantas judi online " +
	"mengimbau masyarakat untuk melapor. Artikel ini membahas dampak sosial dan cara berhenti."

func TestHostFromAddress(t *testing.T) {
	cases := map[string]string{
		"gass.dewa33hi.com":                "gass.dewa33hi.com",
		"https://www.Example.com/path?q=1": "example.com",
		"example.com/a":                    "example.com",
		"http://127.0.0.1:53053/":          "", // IP address
		"localhost:3000":                   "",
		"slot gacor hari ini":              "", // a search typed in the bar
		"":                                 "",
		"chrome://settings":                "", // no dot in the name
		"https://a.b.example.co.id:8443/x": "a.b.example.co.id",
	}
	for in, want := range cases {
		if got := HostFromAddress(in); got != want {
			t.Errorf("HostFromAddress(%q) = %q, want %q", in, got, want)
		}
	}
}

func TestScreenIsJu(t *testing.T) {
	if !ScreenIsJu("DEWA33 - Situs Slot Gacor Online", juText) {
		t.Error("a Ju page was not detected")
	}
	if ScreenIsJu("Bahaya judi online - Kompas", newsText) {
		t.Error("a news page about Ju was blocked")
	}
	if ScreenIsJu("Meeting - Zoom", "Hello everyone, welcome to the group. Please share your week. Thanks for coming.") {
		t.Error("an ordinary page was blocked")
	}
}

func TestParseScreenLine(t *testing.T) {
	b := func(s string) string { return base64.StdEncoding.EncodeToString([]byte(s)) }
	l, ok := ParseScreenLine("JB1|123|" + b("a.com") + "|" + b("Judul é") + "|" + b("isi\nbaris") + "\r\n")
	if !ok || l.Window != "123" || l.Address != "a.com" || l.Title != "Judul é" || l.Doc != "isi\nbaris" {
		t.Errorf("bad parse: %+v %v", l, ok)
	}
	if _, ok := ParseScreenLine("garbage"); ok {
		t.Error("garbage accepted")
	}
}

func TestScreenHandle(t *testing.T) {
	var asked, closed []string
	accept := true
	now := time.Date(2026, 11, 16, 12, 0, 0, 0, time.UTC)
	s := NewScreen(func(h string) bool { asked = append(asked, h); return accept }, func(w string) { closed = append(closed, w) })
	s.Now = func() time.Time { return now }

	// A Ju page: JuBan is asked and the tab is closed.
	if !s.Handle(ScreenLine{Window: "7", Address: "https://gass.dewa33hi.com/", Title: "DEWA33 Slot Gacor", Doc: juText}) {
		t.Fatal("Ju page not handled")
	}
	if len(asked) != 1 || asked[0] != "gass.dewa33hi.com" || len(closed) != 1 || closed[0] != "7" {
		t.Fatalf("asked=%v closed=%v", asked, closed)
	}
	// Right after, the same window is left alone (cool-down), then a new reading is judged again.
	now = now.Add(10 * time.Second)
	if !s.Handle(ScreenLine{Window: "7", Address: "ju2.example.net", Title: "Slot Gacor Online", Doc: juText}) {
		t.Error("second Ju page not handled after the cool-down")
	}
	// JuBan says no (the person allowed the site): nothing is closed.
	now = now.Add(10 * time.Second)
	accept = false
	n := len(closed)
	if s.Handle(ScreenLine{Window: "7", Address: "allowed.example.org", Title: "Slot Gacor Online", Doc: juText}) || len(closed) != n {
		t.Error("closed a tab JuBan refused")
	}
	// Pages that must never be touched.
	accept = true
	now = now.Add(10 * time.Second)
	for _, l := range []ScreenLine{
		{Window: "7", Address: "slot gacor hari ini", Title: "Google", Doc: juText},                // a search
		{Window: "7", Address: "http://127.0.0.1:53053/", Title: "JuBan", Doc: juText},             // JuBan's own page
		{Window: "7", Address: "https://berita.go.id/x", Title: "Slot Gacor Online", Doc: juText},  // government site
		{Window: "7", Address: "https://zoom.us/wc/join", Title: "Slot Gacor Online", Doc: juText}, // safe site
		{Window: "7", Address: "https://news.example.com/a", Title: "Bahaya judi online", Doc: newsText},
	} {
		if s.Handle(l) {
			t.Errorf("handled %q", l.Address)
		}
		now = now.Add(5 * time.Second)
	}
}

func TestAgentEndpoints(t *testing.T) {
	h := newHarness(t)
	h.post("allow", "mine.example.com") // before turning on: once on, loosening is locked
	h.post("on", "")
	key := h.app.agentKey
	if len(key) < 16 {
		t.Fatalf("no agent key: %q", key)
	}
	call := func(method, path, k, body string) (int, string) {
		req, _ := http.NewRequest(method, h.srv.URL+path, strings.NewReader(body))
		if k != "" {
			req.Header.Set("X-JuBan-Agent", k)
		}
		r, err := http.DefaultClient.Do(req)
		if err != nil {
			t.Fatal(err)
		}
		defer r.Body.Close()
		buf := make([]byte, 64)
		n, _ := r.Body.Read(buf)
		return r.StatusCode, string(buf[:n])
	}
	if c, _ := call("POST", "/agent/ju", "", "evil-ju.example.com"); c != 403 {
		t.Errorf("no key: %d", c)
	}
	if c, _ := call("POST", "/agent/ju", "wrong-wrong-wrong-wrong", "evil-ju.example.com"); c != 403 {
		t.Errorf("wrong key: %d", c)
	}
	if c, s := call("GET", "/agent/state", key, ""); c != 200 || s != "1" {
		t.Errorf("state: %d %q", c, s)
	}
	if c, s := call("POST", "/agent/ju", key, "evil-ju.example.com"); c != 200 || s != "ju" {
		t.Errorf("ju: %d %q", c, s)
	}
	if h.app.checker.Cached("evil-ju.example.com") != VerdictJu {
		t.Error("site was not remembered as Ju")
	}
	// A safe site, an IP and the person's own "always allow" are refused.
	if _, s := call("POST", "/agent/ju", key, "www.google.com"); s != "no" {
		t.Errorf("google: %q", s)
	}
	if _, s := call("POST", "/agent/ju", key, "mine.example.com"); s != "no" {
		t.Errorf("allowed site: %q", s)
	}
	// While JuBan is on, switching the screen check off is locked like the other loosening steps.
	h.post("screen", "0")
	if _, s := call("GET", "/agent/state", key, ""); s != "1" {
		t.Errorf("screen check switched off while locked: %q", s)
	}
	// Off (as it would be before JuBan is turned on) makes the helper idle.
	h.app.screenOn.Store(false)
	if _, s := call("GET", "/agent/state", key, ""); s != "0" {
		t.Errorf("state after off: %q", s)
	}
	if _, s := call("POST", "/agent/ju", key, "another-ju.example.com"); s != "no" {
		t.Errorf("accepted while off: %q", s)
	}
}

func TestAgentKeyStable(t *testing.T) {
	dir := t.TempDir()
	a, b := loadAgentKey(dir), loadAgentKey(dir)
	if a == "" || a != b {
		t.Errorf("key not stable: %q %q", a, b)
	}
}
