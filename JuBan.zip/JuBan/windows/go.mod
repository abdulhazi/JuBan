module juban

go 1.22
