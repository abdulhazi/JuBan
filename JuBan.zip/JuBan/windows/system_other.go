//go:build !windows

package main

// Stand-ins so the program can be built and tested on Linux and macOS.
// JuBan itself only does real work on Windows.

import (
	"fmt"
	"os"
	"path/filepath"
)

type noSystem struct{}

func newSystem() System                           { return noSystem{} }
func (noSystem) EnsureDNS(bool) ([]string, error) { return nil, nil }
func (noSystem) RestoreDNS() error                { return nil }
func (noSystem) SetBrowserPolicies(bool) error    { return nil }
func (noSystem) Uninstall() error                 { return nil }

func dataDir() string { return filepath.Join(os.TempDir(), "juban-dev") }

func launch() {
	fmt.Println("JuBan for Windows. On this system only `run` works (for development):")
	fmt.Println("the control page opens at", uiURL, "and nothing is blocked system-wide.")
}

func installCommand()    { fmt.Println("install: Windows only") }
func restoreDNSCommand() { fmt.Println("restore-dns: Windows only") }

func detachConsole() {}
