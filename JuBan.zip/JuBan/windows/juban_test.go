package main

import (
	"encoding/binary"
	"fmt"
	"net"
	"net/http"
	"net/http/httptest"
	"net/url"
	"os"
	"strings"
	"sync"
	"testing"
	"time"
)

// ---------- matcher: same cases as the Android test ----------

func TestMatcherSharedCases(t *testing.T) {
	list := ParseList(blocklistTxt)
	m := NewMatcher(list, []string{"contoh-diblokir.com"}, []string{"merekcontoh"}, []string{"slotted.co"}, true)
	b, err := os.ReadFile("../tools/matcher-cases.txt")
	if err != nil {
		t.Fatal(err)
	}
	n := 0
	for _, line := range strings.Split(string(b), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		f := strings.Fields(line)
		got := m.Check(f[1])
		if f[0] == "block" && got == "" {
			t.Errorf("should block %s", f[1])
		}
		if f[0] == "allow" && got != "" {
			t.Errorf("should allow %s (got %s)", f[1], got)
		}
		n++
	}
	if n < 100 {
		t.Fatalf("only %d cases read", n)
	}
	t.Logf("%d shared cases, %d listed domains", n, len(list))
}

func TestEmbeddedListMatchesAndroid(t *testing.T) {
	b, err := os.ReadFile("../app/src/main/assets/blocklist.txt")
	if err != nil {
		t.Fatal(err)
	}
	if string(b) != blocklistTxt {
		t.Fatal("windows/blocklist.txt is out of date: copy app/src/main/assets/blocklist.txt over it")
	}
}

func TestSmartRulesWithoutList(t *testing.T) {
	m := NewMatcher(nil, nil, nil, nil, true)
	for _, d := range []string{"ibiza168win.com", "x365win.net", "raja99jp.com", "wahana-win.com", "wahana888site.com"} {
		if m.Check(d) != ReasonSmart {
			t.Errorf("smart rule should catch %s", d)
		}
	}
	off := NewMatcher(nil, nil, nil, nil, false)
	if off.Check("slotgacor.xyz") != "" {
		t.Error("smart off should not apply patterns")
	}
}

func TestNormalize(t *testing.T) {
	if NormalizeDomain(" https://www.Example.com/a?b=1 ") != "example.com" {
		t.Error("normalize url")
	}
	if NormalizeDomain("not a domain") != "" || NormalizeDomain("localhost") != "" {
		t.Error("normalize junk")
	}
	if NormalizeWord(" Wahana ") != "wahana" || NormalizeWord("abc") != "" || NormalizeWord("two words") != "" {
		t.Error("normalize word")
	}
}

// ---------- DNS messages ----------

func makeQuery(id uint16, name string, qtype uint16) []byte {
	m := make([]byte, 12)
	binary.BigEndian.PutUint16(m, id)
	m[2] = 0x01 // RD
	binary.BigEndian.PutUint16(m[4:], 1)
	for _, l := range strings.Split(name, ".") {
		m = append(m, byte(len(l)))
		m = append(m, l...)
	}
	m = append(m, 0, byte(qtype>>8), byte(qtype), 0, 1)
	return m
}

func TestParseAndReply(t *testing.T) {
	m := makeQuery(0x1234, "WWW.Slot-Gacor88.com", 1)
	q, ok := ParseQuery(m)
	if !ok || q.Name != "www.slot-gacor88.com" || q.QType != 1 || q.QEnd != len(m) {
		t.Fatalf("parse: %+v %v", q, ok)
	}
	r := Reply(m, q.QEnd, rcodeNXDomain)
	if len(r) != len(m) || r[0] != 0x12 || r[1] != 0x34 || r[2]&0x80 == 0 || r[2]&0x01 == 0 || r[3]&0x0f != 3 {
		t.Fatalf("reply header % x", r[:4])
	}
	if _, ok := ParseQuery(m[:len(m)-3]); ok {
		t.Error("truncated query accepted")
	}
	if _, ok := ParseQuery(r); ok {
		t.Error("a response was parsed as a query")
	}
	if _, ok := ParseQuery([]byte{1, 2, 3}); ok {
		t.Error("short message accepted")
	}
}

// ---------- lock ----------

func TestLock(t *testing.T) {
	t0 := time.Date(2026, 11, 14, 21, 0, 0, 0, time.UTC)
	if ComputeLock(time.Time{}, t0).State != LockNone {
		t.Error("no request")
	}
	if l := ComputeLock(t0, t0.Add(time.Hour)); l.State != LockWaiting || l.Remaining != 23*time.Hour {
		t.Errorf("waiting %+v", l)
	}
	if l := ComputeLock(t0, t0.Add(24*time.Hour)); l.State != LockOpen || l.Remaining != time.Hour {
		t.Errorf("open %+v", l)
	}
	if ComputeLock(t0, t0.Add(25*time.Hour)).State != LockNone {
		t.Error("expires")
	}
	if l := ComputeLock(t0, t0.Add(-5*time.Hour)); l.State != LockWaiting || l.Remaining != 24*time.Hour {
		t.Errorf("clock moved back %+v", l)
	}
	if formatDuration(90*time.Minute+10*time.Second, "%d h %d min", "%d min") != "1 h 31 min" {
		t.Error("duration")
	}
}

// ---------- whole app: control page + DNS filter, with a fake Windows ----------

type fakeSystem struct {
	mu                      sync.Mutex
	pointed, policies, gone bool
	calls                   []string
}

func (f *fakeSystem) note(s string) { f.mu.Lock(); f.calls = append(f.calls, s); f.mu.Unlock() }
func (f *fakeSystem) EnsureDNS(v6 bool) ([]string, error) {
	f.note("ensure")
	f.mu.Lock()
	f.pointed = true
	f.mu.Unlock()
	return nil, nil
}
func (f *fakeSystem) RestoreDNS() error {
	f.note("restore")
	f.mu.Lock()
	f.pointed = false
	f.mu.Unlock()
	return nil
}
func (f *fakeSystem) SetBrowserPolicies(on bool) error {
	f.mu.Lock()
	f.policies = on
	f.mu.Unlock()
	return nil
}
func (f *fakeSystem) Uninstall() error { f.mu.Lock(); f.gone = true; f.mu.Unlock(); return nil }

// fakeUpstream answers every query with one A record 1.2.3.4.
func fakeUpstream(t *testing.T) string {
	c, err := net.ListenPacket("udp4", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { c.Close() })
	go func() {
		buf := make([]byte, 1500)
		for {
			n, from, err := c.ReadFrom(buf)
			if err != nil {
				return
			}
			q, ok := ParseQuery(buf[:n])
			if !ok {
				continue
			}
			r := Reply(buf[:n], q.QEnd, 0)
			binary.BigEndian.PutUint16(r[6:], 1)
			r = append(r, 0xc0, 12, 0, 1, 0, 1, 0, 0, 0, 60, 0, 4, 1, 2, 3, 4)
			c.WriteTo(r, from)
		}
	}()
	return c.LocalAddr().String()
}

type harness struct {
	t        *testing.T
	app      *App
	sys      *fakeSystem
	srv      *httptest.Server
	host     string
	upstream string
	clock    time.Time
}

func newHarness(t *testing.T) *harness {
	h := &harness{t: t, sys: &fakeSystem{}, clock: time.Date(2026, 11, 14, 21, 0, 0, 0, time.UTC)}
	h.app = NewApp(h.sys, t.TempDir(), ParseList(blocklistTxt))
	h.app.now = func() time.Time { return h.clock }
	h.app.DNSAddr4, h.app.DNSAddr6 = "127.0.0.1:0", ""
	h.app.SetFetcherForTest(func(string) *Page { return nil }) // no real web in tests
	h.app.Boot()
	h.upstream = fakeUpstream(t)

	ln, err := net.Listen("tcp4", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	port := ln.Addr().(*net.TCPAddr).Port
	h.srv = httptest.NewUnstartedServer(NewUI(h.app, port))
	h.srv.Listener.Close()
	h.srv.Listener = ln
	h.srv.Start()
	t.Cleanup(h.srv.Close)
	h.host = ln.Addr().String()
	return h
}

var noRedirect = &http.Client{CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }}

func (h *harness) post(action, value string) int {
	form := url.Values{"t": {h.app.token}, "a": {action}, "v": {value}}
	r, err := noRedirect.PostForm(h.srv.URL+"/do", form)
	if err != nil {
		h.t.Fatal(err)
	}
	r.Body.Close()
	return r.StatusCode
}

func (h *harness) lookup(name string) byte {
	h.app.mu.Lock()
	addr := h.app.dns.Addr4
	h.app.mu.Unlock()
	c, err := net.Dial("udp", addr)
	if err != nil {
		h.t.Fatal(err)
	}
	defer c.Close()
	c.SetDeadline(time.Now().Add(5 * time.Second))
	c.Write(makeQuery(7, name, 1))
	buf := make([]byte, 1500)
	n, err := c.Read(buf)
	if err != nil {
		h.t.Fatalf("lookup %s: %v", name, err)
	}
	return buf[:n][3] & 0x0f
}

func TestControlPageSecurity(t *testing.T) {
	h := newHarness(t)

	// Another host name (DNS rebinding) is refused.
	req, _ := http.NewRequest("GET", h.srv.URL+"/", nil)
	req.Host = "evil.example:53053"
	if r, _ := http.DefaultClient.Do(req); r.StatusCode != 403 {
		t.Errorf("foreign host: %d", r.StatusCode)
	}
	// A button press without the token is refused.
	r, _ := noRedirect.PostForm(h.srv.URL+"/do", url.Values{"a": {"on"}})
	if r.StatusCode != 403 {
		t.Errorf("no token: %d", r.StatusCode)
	}
	// A button press coming from another website is refused even with a token.
	req, _ = http.NewRequest("POST", h.srv.URL+"/do", strings.NewReader("t="+h.app.token+"&a=on"))
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	req.Header.Set("Origin", "https://evil.example")
	if r, _ := noRedirect.Do(req); r.StatusCode != 403 {
		t.Errorf("foreign origin: %d", r.StatusCode)
	}
	if h.app.View().Enabled {
		t.Fatal("protection was switched on by a refused request")
	}
	// The page itself loads, in Indonesian when asked.
	req, _ = http.NewRequest("GET", h.srv.URL+"/", nil)
	req.Header.Set("Accept-Language", "id-ID,id;q=0.9,en;q=0.8")
	r, _ = http.DefaultClient.Do(req)
	buf := make([]byte, 20000)
	n, _ := r.Body.Read(buf)
	if r.StatusCode != 200 || !strings.Contains(string(buf[:n]), "Aktifkan perlindungan") {
		t.Errorf("page: %d", r.StatusCode)
	}
	if r.Header.Get("X-Frame-Options") != "DENY" {
		t.Error("frame protection missing")
	}
}

func TestProtectionLifecycle(t *testing.T) {
	h := newHarness(t)
	if h.post("on", "") != 303 {
		t.Fatal("turn on")
	}
	h.app.SetUpstreamsForTest([]string{h.upstream}) // turning on loads the real list; use the fake one
	v := h.app.View()
	if !v.Enabled || !v.Running || !h.sys.pointed || !h.sys.policies {
		t.Fatalf("not on: %+v %+v", v, h.sys)
	}

	// Blocked and allowed lookups.
	if rc := h.lookup("ibiza168win.com"); rc != rcodeNXDomain {
		t.Errorf("listed site: rcode %d", rc)
	}
	if rc := h.lookup("www.slotgacor-baru.xyz"); rc != rcodeNXDomain {
		t.Errorf("smart: rcode %d", rc)
	}
	if rc := h.lookup("www.google.com"); rc != 0 {
		t.Errorf("normal site: rcode %d", rc)
	}
	if v := h.app.View(); v.Count != 2 || len(v.Recent) != 2 {
		t.Errorf("count %d recent %v", v.Count, v.Recent)
	}

	// Adding blocks always works; weakening is locked.
	h.post("block", "wahana")
	if rc := h.lookup("lifewahana-baru.net"); rc != rcodeNXDomain {
		t.Error("brand word not applied")
	}
	h.post("allow", "slotgacor-baru.xyz")
	h.post("smart", "")
	h.post("clear", "")
	h.post("off", "")
	h.post("uninstall", "")
	v = h.app.View()
	if len(v.Allow) != 0 || !v.Smart || len(v.Words) != 1 || !v.Enabled || h.sys.gone {
		t.Fatalf("lock bypassed: %+v", v)
	}

	// Request turn-off: still on while waiting.
	h.post("request", "")
	h.clock = h.clock.Add(23 * time.Hour)
	h.post("off", "")
	if !h.app.View().Enabled {
		t.Fatal("turned off before the delay")
	}
	// After 24 hours: unlocked. Allow and off now work.
	h.clock = h.clock.Add(90 * time.Minute)
	if h.app.View().Lock.State != LockOpen {
		t.Fatal("should be open")
	}
	h.post("allow", "slotgacor-baru.xyz")
	if len(h.app.View().Allow) != 1 {
		t.Error("allow while open")
	}
	h.post("off", "")
	v = h.app.View()
	if v.Enabled || v.Running || h.sys.pointed || h.sys.policies {
		t.Fatalf("not off: %+v %+v", v, h.sys)
	}

	// Settings survive a restart of the background program.
	app2 := NewApp(&fakeSystem{}, h.app.dataDir, nil)
	if c := app2.View(); c.Count != 3 || len(c.Words) != 1 || len(c.Allow) != 1 {
		t.Errorf("not saved: %+v", c)
	}

	h.post("uninstall", "")
	if !h.sys.gone || !h.app.View().Quitting {
		t.Error("uninstall")
	}
}

func TestRequestExpires(t *testing.T) {
	h := newHarness(t)
	h.post("on", "")
	h.post("request", "")
	h.clock = h.clock.Add(26 * time.Hour) // missed the one-hour window
	h.post("off", "")
	if !h.app.View().Enabled || h.app.View().Lock.State != LockNone {
		t.Fatal("expired request still worked")
	}
}

func TestBootResumesAndFailsSafe(t *testing.T) {
	dir := t.TempDir()
	sys := &fakeSystem{}
	a := NewApp(sys, dir, nil)
	a.DNSAddr4, a.DNSAddr6 = "127.0.0.1:0", ""
	a.Do("on", "")
	a.mu.Lock()
	a.stopLocked()
	a.mu.Unlock()

	// Restart: protection comes back by itself.
	b := NewApp(sys, dir, nil)
	b.DNSAddr4, b.DNSAddr6 = "127.0.0.1:0", ""
	b.Boot()
	if v := b.View(); !v.Running || !sys.pointed {
		t.Fatal("did not resume at boot")
	}

	// Port taken by something else: the computer must NOT be left without internet.
	busy, _ := net.ListenPacket("udp4", "127.0.0.1:0")
	defer busy.Close()
	c := NewApp(sys, dir, nil)
	c.DNSAddr4, c.DNSAddr6 = busy.LocalAddr().String(), ""
	sys.pointed = true
	c.Boot()
	if v := c.View(); v.Running || sys.pointed || v.Error == "" {
		t.Fatalf("unsafe failure: %+v pointed=%v", v, sys.pointed)
	}
}

// ---------- page check ----------

// The same sample pages as tools/PageCheckTest.java (modelled on real pages).
const (
	pgKangtoto = `<html><head><title>Daftar Agen Situs Toto Togel Online Resmi - Kangtoto</title>` +
		`<meta name="description" content="Ayo daftar agen toto togel online sekarang juga di situs Kangtoto, link resmi togel">` +
		`</head><body><nav>PAY4D TOGEL PAY4D KUPON PRAGMATIC PLAY PG SOFT JILI MEGAWIN HABANERO SPADEGAMING ` +
		`LIVE CASINO SPORT SABUNG ARCADE BERANDA PROMOSI EVENT LIVECHAT</nav><a>Masuk</a><a>Daftar Sekarang</a></body></html>`
	pgHSS = `<html><head><title>HSS303 - SITUS PROGRAM BANDAR JUDI RESMI LIVE CASINO ONLINE TERPERCAYA HARI INI 2026</title>` +
		`</head><body><h1>HSS303</h1><a>DOWNLOAD APK HSS303 FREE CHIP RP 5.000</a><a>MASUK LOGIN HSS303 NOW!</a>` +
		`<a>GABUNG DAFTAR AKUN GACOR SEKARANG JUGA!!</a></body></html>`
	pgAlexis = `<html><head><title>ALEXISTOGEL ♨ Platform Agen Resmi Situs Game Online Toto Togel 4D Amanah Tentu Bayar</title>` +
		`</head><body><a>LOGIN</a><a>DAFTAR</a> Situs TOGEL ONLINE MIN DEPO 5K | MINIMAL WD 25K ` +
		`Cara Bermain History Nomor Buku Mimpi Referral Promosi Prediksi Togel Live RTP Gacor ` +
		`TURNOVER CASINO &amp; SLOT BULANAN LINK ALTERNATIF</body></html>`
	pgThin = `<html><head><title>SLOT GACOR Hari Ini | Link Situs Slot88 Maxwin</title>` +
		`<script>var x = 'lots of code';</script></head><body><div id=app></div></body></html>`
	pgNews = `<html><head><title>Satgas Berantas Judi Online, 1.000 Situs Slot Diblokir Komdigi</title></head>` +
		`<body><p>Kementerian Komunikasi dan Digital bersama Polri memblokir situs judi online dan slot gacor. ` +
		`Para tersangka ditangkap. Redaksi.</p></body></html>`
	pgShop = `<html><head><title>Toko Sepatu Murah - Daftar dan Login untuk Bonus Member</title></head>` +
		`<body>Daftar sekarang, dapat bonus member baru. Promosi akhir tahun. Login. Hadiah menarik. ` +
		`Sepatu lari, sepatu sekolah dan sandal untuk seluruh keluarga dengan harga terjangkau. ` +
		`Gratis ongkir ke seluruh Indonesia untuk pembelian di atas seratus ribu rupiah. Hubungi kami.</body></html>`
	pgRestaurant = `<html><head><title>Manhattan Restaurant Olsztyn</title></head><body>` +
		`Welcome to our restaurant in the heart of the old town. Steaks, burgers, salads and desserts, ` +
		`freshly prepared every day. Book a table for your family dinner or business lunch. ` +
		`Open Monday to Sunday from noon until ten in the evening. Contact and reservations below.</body></html>`
	pgChallenge = `<html><head><title>Just a moment...</title></head><body>` +
		`Checking your browser before accessing the site. Enable JavaScript and cookies to continue.` +
		`<script src="/cdn-cgi/challenge-platform/h/b/orchestrate/chl_page/v1"></script></body></html>`
	pgTimeSlots = `<html><head><title>Book a time slot - Dentist Jakarta</title></head>` +
		`<body>Choose a slot. Login to manage bookings. Member discount. Jackpot of savings!</body></html>`
	pgGameStore = `<html><head><title>Board games: poker chips, roulette sets and blackjack tables</title></head>` +
		`<body>Buy a poker set. Casino night party kit. Free delivery.</body></html>`
)

func TestScorePages(t *testing.T) {
	for name, page := range map[string]string{"kangtoto": pgKangtoto, "hss303": pgHSS, "alexistogel": pgAlexis, "script-drawn": pgThin} {
		if r := ScorePage(page); !r.Ju {
			t.Errorf("%s should be a Ju page: %+v", name, r)
		}
	}
	for name, page := range map[string]string{"news": pgNews, "shop": pgShop, "restaurant": pgRestaurant,
		"time slots": pgTimeSlots, "game store": pgGameStore, "empty": ""} {
		if r := ScorePage(page); r.Ju {
			t.Errorf("%s should not be a Ju page: %+v", name, r)
		}
	}
	if !Unreadable(pgChallenge, ScorePage(pgChallenge)) {
		t.Error("protection screen should be unreadable")
	}
	if Unreadable(pgShop, ScorePage(pgShop)) || Unreadable(pgThin, ScorePage(pgThin)) {
		t.Error("shop and Ju pages are readable")
	}
	if FindRedirect(`<meta http-equiv="refresh" content="0; url=https://next.example/x">`) != "https://next.example/x" ||
		FindRedirect(`<script>window.location.href = 'https://next.example/';</script>`) != "https://next.example/" {
		t.Error("redirects")
	}
}

func TestEligible(t *testing.T) {
	yes := []string{"4.kangtotorace.com", "pumpkinhss303.it.com", "alexiscaelum.com"}
	no := []string{"www.google.com", "rr3---sn-abc.googlevideo.com", "news.detik.com", "kemdikbud.go.id",
		"api.someapp.com", "printer.local", "192.168.1.1"}
	for _, h := range yes {
		if !Eligible(h, 1) {
			t.Errorf("%s should be checked", h)
		}
	}
	for _, h := range no {
		if Eligible(h, 1) {
			t.Errorf("%s should not be checked", h)
		}
	}
	if Eligible("example.com", 16) {
		t.Error("TXT look-ups are not page visits")
	}
}

func TestResolveVia(t *testing.T) {
	up := fakeUpstream(t)
	ips := ResolveVia(func() []string { return []string{up} })("anything.example")
	if len(ips) != 1 || ips[0].String() != "1.2.3.4" {
		t.Fatalf("resolve: %v", ips)
	}
}

// pageServer serves sample pages by path; the "Host" decides nothing.
func pageServer(t *testing.T) *httptest.Server {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		switch r.URL.Path {
		case "/ju":
			fmt.Fprint(w, pgKangtoto)
		case "/hop":
			http.Redirect(w, r, "/ju", http.StatusFound)
		case "/refresh":
			fmt.Fprint(w, `<meta http-equiv=refresh content="0;url=/ju">`)
		case "/shop":
			fmt.Fprint(w, pgShop)
		case "/cloaked": // a hacked site that shows its Ju page only to Google visitors
			if strings.Contains(r.Referer(), "google.") {
				fmt.Fprint(w, pgHSS)
			} else {
				fmt.Fprint(w, pgRestaurant)
			}
		case "/challenge":
			w.WriteHeader(403)
			fmt.Fprint(w, pgChallenge)
		case "/challenge200":
			fmt.Fprint(w, pgChallenge)
		case "/error":
			w.WriteHeader(503)
			fmt.Fprint(w, pgRestaurant)
		default:
			http.NotFound(w, r)
		}
	}))
	t.Cleanup(srv.Close)
	return srv
}

func TestChecker(t *testing.T) {
	srv := pageServer(t)
	real := HTTPFetcher(nil)
	if p := real(srv.URL + "/hop"); p == nil || !strings.HasSuffix(p.FinalURL, "/ju") || !strings.Contains(p.HTML, "Kangtoto") {
		t.Fatal("redirects are followed")
	}
	if real("http://127.0.0.1:1/") != nil {
		t.Error("unreachable should be nil")
	}
	// site name -> path on the test server; https fails like a site without TLS here
	routed := func(u string) *Page {
		if strings.HasPrefix(u, "https://") {
			return nil
		}
		host := strings.TrimSuffix(strings.TrimPrefix(u, "http://"), "/")
		if strings.HasPrefix(host, "127.0.0.1") {
			return real(u)
		}
		return real(srv.URL + "/" + strings.TrimSuffix(host, ".test"))
	}
	path := t.TempDir() + "/verdicts.txt"
	ck := NewChecker(path, routed)
	want := map[string]int{"ju.test": VerdictJu, "hop.test": VerdictJu, "refresh.test": VerdictJu,
		"cloaked.test": VerdictJu, "shop.test": VerdictClean, "challenge.test": VerdictFailed,
		"challenge200.test": VerdictFailed, "error.test": VerdictFailed, "gone.test": VerdictFailed}
	for h, v := range want {
		if got := ck.Check(h).Wait(10 * time.Second); got != v {
			t.Errorf("%s: got %d want %d", h, got, v)
		}
	}
	if ck.JuCount() != 4 {
		t.Errorf("found %d", ck.JuCount())
	}
	// Remembered after a restart; clean expires after 7 days, Ju never.
	again := NewChecker(path, routed)
	if again.Cached("cloaked.test") != VerdictJu || again.Cached("shop.test") != VerdictClean {
		t.Error("not remembered")
	}
	again.now = func() time.Time { return time.Now().Add(8 * 24 * time.Hour) }
	if again.Cached("shop.test") != VerdictUnknown || again.Cached("ju.test") != VerdictJu {
		t.Error("expiry")
	}
}

func TestFirstVisitBlocked(t *testing.T) {
	h := newHarness(t)
	h.app.SetFetcherForTest(func(u string) *Page {
		switch {
		case strings.Contains(u, "namabaru-acak.com"):
			return &Page{HTML: pgAlexis, FinalURL: u, Status: 200}
		case strings.Contains(u, "manhattan-restaurant.com"):
			return &Page{HTML: pgRestaurant, FinalURL: u, Status: 200}
		}
		return nil
	})
	h.post("on", "")
	h.app.SetUpstreamsForTest([]string{h.upstream})

	start := time.Now()
	if rc := h.lookup("namabaru-acak.com"); rc != rcodeNXDomain {
		t.Errorf("Ju site on first visit: rcode %d", rc)
	}
	if d := time.Since(start); d > 2*time.Second {
		t.Errorf("took %v", d)
	}
	if rc := h.lookup("www.manhattan-restaurant.com"); rc != 0 {
		t.Errorf("normal site: rcode %d", rc)
	}
	if rc := h.lookup("namabaru-acak.com"); rc != rcodeNXDomain {
		t.Error("second visit")
	}
	if v := h.app.View(); v.Found != 1 || !v.PageCheck {
		t.Errorf("found %d", v.Found)
	}
	// Switching page check off is locked while protection is on.
	h.post("page", "")
	if !h.app.View().PageCheck {
		t.Error("page check switched off while locked")
	}
	// "Always allow" beats the page check (once unlocked).
	h.post("request", "")
	h.clock = h.clock.Add(24*time.Hour + time.Minute)
	h.post("allow", "namabaru-acak.com")
	if rc := h.lookup("namabaru-acak.com"); rc != 0 {
		t.Errorf("always allow: rcode %d", rc)
	}
}
