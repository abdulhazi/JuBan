package main

import (
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"log"
	"net"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

// System is everything that touches Windows settings. The real one is in
// system_windows.go; tests use a fake.
type System interface {
	// EnsureDNS points every connected network adapter at JuBan (fixing any that were
	// changed) and returns the DNS servers the networks themselves hand out.
	EnsureDNS(v6 bool) (networkDNS []string, err error)
	// RestoreDNS puts adapters that point at JuBan back to automatic DNS.
	RestoreDNS() error
	// SetBrowserPolicies switches the browsers' own "secure DNS" option off (on=true)
	// so they cannot go around JuBan, or removes that rule again (on=false).
	SetBrowserPolicies(on bool) error
	// Uninstall removes the scheduled task, shortcuts and files.
	Uninstall() error
}

// Config is saved to config.json. Only the background process writes it.
type Config struct {
	Enabled      bool     `json:"enabled"`
	Smart        bool     `json:"smart"`
	Block        []string `json:"block"`
	Words        []string `json:"words"`
	Allow        []string `json:"allow"`
	OffRequest   int64    `json:"offRequest"` // unix ms, 0 = none
	PageCheckOff bool     `json:"pageCheckOff"`
	BlockedCount int64    `json:"blockedCount"`
}

var publicDNS = []string{"8.8.8.8", "1.1.1.1", "2001:4860:4860::8888", "2606:4700:4700::1111"}

type App struct {
	sys     System
	dataDir string
	listed  []string
	now     func() time.Time

	// Where the DNS filter listens. Real use: port 53 on loopback.
	DNSAddr4, DNSAddr6 string

	token       string
	matcher     atomic.Pointer[Matcher]
	upstreams   atomic.Pointer[[]string]
	count       atomic.Int64 // sites blocked so far
	checker     *Checker
	pageCheckOn atomic.Bool

	// Indonesia's list through the network's own DNS (see ispcheck.go).
	isp          IspCheck
	ispBlocked   sync.Map // host -> unix ms until which it stays blocked
	networkDNS   atomic.Pointer[[]string]
	ispKey       string
	ispLearnedAt time.Time
	ispState     atomic.Int32 // 0 checking, 1 active, 2 not available
	savedCnt     int64

	// mu guards the settings and is held during every change to Windows settings,
	// so turning on and off can never interleave. Lookups never take it.
	mu        sync.Mutex
	cfg       Config
	dns       *DNSServer
	lastError string
	quitting  bool

	recentMu      sync.Mutex
	recent        []string
	lastBlocked   string
	lastBlockedAt time.Time
}

func NewApp(sys System, dataDir string, listed []string) *App {
	a := &App{
		sys:      sys,
		dataDir:  dataDir,
		listed:   listed,
		now:      time.Now,
		DNSAddr4: "127.0.0.1:53",
		DNSAddr6: "[::1]:53",
		cfg:      Config{Smart: true},
	}
	var b [16]byte
	rand.Read(b[:])
	a.token = hex.EncodeToString(b[:])
	a.loadConfig()
	a.count.Store(a.cfg.BlockedCount)
	a.savedCnt = a.cfg.BlockedCount
	a.setUpstreams(nil)
	a.rebuildMatcher()
	a.pageCheckOn.Store(!a.cfg.PageCheckOff)
	a.checker = NewChecker(filepath.Join(dataDir, "verdicts.txt"), HTTPFetcher(ResolveVia(a.Upstreams)))
	return a
}

// SetFetcherForTest replaces how pages are opened (tests only).
func (a *App) SetFetcherForTest(f Fetcher) {
	a.checker = NewChecker(filepath.Join(a.dataDir, "verdicts.txt"), f)
}

// ---- config ----

func (a *App) configPath() string { return filepath.Join(a.dataDir, "config.json") }

func (a *App) loadConfig() {
	b, err := os.ReadFile(a.configPath())
	if err != nil {
		return
	}
	var c Config
	if json.Unmarshal(b, &c) == nil {
		a.cfg = c
	}
}

// saveConfig must be called with a.mu held.
func (a *App) saveConfig() {
	a.cfg.BlockedCount = a.count.Load()
	b, _ := json.MarshalIndent(a.cfg, "", "  ")
	os.MkdirAll(a.dataDir, 0o755)
	tmp := a.configPath() + ".tmp"
	if err := os.WriteFile(tmp, b, 0o644); err != nil {
		log.Printf("save config: %v", err)
		return
	}
	if err := os.Rename(tmp, a.configPath()); err != nil {
		log.Printf("save config: %v", err)
		return
	}
	a.savedCnt = a.cfg.BlockedCount
}

// rebuildMatcher must be called with a.mu held (or before the app is shared).
func (a *App) rebuildMatcher() {
	a.matcher.Store(NewMatcher(a.listed, a.cfg.Block, a.cfg.Words, a.cfg.Allow, a.cfg.Smart))
}

func (a *App) Matcher() *Matcher { return a.matcher.Load() }

func (a *App) Upstreams() []string {
	if p := a.upstreams.Load(); p != nil {
		return *p
	}
	return nil
}

// setUpstreams: the network's own DNS servers first, then public ones; all asked at once.
func (a *App) setUpstreams(networkDNS []string) {
	seen := map[string]bool{}
	var ups []string
	for _, s := range append(append([]string(nil), networkDNS...), publicDNS...) {
		ip := net.ParseIP(strings.TrimSpace(s))
		if ip == nil || ip.IsLoopback() || ip.IsLinkLocalUnicast() || ip.IsUnspecified() {
			continue
		}
		hp := net.JoinHostPort(ip.String(), "53")
		if !seen[hp] {
			seen[hp] = true
			ups = append(ups, hp)
		}
	}
	a.upstreams.Store(&ups)
}

// SetUpstreamsForTest replaces the upstream list (tests only).
func (a *App) SetUpstreamsForTest(ups []string) { a.upstreams.Store(&ups) }

func (a *App) RecordBlocked(name string) {
	t := a.now()
	a.recentMu.Lock()
	defer a.recentMu.Unlock()
	// A browser asks several times for the same name; count that as one block.
	if name == a.lastBlocked && t.Sub(a.lastBlockedAt) < 10*time.Second {
		return
	}
	a.lastBlocked, a.lastBlockedAt = name, t
	a.recent = append([]string{t.Format("15:04") + "  " + name}, a.recent...)
	if len(a.recent) > 30 {
		a.recent = a.recent[:30]
	}
	a.count.Add(1)
}

// ---- lock ----

func (a *App) lockLocked() LockState { // a.mu held
	var req time.Time
	if a.cfg.OffRequest > 0 {
		req = time.UnixMilli(a.cfg.OffRequest)
	}
	l := ComputeLock(req, a.now())
	if l.State == LockNone && a.cfg.OffRequest > 0 {
		a.cfg.OffRequest = 0 // expired
		a.saveConfig()
	}
	return l
}

// lockedLocked: settings that weaken protection may not change. a.mu held.
func (a *App) lockedLocked() bool {
	return a.cfg.Enabled && a.lockLocked().State != LockOpen
}

// ---- protection on/off ----

// Boot is called once at start: resume protection if it was on.
func (a *App) Boot() {
	a.mu.Lock()
	defer a.mu.Unlock()
	if a.cfg.Enabled {
		if err := a.startLocked(); err != nil {
			log.Printf("start at boot: %v", err)
		}
	} else {
		// Never leave the computer pointed at a filter that is not running.
		a.sys.RestoreDNS()
	}
}

// startLocked starts the filter and points Windows at it. a.mu held.
func (a *App) startLocked() error {
	if a.dns == nil {
		d, err := StartDNS(a, a.DNSAddr4, a.DNSAddr6)
		if err != nil {
			a.lastError = "dns: " + err.Error()
			// Something else is using port 53. Do not cut the internet: undo our DNS setting.
			a.sys.RestoreDNS()
			return err
		}
		a.dns = d
	}
	a.lastError = ""
	if err := a.sys.SetBrowserPolicies(true); err != nil {
		log.Printf("browser policies: %v", err)
	}
	a.applyDNSLocked()
	return nil
}

func (a *App) applyDNSLocked() {
	if a.dns == nil {
		return
	}
	nd, err := a.sys.EnsureDNS(a.dns.V6)
	if err != nil {
		log.Printf("ensure dns: %v", err)
		a.lastError = "settings: " + err.Error()
		return
	}
	if strings.HasPrefix(a.lastError, "settings: ") {
		a.lastError = ""
	}
	a.setUpstreams(nd)
	a.updateNetworkDNS(nd)
}

// updateNetworkDNS keeps the network's own DNS servers and, when they change (another
// Wi-Fi) or every few hours, learns again how they answer a blocked name. a.mu held.
func (a *App) updateNetworkDNS(nd []string) {
	var list []string
	seen := map[string]bool{}
	for _, s := range nd {
		ip := net.ParseIP(strings.TrimSpace(s))
		if ip == nil || ip.IsLoopback() || ip.IsLinkLocalUnicast() || ip.IsUnspecified() {
			continue
		}
		hp := net.JoinHostPort(ip.String(), "53")
		if !seen[hp] {
			seen[hp] = true
			list = append(list, hp)
		}
	}
	key := strings.Join(list, ",")
	if key == a.ispKey && time.Since(a.ispLearnedAt) < 6*time.Hour {
		return
	}
	a.ispKey, a.ispLearnedAt = key, time.Now()
	a.networkDNS.Store(&list)
	a.isp.Reset()
	a.ispBlocked.Range(func(k, _ any) bool { a.ispBlocked.Delete(k); return true })
	if len(list) == 0 {
		a.ispState.Store(2)
		return
	}
	a.ispState.Store(0)
	go a.learnISP(list)
}

func (a *App) learnISP(list []string) {
	var pub []string
	for _, s := range publicDNS {
		pub = append(pub, net.JoinHostPort(s, "53"))
	}
	for i, probe := range ispProbes {
		q := BuildQuery(uint16(0x4a40+i), probe, 1)
		n := Exchange(q, list, false, 2*time.Second)
		g := Exchange(q, pub, false, 2*time.Second)
		a.isp.Learn(probe, ParseAnswer(n), ParseAnswer(g))
	}
	if a.isp.Active() {
		a.ispState.Store(1)
		logf("Indonesia's list: active on this network")
	} else {
		a.ispState.Store(2)
	}
}

// SetNetworkDNSForTest points the Indonesia's-list check at test servers and learns.
func (a *App) SetNetworkDNSForTest(list []string, google []string) {
	a.networkDNS.Store(&list)
	a.isp.Reset()
	for i, probe := range ispProbes {
		q := BuildQuery(uint16(0x4a40+i), probe, 1)
		a.isp.Learn(probe, ParseAnswer(Exchange(q, list, false, time.Second)), ParseAnswer(Exchange(q, google, false, time.Second)))
	}
}

// Lookup asks the normal DNS servers and, at the same time, the network's own DNS.
// blocked is true when the network's DNS blocks the name (Indonesia's list).
func (a *App) Lookup(m []byte, q Query, askNetwork, tcp bool) (answer []byte, blocked bool) {
	var fromNetwork chan []byte
	if p := a.networkDNS.Load(); askNetwork && p != nil && len(*p) > 0 && a.isp.Active() && (q.QType == 1 || q.QType == 28) {
		fromNetwork = make(chan []byte, 1)
		servers := *p
		go func() { fromNetwork <- Exchange(m, servers, false, 1500*time.Millisecond) }()
	}
	answer = Exchange(m, a.Upstreams(), tcp, 3*time.Second)
	if fromNetwork != nil {
		select {
		case n := <-fromNetwork:
			if a.isp.Blocked(ParseAnswer(n), ParseAnswer(answer)) {
				a.ispBlocked.Store(q.Name, a.now().Add(24*time.Hour).UnixMilli())
				return nil, true
			}
		case <-time.After(1500 * time.Millisecond):
		}
	}
	return answer, false
}

// IspBlockedNow: on Indonesia's list (remembered for a day).
func (a *App) IspBlockedNow(host string) bool {
	v, ok := a.ispBlocked.Load(host)
	return ok && v.(int64) > a.now().UnixMilli()
}

func (a *App) stopLocked() {
	if err := a.sys.RestoreDNS(); err != nil {
		log.Printf("restore dns: %v", err)
	}
	if err := a.sys.SetBrowserPolicies(false); err != nil {
		log.Printf("browser policies: %v", err)
	}
	if a.dns != nil {
		a.dns.Close()
		a.dns = nil
	}
}

// Tick runs every 30 seconds: re-applies DNS if someone changed it, saves the counter.
func (a *App) Tick() {
	a.mu.Lock()
	defer a.mu.Unlock()
	if a.cfg.Enabled {
		if a.dns == nil {
			a.startLocked() // port 53 may have become free
		} else {
			a.applyDNSLocked()
		}
	}
	a.lockLocked()
	if a.count.Load() != a.savedCnt {
		a.saveConfig()
	}
}

// Shutdown is used on uninstall.
func (a *App) Shutdown() {
	a.mu.Lock()
	defer a.mu.Unlock()
	a.saveConfig()
}

// ---- actions from the control page ----

const (
	msgAddedBlock = "added_block"
	msgAddedWord  = "added_word"
	msgAddedAllow = "added_allow"
	msgBadDomain  = "bad_domain"
	msgLocked     = "locked"
	msgStartFail  = "start_failed"
	msgRemoved    = "removed"
)

// Do performs one button press. It returns a flash message key (and argument).
func (a *App) Do(action, value string) (msg, arg string) {
	a.mu.Lock()
	defer a.mu.Unlock()
	switch action {
	case "on":
		if a.cfg.Enabled && a.dns != nil {
			return "", ""
		}
		a.cfg.Enabled = true
		a.cfg.OffRequest = 0
		if err := a.startLocked(); err != nil {
			a.cfg.Enabled = false
			a.saveConfig()
			return msgStartFail, err.Error()
		}
		a.saveConfig()
	case "request":
		if a.cfg.Enabled && a.lockLocked().State == LockNone {
			a.cfg.OffRequest = a.now().UnixMilli()
			a.saveConfig()
		}
	case "cancel":
		a.cfg.OffRequest = 0
		a.saveConfig()
	case "off":
		if !a.cfg.Enabled {
			return "", ""
		}
		if a.lockLocked().State != LockOpen {
			return msgLocked, ""
		}
		a.stopLocked()
		a.cfg.Enabled = false
		a.cfg.OffRequest = 0
		a.saveConfig()
	case "smart":
		on := value == "1"
		if !on && a.lockedLocked() {
			return msgLocked, ""
		}
		a.cfg.Smart = on
		a.rebuildMatcher()
		a.saveConfig()
	case "page":
		on := value == "1"
		if !on && a.lockedLocked() {
			return msgLocked, ""
		}
		a.cfg.PageCheckOff = !on
		a.pageCheckOn.Store(on)
		a.saveConfig()
	case "block":
		if d := NormalizeDomain(value); d != "" {
			a.cfg.Block = addTo(a.cfg.Block, d)
			a.cfg.Allow = removeFrom(a.cfg.Allow, d)
			a.rebuildMatcher()
			a.saveConfig()
			return msgAddedBlock, d
		}
		if w := NormalizeWord(value); w != "" {
			a.cfg.Words = addTo(a.cfg.Words, w)
			a.rebuildMatcher()
			a.saveConfig()
			return msgAddedWord, w
		}
		return msgBadDomain, ""
	case "allow":
		if a.lockedLocked() {
			return msgLocked, ""
		}
		d := NormalizeDomain(value)
		if d == "" {
			return msgBadDomain, ""
		}
		a.cfg.Allow = addTo(a.cfg.Allow, d)
		a.cfg.Block = removeFrom(a.cfg.Block, d)
		a.rebuildMatcher()
		a.saveConfig()
		return msgAddedAllow, d
	case "clear":
		if a.lockedLocked() {
			return msgLocked, ""
		}
		a.cfg.Block, a.cfg.Words, a.cfg.Allow = nil, nil, nil
		a.rebuildMatcher()
		a.saveConfig()
	case "uninstall":
		if a.cfg.Enabled {
			return msgLocked, ""
		}
		a.stopLocked()
		if err := a.sys.Uninstall(); err != nil {
			log.Printf("uninstall: %v", err)
		}
		a.quitting = true
		return msgRemoved, ""
	}
	return "", ""
}

func addTo(list []string, s string) []string {
	for _, x := range list {
		if x == s {
			return list
		}
	}
	list = append(list, s)
	sort.Strings(list)
	return list
}

func removeFrom(list []string, s string) []string {
	out := list[:0:0]
	for _, x := range list {
		if x != s {
			out = append(out, x)
		}
	}
	return out
}

// ---- what the control page shows ----

type View struct {
	Enabled, Running, Smart, Locked bool
	PageCheck                       bool
	Found                           int
	IspState                        int
	Lock                            LockState
	Count                           int64
	Recent                          []string
	Block, Words, Allow             []string
	Error                           string
	Quitting                        bool
}

func (a *App) View() View {
	a.recentMu.Lock()
	recent := append([]string(nil), a.recent...)
	a.recentMu.Unlock()
	a.mu.Lock()
	defer a.mu.Unlock()
	return View{
		Enabled:   a.cfg.Enabled,
		Running:   a.dns != nil,
		Smart:     a.cfg.Smart,
		PageCheck: !a.cfg.PageCheckOff,
		Found:     a.checker.JuCount(),
		IspState:  int(a.ispState.Load()),
		Locked:    a.lockedLocked(),
		Lock:      a.lockLocked(),
		Count:     a.count.Load(),
		Recent:    recent,
		Block:     append([]string(nil), a.cfg.Block...),
		Words:     append([]string(nil), a.cfg.Words...),
		Allow:     append([]string(nil), a.cfg.Allow...),
		Error:     a.lastError,
		Quitting:  a.quitting,
	}
}

func formatDuration(d time.Duration, hm, m string) string {
	minutes := int64((d + time.Minute - 1) / time.Minute)
	if minutes < 1 {
		minutes = 1
	}
	if minutes >= 60 {
		return fmt.Sprintf(hm, minutes/60, minutes%60)
	}
	return fmt.Sprintf(m, minutes)
}
