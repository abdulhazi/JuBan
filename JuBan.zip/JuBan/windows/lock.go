package main

import "time"

// The turn-off delay, same rules as the Android app (LockTimer.java): ask, wait
// LockDelay, then there is LockWindow to actually switch off before the request expires.

const (
	LockDelay  = 24 * time.Hour
	LockWindow = time.Hour
)

const (
	LockNone    = 0
	LockWaiting = 1
	LockOpen    = 2
)

type LockState struct {
	State     int
	Remaining time.Duration
}

// ComputeLock: request is when turn-off was requested (zero time = no request).
func ComputeLock(request, now time.Time) LockState {
	if request.IsZero() {
		return LockState{LockNone, 0}
	}
	passed := now.Sub(request)
	if passed < 0 {
		passed = 0 // clock moved back: start counting again
	}
	switch {
	case passed < LockDelay:
		return LockState{LockWaiting, LockDelay - passed}
	case passed < LockDelay+LockWindow:
		return LockState{LockOpen, LockDelay + LockWindow - passed}
	default:
		return LockState{LockNone, 0}
	}
}
