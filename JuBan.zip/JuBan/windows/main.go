// JuBan for Windows: blocks Ju sites for every browser and app on the computer.
//
// One program, three jobs:
//
//	JuBan.exe              (double-click) install or update if needed, then open the control page
//	JuBan.exe run          the background part; started by Windows at boot as SYSTEM
//	JuBan.exe screen       the browser-reading helper; started when someone signs in
//	JuBan.exe restore-dns  emergency: put internet settings back if JuBan is broken
package main

import (
	_ "embed"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"
)

const (
	version = "2.2"
	uiPort  = 53053
	uiURL   = "http://127.0.0.1:53053/"
)

// blocklist.txt is a copy of app/src/main/assets/blocklist.txt (the build copies it).
//
//go:embed blocklist.txt
var blocklistTxt string

func main() {
	cmd := ""
	if len(os.Args) > 1 {
		cmd = strings.ToLower(os.Args[1])
	}
	// These modes have nothing to show in a console, and a console window left open (or closed
	// by mistake, which ends the program) is the wrong thing to have. Let go of it.
	if cmd == "run" || cmd == "screen" || cmd == "" {
		detachConsole()
	}
	switch cmd {
	case "run":
		runBackground()
	case "install":
		installCommand()
	case "screen":
		screenCommand()
	case "restore-dns":
		restoreDNSCommand()
	case "version":
		fmt.Println(version)
	default:
		launch()
	}
}

func runBackground() {
	dir := dataDir()
	os.MkdirAll(dir, 0o755)
	setupLog(filepath.Join(dir, "juban.log"))

	// Only one copy may run: the control page port doubles as a lock.
	ln, err := net.Listen("tcp4", fmt.Sprintf("127.0.0.1:%d", uiPort))
	if err != nil {
		log.Printf("already running (%v)", err)
		return
	}
	log.Printf("JuBan %s starting", version)
	app := NewApp(newSystem(), dir, ParseList(blocklistTxt))
	srv := &http.Server{Handler: NewUI(app, uiPort), ReadHeaderTimeout: 10 * time.Second}
	go srv.Serve(ln)

	app.Boot()
	for range time.Tick(30 * time.Second) {
		if app.View().Quitting {
			app.Shutdown()
			time.Sleep(2 * time.Second) // let the "removed" page load
			log.Printf("uninstalled, exiting")
			os.Exit(0)
		}
		app.Tick()
	}
}

func logf(format string, a ...any) { log.Printf(format, a...) }

func setupLog(path string) {
	if fi, err := os.Stat(path); err == nil && fi.Size() > 512*1024 {
		os.Rename(path, path+".old")
	}
	f, err := os.OpenFile(path, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o644)
	if err != nil {
		return
	}
	log.SetOutput(f)
}

// runningVersion asks a running JuBan for its version ("" if none is running).
func runningVersion() string {
	c := http.Client{Timeout: 2 * time.Second}
	r, err := c.Get(uiURL + "version")
	if err != nil {
		return ""
	}
	defer r.Body.Close()
	b, _ := io.ReadAll(io.LimitReader(r.Body, 64))
	if r.StatusCode != 200 {
		return ""
	}
	return strings.TrimSpace(string(b))
}

func waitForVersion(want string, timeout time.Duration) bool {
	deadline := time.Now().Add(timeout)
	for time.Now().Before(deadline) {
		if runningVersion() == want {
			return true
		}
		time.Sleep(time.Second)
	}
	return false
}
