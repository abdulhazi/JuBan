//go:build !windows

package main

import "fmt"

func screenCommand() { fmt.Println("screen: Windows only") }
