package main

// A tiny DNS filter. Windows is pointed at 127.0.0.1 / ::1 as its DNS server; every
// site-name lookup arrives here. Blocked names get "no such site", everything else is
// passed to real DNS servers and the answer handed back.

import (
	"encoding/binary"
	"errors"
	"io"
	"net"
	"strings"
	"sync"
	"time"
)

type Query struct {
	Name  string
	QType uint16
	QEnd  int // offset just past the first question
}

// ParseQuery reads the first question of a DNS query message.
func ParseQuery(m []byte) (Query, bool) {
	var q Query
	if len(m) < 12 || m[2]&0x80 != 0 || binary.BigEndian.Uint16(m[4:]) < 1 {
		return q, false
	}
	var sb strings.Builder
	i := 12
	for {
		if i >= len(m) {
			return q, false
		}
		l := int(m[i])
		if l == 0 {
			i++
			break
		}
		if l&0xc0 != 0 || i+1+l > len(m) {
			return q, false
		}
		if sb.Len() > 0 {
			sb.WriteByte('.')
		}
		sb.Write(m[i+1 : i+1+l])
		i += 1 + l
	}
	if i+4 > len(m) {
		return q, false
	}
	q.Name = strings.ToLower(sb.String())
	q.QType = binary.BigEndian.Uint16(m[i:])
	q.QEnd = i + 4
	return q, true
}

const (
	rcodeServFail = 2
	rcodeNXDomain = 3
)

// Reply builds an answer with no records and the given result code.
func Reply(m []byte, qEnd int, rcode byte) []byte {
	b := make([]byte, qEnd)
	copy(b, m[:qEnd])
	b[2] = 0x80 | (b[2] & 0x79) // QR=1, keep opcode + RD
	b[3] = 0x80 | rcode         // RA=1
	binary.BigEndian.PutUint16(b[4:], 1)
	binary.BigEndian.PutUint16(b[6:], 0)
	binary.BigEndian.PutUint16(b[8:], 0)
	binary.BigEndian.PutUint16(b[10:], 0)
	return b
}

// DNSServer listens on UDP and TCP port 53 of the loopback addresses.
type DNSServer struct {
	app   *App
	udp   []net.PacketConn
	tcp   []net.Listener
	V6    bool // listening on ::1 too
	Addr4 string
	wg    sync.WaitGroup
}

func StartDNS(app *App, addr4, addr6 string) (*DNSServer, error) {
	s := &DNSServer{app: app}
	u4, err := net.ListenPacket("udp4", addr4)
	if err != nil {
		return nil, err
	}
	t4, err := net.Listen("tcp4", u4.LocalAddr().String())
	if err != nil {
		u4.Close()
		return nil, err
	}
	s.udp = append(s.udp, u4)
	s.tcp = append(s.tcp, t4)
	s.Addr4 = u4.LocalAddr().String()

	if addr6 != "" {
		if u6, err := net.ListenPacket("udp6", addr6); err == nil {
			if t6, err := net.Listen("tcp6", u6.LocalAddr().String()); err == nil {
				s.udp = append(s.udp, u6)
				s.tcp = append(s.tcp, t6)
				s.V6 = true
			} else {
				u6.Close()
			}
		}
	}
	for _, c := range s.udp {
		s.wg.Add(1)
		go s.serveUDP(c)
	}
	for _, l := range s.tcp {
		s.wg.Add(1)
		go s.serveTCP(l)
	}
	return s, nil
}

func (s *DNSServer) Close() {
	for _, c := range s.udp {
		c.Close()
	}
	for _, l := range s.tcp {
		l.Close()
	}
	s.wg.Wait()
}

func (s *DNSServer) serveUDP(c net.PacketConn) {
	defer s.wg.Done()
	buf := make([]byte, 65535)
	for {
		n, from, err := c.ReadFrom(buf)
		if err != nil {
			if errors.Is(err, net.ErrClosed) {
				return
			}
			continue // Windows reports ICMP "port unreachable" as a read error; keep going
		}
		m := append([]byte(nil), buf[:n]...)
		go func() {
			if r := s.handle(m, false); r != nil {
				c.WriteTo(r, from)
			}
		}()
	}
}

func (s *DNSServer) serveTCP(l net.Listener) {
	defer s.wg.Done()
	for {
		conn, err := l.Accept()
		if err != nil {
			if errors.Is(err, net.ErrClosed) {
				return
			}
			continue
		}
		go func() {
			defer conn.Close()
			for {
				conn.SetDeadline(time.Now().Add(10 * time.Second))
				m, err := readTCPMsg(conn)
				if err != nil {
					return
				}
				r := s.handle(m, true)
				if r == nil || writeTCPMsg(conn, r) != nil {
					return
				}
			}
		}()
	}
}

func readTCPMsg(r io.Reader) ([]byte, error) {
	var l [2]byte
	if _, err := io.ReadFull(r, l[:]); err != nil {
		return nil, err
	}
	m := make([]byte, binary.BigEndian.Uint16(l[:]))
	_, err := io.ReadFull(r, m)
	return m, err
}

func writeTCPMsg(w io.Writer, m []byte) error {
	b := make([]byte, 2+len(m))
	binary.BigEndian.PutUint16(b, uint16(len(m)))
	copy(b[2:], m)
	_, err := w.Write(b)
	return err
}

// holdFirstVisit is the longest a first visit to an unknown site waits for the page check.
const holdFirstVisit = 3 * time.Second

func (s *DNSServer) handle(m []byte, tcp bool) []byte {
	q, ok := ParseQuery(m)
	if ok {
		mt := s.app.Matcher()
		if mt.Check(q.Name) != "" {
			s.app.RecordBlocked(q.Name)
			return Reply(m, q.QEnd, rcodeNXDomain)
		}
		if s.app.IspBlockedNow(q.Name) && !mt.AllowedByUser(q.Name) {
			s.app.RecordBlocked(q.Name) // on Indonesia's list
			return Reply(m, q.QEnd, rcodeNXDomain)
		}
		ck := s.app.checker
		if ck != nil && s.app.pageCheckOn.Load() && Eligible(q.Name, q.QType) && !mt.AllowedByUser(q.Name) {
			switch ck.Cached(q.Name) {
			case VerdictJu:
				s.app.RecordBlocked(q.Name)
				return Reply(m, q.QEnd, rcodeNXDomain)
			case VerdictUnknown:
				return s.checkThenAnswer(m, q, tcp, ck)
			}
		}
	}
	askNetwork := ok && !s.app.Matcher().AllowedByUser(q.Name)
	r, blocked := s.app.Lookup(m, q, askNetwork, tcp)
	if blocked {
		s.app.RecordBlocked(q.Name)
		return Reply(m, q.QEnd, rcodeNXDomain)
	}
	if r != nil {
		return r
	}
	if ok {
		return Reply(m, q.QEnd, rcodeServFail) // fail fast instead of making the browser wait
	}
	return nil
}

// checkThenAnswer: first visit to an unknown site. Ask real DNS and read the site's front
// page at the same time; answer once the page is judged (or holdFirstVisit has passed).
func (s *DNSServer) checkThenAnswer(m []byte, q Query, tcp bool, ck *Checker) []byte {
	start := time.Now()
	call := ck.Check(q.Name)
	r, blocked := s.app.Lookup(m, q, true, tcp)
	if blocked {
		s.app.RecordBlocked(q.Name)
		return Reply(m, q.QEnd, rcodeNXDomain)
	}
	if len(r) >= 4 && r[3]&0x0f == rcodeNXDomain {
		return r // the site does not exist anyway
	}
	if call.Wait(holdFirstVisit-time.Since(start)) == VerdictJu {
		s.app.RecordBlocked(q.Name)
		return Reply(m, q.QEnd, rcodeNXDomain)
	}
	if r != nil {
		return r
	}
	return Reply(m, q.QEnd, rcodeServFail)
}

// Exchange asks every upstream server at once and returns the first answer.
func Exchange(m []byte, upstreams []string, tcp bool, timeout time.Duration) []byte {
	if len(upstreams) == 0 || len(m) < 2 {
		return nil
	}
	ch := make(chan []byte, len(upstreams))
	for _, u := range upstreams {
		go func(u string) {
			r, err := exchangeOne(m, u, tcp, timeout)
			if err != nil {
				r = nil
			}
			ch <- r
		}(u)
	}
	for range upstreams {
		if r := <-ch; r != nil {
			return r
		}
	}
	return nil
}

func exchangeOne(m []byte, server string, tcp bool, timeout time.Duration) ([]byte, error) {
	network := "udp"
	if tcp {
		network = "tcp"
	}
	c, err := net.DialTimeout(network, server, timeout)
	if err != nil {
		return nil, err
	}
	defer c.Close()
	c.SetDeadline(time.Now().Add(timeout))
	if tcp {
		if err := writeTCPMsg(c, m); err != nil {
			return nil, err
		}
		return readTCPMsg(c)
	}
	if _, err := c.Write(m); err != nil {
		return nil, err
	}
	buf := make([]byte, 65535)
	for {
		n, err := c.Read(buf)
		if err != nil {
			return nil, err
		}
		if n >= 12 && buf[0] == m[0] && buf[1] == m[1] {
			return append([]byte(nil), buf[:n]...), nil
		}
	}
}

// BuildQuery makes a standard recursive query for one name.
func BuildQuery(id uint16, name string, qtype uint16) []byte {
	m := make([]byte, 12, 64)
	binary.BigEndian.PutUint16(m, id)
	m[2] = 0x01 // recursion desired
	binary.BigEndian.PutUint16(m[4:], 1)
	for _, l := range strings.Split(strings.TrimSuffix(name, "."), ".") {
		if l == "" || len(l) > 63 {
			continue
		}
		m = append(m, byte(len(l)))
		m = append(m, l...)
	}
	return append(m, 0, byte(qtype>>8), byte(qtype), 0, 1)
}

// skipName returns the offset just past a (possibly compressed) name, or -1.
func skipName(m []byte, off int) int {
	for off < len(m) {
		l := int(m[off])
		switch {
		case l == 0:
			return off + 1
		case l&0xc0 == 0xc0:
			if off+2 > len(m) {
				return -1
			}
			return off + 2
		default:
			off += 1 + l
		}
	}
	return -1
}

// ParseAddrs reads the A (qtype 1) or AAAA (qtype 28) records of an answer.
func ParseAddrs(m []byte, qtype uint16) []net.IP {
	if len(m) < 12 || m[3]&0x0f != 0 {
		return nil
	}
	qd, an := int(binary.BigEndian.Uint16(m[4:])), int(binary.BigEndian.Uint16(m[6:]))
	off := 12
	for i := 0; i < qd; i++ {
		if off = skipName(m, off); off < 0 || off+4 > len(m) {
			return nil
		}
		off += 4
	}
	var ips []net.IP
	for i := 0; i < an; i++ {
		if off = skipName(m, off); off < 0 || off+10 > len(m) {
			return ips
		}
		typ := binary.BigEndian.Uint16(m[off:])
		rdlen := int(binary.BigEndian.Uint16(m[off+8:]))
		off += 10
		if off+rdlen > len(m) {
			return ips
		}
		if typ == qtype && (rdlen == 4 || rdlen == 16) {
			ips = append(ips, net.IP(append([]byte(nil), m[off:off+rdlen]...)))
		}
		off += rdlen
	}
	return ips
}
