package main

// Decides whether a host name is a Ju site. This is a line-by-line port of
// app/src/main/java/id/juban/app/DomainMatcher.java; both are checked against
// tools/matcher-cases.txt so they always give the same answers. Change both together.

import (
	"regexp"
	"strings"
)

const (
	ReasonList   = "list"
	ReasonCustom = "custom"
	ReasonSmart  = "smart"
)

func set(xs ...string) map[string]bool {
	m := make(map[string]bool, len(xs))
	for _, x := range xs {
		m[x] = true
	}
	return m
}

// Legitimate sites that the naming patterns would otherwise catch.
var builtinAllow = set("toto.com", "toto.co.id", "totousa.com", "bet.com", "qq.com", "alphabet.com")

// Top-level domains reserved for this kind of site.
var specialTLDs = set("bet", "casino", "poker", "bingo", "lotto")

// If any part of the name contains one of these, it is blocked.
var strong = []string{
	"togel", "gacor", "maxwin", "sbobet", "judol", "casino", "poker",
	"judibola", "judionline", "judiqq", "judimpo", "judislot",
	"bandarq", "dominoqq", "pkvgames", "sabungayam", "mixparlay", "taruhan",
	"mahjongways", "pragmaticplay", "pgsoft", "spadegaming", "gatesofolympus",
	"rtpslot", "rtplive", "bocoranrtp", "scatterhitam", "sportsbook", "betting",
	"jackpot", "roulette", "baccarat", "totomacau", "toto4d",
	"1xbet", "bet365", "betway", "188bet", "fun88", "joker123", "joker388",
	"nova88", "cmd368", "ibcbet", "alexis17",
	// game makers: their game servers carry these names (pragmaticplay and pgsoft above)
	"evogames", "evolutiongaming", "ezugi", "microgaming", "jiligame", "jokergaming",
	"cq9gaming", "playngo", "nolimitcity", "hacksawgaming", "redtigergaming",
	"yggdrasilgaming", "relaxgaming", "booongo", "spribe", "nextspin", "advantplay",
	"mega888", "918kiss", "sexybaccarat", "aesexy", "jdbgaming", "skywindgroup",
	"habanerosystems",
	// brands and phrases seen in the wild
	"mawartoto", "loginalternatif", "linkalternatif", "alternatiflogin",
}

// Whole words (bounded by digits, hyphens or the ends of the name).
var words = set("slot", "slots", "judi", "toto", "bet", "bets", "mpo", "w88", "m88")

// Ordinary words that merely end like one of the names above.
var suffixExceptions = []string{"timeslot", "timeslots", "alphabet", "tibet", "sherbet", "abet", "cinema4d"}

// Words that, glued to a "lucky number", make a typical brand (hoki88, raja777...).
var brandWords = []string{
	"hoki", "cuan", "jp", "win", "mpo", "dewa", "naga", "raja", "ratu", "sultan",
	"bos", "bola", "spin", "zeus", "bet", "slot", "toto", "play", "kaya", "mega",
	"asia", "indo", "king", "liga", "gol", "vip", "luck", "fortune", "emas", "gold",
	"menang", "untung", "jitu", "angka", "kartu", "club", "game", "olympus",
}

var luckyNumbers = set(
	"77", "88", "99", "123", "138", "168", "188", "189", "303", "328", "338", "365",
	"368", "388", "555", "666", "777", "789", "888", "999", "1000", "4d")

// A name ending in one of these after a hyphen: "something-win", "something-jp".
var lastWords = set("win", "wins", "jp", "cuan", "hoki")

var (
	wordNum    = regexp.MustCompile(`^([a-z]{2,14})(\d{2,4}|4d)$`)
	numWord    = regexp.MustCompile(`^(\d{2,4})([a-z]{2,14})$`)
	triple     = regexp.MustCompile(`(777|888|999)`)
	numThenWin = regexp.MustCompile(`[0-9]{2,4}(win|wins|jp)[0-9]*$`)
	nonLetters = regexp.MustCompile(`[^a-z]+`)
	domainRe   = regexp.MustCompile(`^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$`)
	wordRe     = regexp.MustCompile(`^[a-z0-9]{4,20}$`)
)

type Matcher struct {
	listed, block, allow map[string]bool
	userWords            []string
	smart                bool
}

func NewMatcher(listed, block, userWords, allow []string, smart bool) *Matcher {
	return &Matcher{
		listed:    set(listed...),
		block:     set(block...),
		allow:     set(allow...),
		userWords: append([]string(nil), userWords...),
		smart:     smart,
	}
}

// Check returns why host is blocked (one of the Reason constants), or "" if it is allowed.
func (m *Matcher) Check(host string) string {
	if host == "" {
		return ""
	}
	h := strings.TrimSuffix(strings.ToLower(host), ".")

	if inSet(m.allow, h) {
		return ""
	}
	if inSet(m.block, h) {
		return ReasonCustom
	}
	if inSet(m.listed, h) {
		return ReasonList
	}

	labels := strings.Split(h, ".")
	if len(labels) < 2 {
		return ""
	}
	if len(m.userWords) > 0 {
		for _, l := range labels[:len(labels)-1] {
			flat := strings.ReplaceAll(l, "-", "")
			for _, w := range m.userWords {
				if strings.Contains(flat, w) {
					return ReasonCustom
				}
			}
		}
	}
	if !m.smart || inSet(builtinAllow, h) {
		return ""
	}
	if specialTLDs[labels[len(labels)-1]] {
		return ReasonSmart
	}
	for _, l := range labels[:len(labels)-1] {
		if looksLike(l) {
			return ReasonSmart
		}
	}
	return ""
}

// AllowedByUser is true if the user marked this site (or a parent domain) "Always allow".
func (m *Matcher) AllowedByUser(host string) bool {
	return inSet(m.allow, strings.TrimSuffix(strings.ToLower(host), "."))
}

// inSet is true if the domain or any parent domain is in the set.
func inSet(s map[string]bool, h string) bool {
	if len(s) == 0 {
		return false
	}
	d := h
	for {
		if s[d] {
			return true
		}
		i := strings.IndexByte(d, '.')
		if i < 0 {
			return false
		}
		d = d[i+1:]
	}
}

func looksLike(label string) bool {
	if len(label) < 3 && !words[label] {
		return false
	}
	flat := strings.ReplaceAll(label, "-", "")
	for _, ok := range suffixExceptions {
		if flat == ok || (len(ok) >= 5 && strings.HasSuffix(flat, ok)) {
			return false
		}
	}
	for _, k := range strong {
		if strings.Contains(flat, k) {
			return true
		}
	}
	for _, t := range nonLetters.Split(label, -1) {
		if words[t] {
			return true
		}
	}
	for _, t := range strings.Split(label, "-") {
		if words[t] {
			return true // catches w88 / m88
		}
	}
	if strings.HasPrefix(flat, "slot") || strings.HasSuffix(flat, "slot") || strings.HasSuffix(flat, "slots") {
		return true
	}
	if len(flat) > 4 && (strings.HasSuffix(flat, "toto") || strings.HasSuffix(flat, "judi")) {
		return true
	}
	if len(flat) > 4 && strings.HasSuffix(flat, "bet") {
		return true
	}
	if len(flat) > 3 && (strings.HasSuffix(flat, "4d") || strings.HasSuffix(flat, "qq")) {
		return true
	}
	if parts := strings.Split(label, "-"); len(parts) > 1 && lastWords[parts[len(parts)-1]] {
		return true
	}
	if numThenWin.MatchString(flat) {
		return true
	}
	if triple.MatchString(flat) && len(nonLetters.ReplaceAllString(flat, "")) >= 3 {
		return true
	}
	if g := wordNum.FindStringSubmatch(flat); g != nil {
		if g[1] == "mpo" {
			return true
		}
		if luckyNumbers[g[2]] && hasBrandWord(g[1]) {
			return true
		}
	}
	if g := numWord.FindStringSubmatch(flat); g != nil && luckyNumbers[g[1]] && hasBrandWord(g[2]) {
		return true
	}
	return false
}

func hasBrandWord(w string) bool {
	for _, b := range brandWords {
		if strings.Contains(w, b) {
			return true
		}
	}
	return false
}

// NormalizeDomain turns "https://www.Example.com/page" into "example.com", or "" if it is not a domain.
func NormalizeDomain(in string) string {
	s := strings.ToLower(strings.TrimSpace(in))
	if i := strings.Index(s, "://"); i >= 0 {
		s = s[i+3:]
	}
	if i := strings.IndexByte(s, '/'); i >= 0 {
		s = s[:i]
	}
	if i := strings.IndexByte(s, ':'); i >= 0 {
		s = s[:i]
	}
	s = strings.TrimPrefix(s, "www.")
	if !domainRe.MatchString(s) {
		return ""
	}
	return s
}

// NormalizeWord accepts a brand word of 4-20 letters or digits, or returns "".
func NormalizeWord(in string) string {
	s := strings.ToLower(strings.TrimSpace(in))
	if !wordRe.MatchString(s) {
		return ""
	}
	return s
}

// ParseList reads a block list: one domain per line, # starts a comment.
func ParseList(text string) []string {
	var out []string
	for _, line := range strings.Split(text, "\n") {
		line = strings.ToLower(strings.TrimSpace(line))
		if line != "" && !strings.HasPrefix(line, "#") {
			out = append(out, line)
		}
	}
	return out
}
