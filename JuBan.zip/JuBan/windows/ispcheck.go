package main

// Indonesia's own blocklist, through the network's DNS. A port of IspCheck.java: the
// network DNS (home router / ISP) must block Komdigi's TRUST+Positif list; JuBan learns how
// it answers a blocked name and blocks whatever it blocks. An address only counts as the
// warning page once it came back for at least two different blocked names, so a big site
// that simply has a different address at the ISP is never mistaken for a block.

import (
	"encoding/binary"
	"net"
	"sync"
)

var ispProbes = []string{"bet365.com", "1xbet.com", "sbobet.com", "pornhub.com", "xvideos.com", "stake.com"}

type DNSAnswer struct {
	Rcode int
	Addrs map[string]bool
}

func (a *DNSAnswer) resolves() bool   { return a != nil && a.Rcode == 0 && len(a.Addrs) > 0 }
func (a *DNSAnswer) noSuchSite() bool { return a != nil && a.Rcode == rcodeNXDomain }

// ParseAnswer reads the result code and the A / AAAA addresses of a DNS answer.
func ParseAnswer(m []byte) *DNSAnswer {
	if len(m) < 12 {
		return nil
	}
	a := &DNSAnswer{Rcode: int(m[3] & 0x0f), Addrs: map[string]bool{}}
	qd, an := int(binary.BigEndian.Uint16(m[4:])), int(binary.BigEndian.Uint16(m[6:]))
	off := 12
	for i := 0; i < qd; i++ {
		if off = skipName(m, off); off < 0 || off+4 > len(m) {
			return a
		}
		off += 4
	}
	for i := 0; i < an; i++ {
		if off = skipName(m, off); off < 0 || off+10 > len(m) {
			return a
		}
		typ := binary.BigEndian.Uint16(m[off:])
		rdlen := int(binary.BigEndian.Uint16(m[off+8:]))
		off += 10
		if off+rdlen > len(m) {
			return a
		}
		if (typ == 1 && rdlen == 4) || (typ == 28 && rdlen == 16) {
			a.Addrs[net.IP(m[off:off+rdlen]).String()] = true
		}
		off += rdlen
	}
	return a
}

type IspCheck struct {
	mu             sync.Mutex
	seenFor        map[string]map[string]bool
	nxProbes       int
	blockAddrs     map[string]bool
	nxMeansBlocked bool
}

func (c *IspCheck) Reset() {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.seenFor, c.nxProbes, c.blockAddrs, c.nxMeansBlocked = nil, 0, nil, false
}

func (c *IspCheck) Learn(probe string, network, google *DNSAnswer) {
	if network == nil || !google.resolves() {
		return
	}
	c.mu.Lock()
	defer c.mu.Unlock()
	if network.noSuchSite() {
		if c.nxProbes++; c.nxProbes >= 2 {
			c.nxMeansBlocked = true
		}
		return
	}
	if !network.resolves() {
		return
	}
	for a := range network.Addrs {
		if google.Addrs[a] {
			return // same answer as Google: not blocked
		}
	}
	if c.seenFor == nil {
		c.seenFor = map[string]map[string]bool{}
	}
	if c.blockAddrs == nil {
		c.blockAddrs = map[string]bool{}
	}
	for a := range network.Addrs {
		if c.seenFor[a] == nil {
			c.seenFor[a] = map[string]bool{}
		}
		c.seenFor[a][probe] = true
		if len(c.seenFor[a]) >= 2 {
			c.blockAddrs[a] = true
		}
	}
}

func (c *IspCheck) Active() bool {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.nxMeansBlocked || len(c.blockAddrs) > 0
}

func (c *IspCheck) Blocked(network, google *DNSAnswer) bool {
	if network == nil {
		return false
	}
	c.mu.Lock()
	defer c.mu.Unlock()
	if network.Rcode == 0 {
		for a := range network.Addrs {
			if c.blockAddrs[a] {
				return true
			}
		}
		return false
	}
	return c.nxMeansBlocked && network.noSuchSite() && google.resolves()
}
