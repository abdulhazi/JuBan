# JuBan: user guide

JuBan blocks Ju sites on your Android phone and your Windows laptop. Once it is on, it is deliberately slow to turn off,
so a strong urge has time to pass.

## Install

1. Open the file `app-debug.apk` on your phone.
2. If Android asks, allow your file app or browser to "install unknown apps".
3. Tap **Install**, then **Open**.

## Set up (about 2 minutes)

1. **Add sites you must always reach (optional).** Under *My own rules*, type the address
   and tap **Always allow**. Do this first: it is locked once protection is on.
2. **Turn on protection.** Tap **Turn on protection** and accept Android's VPN request.
   JuBan does not send your browsing anywhere. It only checks site names, on your phone.
   Allow notifications when asked.
3. **Turn on uninstall protection.** Tap **Turn on uninstall protection**, then
   **Activate this device admin app**. From now on the Uninstall button is disabled.
   - If Android says *"Restricted setting"*: open Settings → Apps → JuBan → the ⋮ menu
     (top right) → **Allow restricted settings**, then repeat this step.
4. **Turn on strict mode.** Tap **Open accessibility settings** → *Downloaded apps*
   (or *Installed apps*) → **JuBan strict mode** → switch it on. If Android says it is a
   restricted setting: Settings → Apps → JuBan → ⋮ → **Allow restricted settings**, then
   try again. On Xiaomi, also lock JuBan in the recent-apps screen (long-press its card →
   lock) so it is not closed. While protection is locked, strict mode closes JuBan's App
   info, the device admin page, the uninstall dialog and JuBan's VPN settings. Without
   it, uninstall protection can simply be switched off in Settings.
5. **Optional, for extra strength.** Tap **Open VPN settings** → the gear next to JuBan →
   switch on **Always-on VPN**. Leave **Block connections without VPN** switched off,
   otherwise the phone will have no internet.

Check that it works: try to open a Ju site. It should fail to load and appear under
*Recently blocked* in JuBan.

## Everyday use

- **Screen check** (on by default, needs strict mode): reads the page you are looking at in
  your browser and goes back if it is a Ju page. It reads browsers only, on the phone only,
  and keeps nothing.
- **Indonesia's blocklist**: on most Indonesian networks JuBan also blocks everything on
  the government's official list. The status is shown on JuBan's main screen.
- **Page check** (on by default): the first time a site is opened, JuBan reads its front
  page and blocks it if it is full of Ju words. A new site can take a second or two longer
  the first time; after that it is remembered.
- **A Ju site still opens?** Type its address under *My own rules* and tap **Block**.
- **The same brand keeps coming back on new addresses?** Type just the brand name
  (one word, no dots) and tap **Block**. Every address containing that word is blocked.
- **A normal site is blocked by mistake?** It can be added to *Always allow* only while
  protection is off or unlocked (see below). This is on purpose.
- **Protection stopped by itself?** If the VPN is disconnected in Android's settings,
  JuBan switches itself back on. If it cannot, you get a notification: tap it.
- After a phone restart, JuBan starts again by itself.

## Turning it off

1. Tap **Request turn-off** and confirm. Protection stays on for 24 more hours.
2. You can tap **Cancel turn-off request** at any time to stay protected.
3. After 24 hours the button says **Turn off now**. You have one hour to use it; after
   that the request expires and you would have to ask again.
4. To uninstall: after turning off, tap **Remove uninstall protection**. Then uninstall
   JuBan like any other app.

## What JuBan cannot do

- Android allows only one VPN at a time, so JuBan cannot run together with another VPN app.
- If *Private DNS* in Android's network settings is set to a specific provider, site
  look-ups go around JuBan. Keep it on "Off" or "Automatic".
- A determined person can still get around it (for example by deactivating the device
  admin app in Android's security settings, or by resetting the phone). JuBan is built to
  stop impulses, and works best together with support from people you trust.

## Windows laptop

1. Download `JuBan.exe` and double-click it.
2. If Windows shows **"Windows protected your PC"**: click **More info**, then **Run anyway**.
   (JuBan is not signed by a paid certificate, so Windows does not recognise it.)
3. Click **Yes** when Windows asks for administrator permission.
4. JuBan installs itself and opens its page in your browser. Click **Turn on protection**.
5. Check: open a Ju site. It should say *This site can't be reached*.

- JuBan protects every browser and every Windows user on the laptop, and starts by
  itself when the laptop starts. There is no window to keep open.
- To open the JuBan page again: the **JuBan** shortcut on the desktop or in the Start menu.
- Turning off works the same as on the phone: **Request turn-off**, wait 24 hours,
  **Turn off now**. After that, **Remove JuBan** at the bottom of the page uninstalls it.
- Chrome and Edge may show *"Managed by your organization"*. That is JuBan switching off
  their built-in secure-DNS option, which would otherwise go around the block.
- **No internet at all?** That means JuBan stopped unexpectedly. It restarts itself within
  a few minutes. If it does not, restart the laptop. As a last resort, press Win+R and run:
  `"C:\Program Files\JuBan\JuBan.exe" restore-dns`
- A determined administrator can still get around it (for example in Task Scheduler).
  Like the phone app, it is built to stop impulses.

---

# JuBan: panduan pengguna

JuBan memblokir situs Ju di ponsel Android dan laptop Windows Anda. Setelah aktif, JuBan sengaja dibuat lama untuk
dimatikan, supaya keinginan yang kuat sempat mereda.

## Memasang

1. Buka berkas `app-debug.apk` di ponsel.
2. Jika diminta, izinkan aplikasi berkas atau browser untuk "memasang aplikasi tidak dikenal".
3. Ketuk **Instal**, lalu **Buka**.

## Pengaturan awal (sekitar 2 menit)

1. **Tambahkan situs yang harus selalu bisa dibuka (opsional).** Di *Aturan saya*, ketik
   alamatnya lalu ketuk **Selalu izinkan**. Lakukan ini dulu: bagian ini terkunci setelah
   perlindungan aktif.
2. **Aktifkan perlindungan.** Ketuk **Aktifkan perlindungan** dan setujui permintaan VPN
   dari Android. JuBan tidak mengirim data penjelajahan Anda ke mana pun. JuBan hanya
   memeriksa nama situs, di ponsel Anda. Izinkan notifikasi jika diminta.
3. **Aktifkan perlindungan uninstall.** Ketuk **Aktifkan perlindungan uninstall**, lalu
   **Aktifkan aplikasi admin perangkat ini**. Mulai sekarang tombol Uninstall tidak bisa
   dipakai.
   - Jika Android menampilkan *"Setelan terbatas"*: buka Setelan → Aplikasi → JuBan →
     menu ⋮ (kanan atas) → **Izinkan setelan terbatas**, lalu ulangi langkah ini.
4. **Aktifkan mode ketat.** Ketuk **Buka setelan aksesibilitas** → *Aplikasi yang
   didownload* (atau *Aplikasi terinstal*) → **Mode ketat JuBan** → aktifkan. Jika Android
   menyebutnya setelan terbatas: Setelan → Aplikasi → JuBan → ⋮ → **Izinkan setelan
   terbatas**, lalu coba lagi. Di Xiaomi, kunci juga JuBan di layar aplikasi terbaru (tekan
   lama kartunya → kunci) agar tidak ditutup. Selama perlindungan terkunci, mode ketat
   menutup Info aplikasi JuBan, halaman admin perangkat, dialog uninstall dan pengaturan VPN
   JuBan. Tanpa mode ketat, perlindungan uninstall bisa dimatikan begitu saja di Setelan.
5. **Opsional, agar lebih kuat.** Ketuk **Buka pengaturan VPN** → ikon roda gigi di samping
   JuBan → nyalakan **VPN selalu aktif**. Biarkan **Blokir koneksi tanpa VPN** tetap mati,
   kalau tidak ponsel tidak bisa internet.

Cek hasilnya: coba buka sebuah situs Ju. Situs itu seharusnya gagal dimuat dan muncul di
*Baru saja diblokir* di JuBan.

## Pemakaian sehari-hari

- **Cek layar** (aktif sejak awal, butuh mode ketat): membaca halaman yang sedang Anda lihat
  di browser dan kembali jika itu halaman Ju. Hanya membaca browser, hanya di ponsel ini,
  dan tidak menyimpan apa pun.
- **Daftar blokir Indonesia**: di sebagian besar jaringan Indonesia, JuBan juga memblokir
  semua situs dalam daftar resmi pemerintah. Statusnya tampil di layar utama JuBan.
- **Cek halaman** (aktif sejak awal): saat sebuah situs dibuka pertama kali, JuBan membaca
  halaman depannya dan memblokirnya jika penuh kata-kata Ju. Situs baru bisa butuh satu-dua
  detik lebih lama saat pertama dibuka; setelah itu hasilnya diingat.
- **Masih ada situs Ju yang terbuka?** Ketik alamatnya di *Aturan saya* lalu ketuk **Blokir**.
- **Merek yang sama muncul lagi dengan alamat baru?** Ketik nama mereknya saja (satu kata,
  tanpa titik) lalu ketuk **Blokir**. Semua alamat yang mengandung kata itu diblokir.
- **Situs biasa ikut terblokir?** Situs itu hanya bisa ditambahkan ke *Selalu izinkan* saat
  perlindungan mati atau terbuka (lihat di bawah). Ini memang disengaja.
- **Perlindungan berhenti sendiri?** Jika VPN diputus dari pengaturan Android, JuBan
  menyalakan dirinya lagi. Jika tidak bisa, muncul notifikasi: ketuk notifikasi itu.
- Setelah ponsel dinyalakan ulang, JuBan aktif lagi dengan sendirinya.

## Mematikan

1. Ketuk **Ajukan penonaktifan** lalu konfirmasi. Perlindungan tetap aktif 24 jam lagi.
2. Anda bisa mengetuk **Batalkan pengajuan** kapan saja agar tetap terlindungi.
3. Setelah 24 jam, tombol berubah menjadi **Matikan sekarang**. Anda punya waktu satu jam
   untuk memakainya; setelah itu pengajuan hangus dan harus diajukan lagi.
4. Untuk uninstall: setelah dimatikan, ketuk **Lepas perlindungan uninstall**. Lalu
   uninstall JuBan seperti aplikasi biasa.

## Yang tidak bisa dilakukan JuBan

- Android hanya mengizinkan satu VPN dalam satu waktu, jadi JuBan tidak bisa berjalan
  bersama aplikasi VPN lain.
- Jika *DNS Pribadi* di pengaturan jaringan Android diisi penyedia tertentu, pencarian
  nama situs tidak melewati JuBan. Biarkan di "Nonaktif" atau "Otomatis".
- Orang yang benar-benar berniat tetap bisa mengakalinya (misalnya dengan menonaktifkan
  aplikasi admin perangkat di pengaturan keamanan Android, atau mereset ponsel). JuBan
  dibuat untuk menahan dorongan sesaat, dan paling efektif bila disertai dukungan dari
  orang yang Anda percaya.


## Laptop Windows

1. Unduh `JuBan.exe` lalu klik dua kali.
2. Jika muncul **"Windows protected your PC"**: klik **More info**, lalu **Run anyway**.
   (JuBan tidak ditandatangani dengan sertifikat berbayar, jadi Windows belum mengenalnya.)
3. Klik **Yes** saat Windows meminta izin administrator.
4. JuBan memasang dirinya dan membuka halamannya di browser. Klik **Aktifkan perlindungan**.
5. Cek: buka sebuah situs Ju. Seharusnya muncul *This site can't be reached*.

- JuBan melindungi semua browser dan semua pengguna Windows di laptop, dan berjalan sendiri
  saat laptop dinyalakan. Tidak ada jendela yang perlu dibiarkan terbuka.
- Untuk membuka halaman JuBan lagi: pintasan **JuBan** di desktop atau menu Start.
- Cara mematikan sama seperti di ponsel: **Ajukan penonaktifan**, tunggu 24 jam,
  **Matikan sekarang**. Setelah itu, **Hapus JuBan** di bagian bawah halaman untuk uninstall.
- Chrome dan Edge mungkin menulis *"Dikelola oleh organisasi Anda"*. Itu karena JuBan
  mematikan opsi DNS aman bawaan mereka yang bisa mengakali blokir.
- **Internet mati total?** Artinya JuBan berhenti tiba-tiba. JuBan akan menyala lagi dalam
  beberapa menit. Jika tidak, nyalakan ulang laptop. Sebagai jalan terakhir, tekan Win+R lalu jalankan:
  `"C:\Program Files\JuBan\JuBan.exe" restore-dns`
- Administrator yang benar-benar berniat tetap bisa mengakalinya (misalnya lewat Task Scheduler).
  Sama seperti di ponsel, JuBan dibuat untuk menahan dorongan sesaat.


## Phone lock (Android, optional, from 2.3)

Safe Mode switches off every app you installed, so an app alone cannot stop it. If JuBan is made
the **device owner** of the phone (the way companies manage work phones), Android lets it block:
Safe Mode, factory reset from Settings, adding another user (which would have no protection),
uninstall and Private DNS changes. JuBan also asks Android to keep its
VPN running ("Block connections without VPN" stays off on purpose).

Set-up (needs a computer with a USB cable):
1. Sign out of every account on the phone (Google, Xiaomi, others). Android refuses otherwise. Sign in again afterwards.
2. Turn on Developer options and USB debugging (on Xiaomi also "USB debugging (Security settings)").
3. Run: `adb shell dpm set-device-owner id.juban.app/.AdminReceiver`
4. Open JuBan: the "Phone lock" section should say ON.

Undo: wait out the 24-hour turn-off delay, then tap "Release phone lock". It is locked while protection is on.
Not covered: resetting from recovery mode with the buttons, a hardware reflash, other devices.
Risks: set-up is awkward on some phones (Xiaomi especially) and this code has only been type-checked,
not run on a phone. Do it when you are calm and have time, not in a hurry.


## Keeping strict mode on (Android, from 2.4)

Some phones (Xiaomi especially) switch an accessibility service off after a day or two. JuBan now
checks once a minute while protection is on. If strict mode was on and is now off, it shows an alert
that opens JuBan. For an automatic fix, grant JuBan one extra permission once from a computer:
`adb shell pm grant id.juban.app android.permission.WRITE_SECURE_SETTINGS`
JuBan then switches strict mode back on by itself. Also set Battery to "No restrictions", turn on
Autostart and lock JuBan in the recent-apps screen so the phone's cleaner leaves it alone.
