# JuBan

Android app and Windows program. The Windows version is in `windows/` (Go, no
dependencies); see "Windows" below. Both use the same site list and the same rules.

An Android app that blocks online gambling ("judol") sites on the phone it is installed on.
Android 8.0 or newer. No account, no ads, no server: nothing leaves the phone.

## How it works

JuBan sets itself up as a local VPN, but it does **not** route your traffic anywhere.
It only becomes the phone's DNS server (the "phone book" every app uses to find a site).

1. An app or browser asks "where is `slotgacor88.xyz`?"
2. The question arrives in `BlockVpnService`.
3. `DomainMatcher` decides:
   - on your **Always allow** list → let through
   - on your **Block** list, contains one of your **brand words**, or on the bundled list
     (`app/src/main/assets/blocklist.txt`) → blocked
   - **Smart detection**: the name looks like gambling (`slot`, `togel`, `gacor`, `judi`,
     `…toto`, `…bet`, `hoki88`, `raja777`, `mpo123`, `.casino`, `.bet` …) → blocked
4. Blocked names get the answer "no such site". Everything else is passed to a normal
   DNS server (8.8.8.8, then 1.1.1.1) and works as usual.

Smart detection matters most in Indonesia: illegal sites change address every few days,
so a fixed list is always behind, but they keep the same style of name.

## Getting the APK

**Without a computer (GitHub builds it):**

1. Create a new repository on GitHub and upload everything in this folder
   (keep the folder structure, including `.github/workflows/build.yml`).
2. Open the **Actions** tab → **Build APK** → wait for the green tick.
3. Open the finished run → **Artifacts** → download `JuBan-apk` → unzip → `app-debug.apk`.
4. Copy the APK to the phone, open it, and allow "install unknown apps" when asked.

**With Android Studio:** File → Open → this folder → Run ▶.

## Using it

See [USER_GUIDE.md](USER_GUIDE.md) (English and Indonesian) for install, setup and
turn-off steps written for the person using the phone. The same steps are inside the app
under "Setup guide". The app's own screens never use the word "gambling"; they say "Ju sites".

## Indonesia's blocklist (from 1.7, both apps)

Indonesian ISPs must block Komdigi's TRUST+Positif list (millions of Ju sites) in their
DNS. JuBan normally asks Google's DNS, which does not, so every A/AAAA look-up is also
sent to the network's own DNS (Wi-Fi router / mobile operator). If that DNS blocks the
name, so does JuBan (remembered for a day). `IspCheck.java` / `windows/ispcheck.go`:
JuBan first learns how the network answers a blocked name by asking about a few names
that are surely on the list; an address only counts as the warning page once it came
back for at least two different blocked names, so big sites with a different address at
the ISP are never mistaken for blocks. On a network whose DNS blocks nothing, the
feature simply stays off ("Not available on this network").

## Screen check (Android, from 1.7)

Part of the accessibility service: in browsers only, while protection is on, JuBan reads
the visible page (at most every 1.2 s, nothing stored) and scores it like the page check.
A Ju page is closed (Back) and its site, read from the address bar, is remembered as Ju.
This is the one layer that sees what the user sees: hacked sub-pages, cloaked pages and
brand-new addresses. News pages about Ju sites are recognised and left alone. Switching
it off is locked while protection is on. In-app browsers of other apps are not covered.

## Game makers (from 1.6)

Ju sites are mostly shop fronts; the slot and live-casino games stream from the game
makers' own servers. Both apps block those servers: by name (any address containing a
distinctive maker name such as `pragmaticplay`, `evogames`, `spribe`, `jiligame`, see
DomainMatcher) and by address (the "Game makers" section of the shared list). Names that
are also ordinary words (habanero, playtech, netent) are only blocked as exact addresses.
Limit: sites that stream the games through their own address (some do, via game
aggregators) are not affected by this layer.

## Windows safety task (from 1.6)

A second scheduled task, `JuBan-Safety`, runs every 5 minutes. If `JuBan.exe` is missing
(for example removed by antivirus), it puts the adapters that point at JuBan back to
automatic DNS, so the laptop is never left without internet.

## Page check (Android from 1.3, Windows from 1.5)

Names alone miss many sites (random names, hacked subdomains of real websites). So the
first time an unknown site is looked up, JuBan opens its front page itself, the way a
phone browser in Indonesia would, and scores the text (`ContentScorer.java`). Several
strong phrases together (e.g. "togel online", "live casino", "slot gacor", game-provider
names) mean a Ju site. Pages about Ju sites (news, police, government) are recognised by
their own vocabulary and let through.

- The DNS answer for that first visit is held for up to 3 seconds while the page is read,
  so even the first visit is blocked. If the check takes longer, that visit goes through
  and the next one uses the verdict.
- The check visits like someone who clicked a Google result (Google as referrer): many Ju
  pages sit on hacked websites that show the Ju page only to visitors coming from Google.
- Verdicts are remembered in `files/verdicts2.txt`: Ju sites forever, clean sites 7 days,
  sites that could not be read 6 hours (never blocked). Error pages, "checking your browser"
  screens and pages with almost no text count as "could not be read", never as clean.
  (1.4 dropped the clean verdicts stored by 1.3, so those sites are checked again.)
- Big known sites, app/ad/CDN servers, government and school domains are never checked
  (`PageCheckPolicy.java`). JuBan's own checks are excluded from its VPN.
- Limits: it only sees the front page. A Ju page hidden on a sub-page of a hacked site
  (example: `2020.latamhospitals.com/evento/`) is invisible at this level; block that
  name manually. Sites that show a harmless page to some visitors can also slip through.
- Switching page check off is locked while protection is on.
- Windows: the same rules in `windows/pagecheck.go`. Its word lists are generated from
  the Java code (`python3 tools/gen_go_lists.py`), so both apps judge pages the same way.
  JuBan for Windows looks up the site's address itself (the computer's DNS points at
  JuBan and would wait for the very check), and the verdicts live in
  `C:\ProgramData\JuBan\verdicts.txt`.

## Strict mode: what is locked, and how

**Strict mode (Android, from 1.5).** Device admin alone only greys out Uninstall; it can be
deactivated in Settings. Strict mode is an Accessibility Service (`GuardService.java`) that,
while protection is locked, closes any system screen mentioning JuBan together with a word
for switching it off (App info, device admin, uninstall dialog, JuBan's Accessibility
switch, VPN settings, clear storage). It looks only at system packages (Settings,
installers, security centres, launchers; `GuardRules.java`), never at chats or other apps,
and stores nothing. Still not a wall: Safe Mode, a factory reset or a computer with adb
get around it.


- **24-hour turn-off delay.** "Request turn-off" starts a countdown; protection stays on.
  After 24 hours there is a one-hour window to actually turn it off, then the request
  expires. Change the times in `LockTimer.java` (`DELAY_MS`, `WINDOW_MS`).
- **Locked while on:** adding "Always allow" sites, removing rules, switching Smart
  detection off, and removing uninstall protection. Adding blocks is always possible.
- **Uninstall protection.** JuBan can be made a device admin app (it requests no admin
  policies). Android will not uninstall an active device admin app.
- **Self-restart.** If the VPN is disconnected in Android settings while protection is
  wanted, the service reconnects after 2 seconds. After a reboot `BootReceiver` starts it.
- The countdown uses time-since-boot while the phone has not restarted, so moving the
  clock forward does not shorten it.

## Limits you should know

- **It is friction, not a wall.** Device admin can be deactivated in Android's security
  settings (JuBan shows a warning there but cannot refuse). "Forget VPN", safe mode, a
  restart combined with a clock change, or a factory reset also get around it. Closing
  those gaps needs device-owner mode, which this app does not use.
- **False positives are slower to fix.** With protection on, "Always allow" is locked,
  so a wrongly blocked site waits for the turn-off delay.
- **Private DNS.** If Settings → Network → Private DNS is set to a specific provider
  (not "Off" or "Automatic"), look-ups skip JuBan. Same for a browser whose
  "Secure DNS" setting is pointed at a chosen provider.
- **One VPN at a time.** Android allows a single active VPN.
- **Names only.** A site with an innocent-looking address that is on no list gets
  through until someone blocks it or its brand word.
- Only IPv4 DNS over UDP is handled, which is what Android uses by default.

## Updating the app

All builds are signed with `app/debug.keystore`, so a newer APK installs over the old one
and keeps the user's rules. (Builds made before that file existed had a random signature
and must be uninstalled once.) It is a throwaway debug key: fine for sharing an APK
directly, not for publishing to an app store.

## Windows

`windows/` builds `JuBan.exe`. The same idea as the phone: a small DNS filter on
127.0.0.1 / ::1 port 53, with every network adapter pointed at it.

- Runs as a scheduled task under SYSTEM: at boot, restarted if it stops, re-checked every
  5 minutes. Every 30 seconds it re-points any adapter whose DNS was changed.
- Control page at http://127.0.0.1:53053/ (only reachable from this computer; host-header
  check plus a per-start secret token on every button).
- Sets Chrome, Edge, Brave and Firefox policies that switch off their own DNS-over-HTTPS.
- Same 24-hour turn-off delay and same locked settings as the phone. Uses the clock, so
  an administrator who changes the clock can shorten it.
- If port 53 is taken by something else, it does not point the computer at itself
  (so the internet keeps working) and shows the problem on the page.
- Settings: `C:\ProgramData\JuBan\config.json`, log: `juban.log` next to it.
- Untested on a real Windows machine at the time of writing; the PowerShell steps are the
  part most likely to need a fix.

Build and test (any OS with Go 1.22+):

```
cp app/src/main/assets/blocklist.txt windows/blocklist.txt
cd windows
go test ./...
GOOS=windows GOARCH=amd64 go build -trimpath -ldflags "-H windowsgui -s -w" -o JuBan.exe .
```

## Changing the rules

- Bundled list: edit `app/src/main/assets/blocklist.txt` (one domain per line) and rebuild.
  It is used by both apps (the Windows build copies it).
- Test cases for both apps: `tools/matcher-cases.txt`. Add a line for every site that
  slipped through, so it stays fixed in both.
- Patterns: edit the word lists at the top of
  `app/src/main/java/id/juban/app/DomainMatcher.java` and the same lists in
  `windows/matcher.go`.
- After changing patterns, run the engine test (needs only Java, no Android tools):

```
mkdir -p /tmp/engine
javac -d /tmp/engine app/src/main/java/id/juban/app/DnsPacket.java \
      app/src/main/java/id/juban/app/DomainMatcher.java \
      app/src/main/java/id/juban/app/LockTimer.java app/src/main/java/id/juban/app/ContentScorer.java \
      app/src/main/java/id/juban/app/PageCheckPolicy.java app/src/main/java/id/juban/app/PageChecker.java \
      tools/EngineTest.java tools/LockTest.java tools/PageCheckTest.java
java -cp /tmp/engine EngineTest app/src/main/assets/blocklist.txt tools/matcher-cases.txt
java -cp /tmp/engine LockTest
java -cp /tmp/engine PageCheckTest
```

## Files

| File | What it does |
|---|---|
| `DomainMatcher.java` | Decides whether a site name is gambling |
| `DnsPacket.java` | Reads DNS questions and writes the "blocked" answer |
| `BlockVpnService.java` | The local VPN that receives look-ups |
| `MainActivity.java` | The screen |
| `Prefs.java` | Saved settings, your own rules, the lock state |
| `LockTimer.java` | The turn-off delay |
| `ContentScorer.java` | Decides from a page's text whether it is a Ju site |
| `PageChecker.java` | Opens front pages and remembers verdicts |
| `PageCheckPolicy.java` | Which site names are worth checking |
| `AdminReceiver.java` | Uninstall protection (device admin) |
| `BootReceiver.java` | Restarts protection after a reboot |
| `res/values-in/` | Indonesian text (shown automatically on Indonesian phones) |


## Screen check on Windows (from 1.9)

A small helper (`JuBan.exe screen`, scheduled task `JuBan-Screen`, started when someone signs in)
runs in the signed-in person's own session. Every two seconds, if Chrome, Edge, Brave or Firefox is
the window in front, it reads the address bar and the page text through Windows UI Automation and
scores it with the same rules as the Android screen check. If it is a Ju page, it tells JuBan
(`/agent/ju`, protected by the key in `C:\ProgramData\JuBan\agent.key`), which remembers the site
as blocked, and the helper closes the tab (Ctrl+W, only if that window is still in front).
Searches, blank tabs, IP addresses, safe-listed sites and "Always allow" sites are never touched.
The text is never stored. It can be switched off on the control page (locked while JuBan is on).
Limits: it only works while the person is signed in, a person can still end the helper in Task
Manager, and in-app browsers are not covered.


## Phone lock (Android, optional, from 2.3)

Safe Mode switches off every app you installed, so an app alone cannot stop it. If JuBan is made
the **device owner** of the phone (the way companies manage work phones), Android lets it block:
Safe Mode, factory reset from Settings, adding another user (which would have no protection),
uninstall and Private DNS changes. JuBan also asks Android to keep its
VPN running ("Block connections without VPN" stays off on purpose).

Set-up (needs a computer with a USB cable):
1. Sign out of every account on the phone (Google, Xiaomi, others). Android refuses otherwise. Sign in again afterwards.
2. Turn on Developer options and USB debugging (on Xiaomi also "USB debugging (Security settings)").
3. Run: `adb shell dpm set-device-owner id.juban.app/.AdminReceiver`
4. Open JuBan: the "Phone lock" section should say ON.

Undo: wait out the 24-hour turn-off delay, then tap "Release phone lock". It is locked while protection is on.
Not covered: resetting from recovery mode with the buttons, a hardware reflash, other devices.
Risks: set-up is awkward on some phones (Xiaomi especially) and this code has only been type-checked,
not run on a phone. Do it when you are calm and have time, not in a hurry.


## Keeping strict mode on (Android, from 2.4)

Some phones (Xiaomi especially) switch an accessibility service off after a day or two. JuBan now
checks once a minute while protection is on. If strict mode was on and is now off, it shows an alert
that opens JuBan. For an automatic fix, grant JuBan one extra permission once from a computer:
`adb shell pm grant id.juban.app android.permission.WRITE_SECURE_SETTINGS`
JuBan then switches strict mode back on by itself. Also set Battery to "No restrictions", turn on
Autostart and lock JuBan in the recent-apps screen so the phone's cleaner leaves it alone.
